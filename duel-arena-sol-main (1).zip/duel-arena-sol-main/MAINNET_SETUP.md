# 🚀 DUEL ARENA SOL - MAINNET SETUP INSTRUCTIONS

## ✅ CAMBIOS IMPLEMENTADOS

### 1. **Configuración de MAINNET**
- ✅ Helius RPC configurado en `.env`
- ✅ WalletProvider actualizado a mainnet-beta
- ✅ Variables de entorno configuradas

### 2. **Dependencias Instaladas**
- ✅ @coral-xyz/anchor
- ✅ @solana/spl-token
- ✅ @solana/wallet-adapter-wallets (con Solflare y Backpack)

### 3. **Sistema de Transacciones Implementado**
- ✅ `src/lib/solana.ts` - Funciones de transacciones
- ✅ `src/hooks/useSolanaTransactions.ts` - Hook personalizado
- ✅ Escrow accounts con cuentas determinísticas
- ✅ Distribución automática de fondos al ganador
- ✅ Sistema de reembolsos

### 4. **Interfaz Actualizada**
- ✅ CreateChallenge con toggle demo/real
- ✅ AcceptChallenge con pagos reales
- ✅ Game.tsx con distribución de premios
- ✅ Mostrar balance de SOL
- ✅ Validaciones de saldo

---

## 🔧 CONFIGURACIÓN REQUERIDA ANTES DE USAR

### **IMPORTANTE: Actualizar Wallet de Plataforma**

En `src/lib/solana.ts`, línea 13:
```typescript
export const PLATFORM_FEE_WALLET = new PublicKey('YOUR_PLATFORM_WALLET_ADDRESS_HERE');
```

**⚠️ CAMBIAR por tu dirección de wallet real donde recibirás los fees**

### **Ejemplo:**
```typescript
export const PLATFORM_FEE_WALLET = new PublicKey('7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU');
```

---

## 🎮 CÓMO FUNCIONA

### **Modo Demo (Por Defecto)**
- No requiere SOL real
- Toggle "Demo Mode" activado
- Perfecto para testing
- Sin transacciones blockchain

### **Modo Real (MAINNET)**
- Desactivar toggle "Demo Mode"
- Requiere SOL en la wallet
- Transacciones reales en Solana
- Fees: 3.75% (90% para buyback & burn)

---

## 💰 FLUJO DE FONDOS (Modo Real)

### **1. Creación de Sala**
```
Usuario → Escrow Account (Keypair determinístico)
Monto: Bet Amount
```

### **2. Unirse a Sala**
```
Oponente → Mismo Escrow Account
Monto: Bet Amount
```

### **3. Fin del Juego (Ganador)**
```
Escrow Account → Ganador (96.25%)
Escrow Account → Platform Wallet (3.75%)
```

---

## 📋 FUNCIONALIDADES

### **Balance Display**
- Muestra SOL balance del usuario
- Se actualiza automáticamente
- Validación antes de apostar

### **Validaciones**
- ✅ Balance suficiente
- ✅ Mínimo 0.03 SOL
- ✅ Confirmación de transacción
- ✅ Verificación on-chain

### **Confirmaciones de Usuario**
- Phantom wallet popup para aprobar
- Mensajes de estado (toast)
- Loaders durante procesamiento
- Mensajes de éxito/error claros

---

## 🔐 SEGURIDAD

### **Escrow System**
- Cuentas determinísticas por challenge ID
- Fondos bloqueados hasta fin del juego
- Distribución automática al ganador
- No custodia de fondos

### **Validaciones Backend**
- Edge functions seguras
- RLS habilitado en Supabase
- Rate limiting implementado
- Verificación de participantes

---

## 🚀 PRÓXIMOS PASOS PARA PRODUCCIÓN

### **1. Token $DUEL (Requerido para fees reales)**
```bash
# Crear SPL Token en Solana
spl-token create-token
spl-token create-account <TOKEN_ADDRESS>
spl-token mint <TOKEN_ADDRESS> <AMOUNT>
```

Actualizar en `.env`:
```
VITE_DUEL_TOKEN_MINT="<YOUR_TOKEN_ADDRESS>"
```

### **2. Smart Contract Completo (Opcional pero recomendado)**
Para mayor seguridad, considera implementar un programa Anchor completo:

```bash
anchor init duel-arena
cd duel-arena
# Desarrollar programa con:
# - Escrow PDA (Program Derived Address)
# - Validación de juegos
# - Distribución automática
# - Sistema de fees con token burn
```

### **3. Deploy Edge Functions**
```bash
cd supabase
supabase functions deploy record-winner
supabase functions deploy verify-deposit
```

Configurar secrets:
```bash
supabase secrets set SOLANA_RPC_URL="https://mainnet.helius-rpc.com/?api-key=YOUR_KEY"
```

---

## 📊 TESTING

### **Modo Demo**
1. Conectar wallet
2. Toggle "Demo Mode" ON
3. Crear sala con cualquier monto
4. Jugar sin gastar SOL real

### **Modo Real (TESTEAR EN DEVNET PRIMERO)**
1. Cambiar RPC a devnet
2. Obtener SOL de faucet
3. Toggle "Demo Mode" OFF
4. Crear y jugar con SOL de testnet

### **Producción MAINNET**
1. Verificar PLATFORM_FEE_WALLET actualizado
2. Probar con montos pequeños primero
3. Monitorear transacciones
4. Verificar distribución de fees

---

## 🐛 TROUBLESHOOTING

### **"Insufficient funds"**
- Verificar balance de SOL
- Necesitas SOL + fee de transacción (~0.001 SOL)

### **"Transaction failed"**
- Verificar conexión a Helius RPC
- Revisar API key de Helius
- Comprobar que wallet tiene fondos

### **"Deposit failed"**
- Usuario canceló transacción en Phantom
- Network congestion (reintentar)
- RPC endpoint caído (cambiar endpoint)

### **Edge functions no funcionan**
- Verificar secrets en Supabase
- Deploy las funciones
- Revisar logs en dashboard

---

## 🔗 RECURSOS

### **Helius RPC**
- Dashboard: https://dashboard.helius.dev
- Docs: https://docs.helius.dev

### **Solana**
- Explorer: https://explorer.solana.com
- Docs: https://docs.solana.com

### **Supabase**
- Dashboard: https://supabase.com/dashboard
- Edge Functions: https://supabase.com/docs/guides/functions

---

## ⚡ COMANDOS ÚTILES

```bash
# Instalar dependencias
npm install

# Ejecutar en desarrollo
npm run dev

# Build para producción
npm run build

# Preview build
npm run preview

# Linter
npm run lint
```

---

## 📝 NOTAS IMPORTANTES

1. **NUNCA** commits el `.env` con keys reales
2. **SIEMPRE** prueba en devnet antes de mainnet
3. **VERIFICA** la wallet de plataforma antes de deploy
4. **MONITOREA** las transacciones después del lanzamiento
5. **MANTÉN** un registro de transacciones para debugging

---

## ✨ CARACTERÍSTICAS ADICIONALES IMPLEMENTADAS

- Toggle demo/real en CreateChallenge
- Balance display en tiempo real
- Validación de saldo antes de apostar
- Mensajes de confirmación claros
- Soporte para múltiples wallets (Phantom, Solflare, Backpack)
- Sistema de escrow determinístico
- Distribución automática de premios
- Sistema de reembolsos para juegos cancelados

---

## 🎯 ESTADO ACTUAL

✅ **Listo para testing en MAINNET con Demo Mode**
⚠️ **Requiere actualizar PLATFORM_FEE_WALLET antes de modo real**
⚠️ **Requiere deploy de Edge Functions para producción**

---

**¡Proyecto configurado y listo para MAINNET!** 🚀
