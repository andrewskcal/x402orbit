import { Connection, PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';

/**
 * Utility script para verificar configuración de Solana MAINNET
 * Ejecutar con: npx ts-node scripts/check-setup.ts
 */

const RPC_URL = process.env.VITE_SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com';
const PLATFORM_WALLET = 'YOUR_PLATFORM_WALLET_ADDRESS_HERE'; // Actualizar esto

async function checkSetup() {
  console.log('🔍 Verificando configuración de Solana MAINNET...\n');

  // 1. Verificar conexión RPC
  console.log('1️⃣ Verificando conexión RPC...');
  console.log(`   URL: ${RPC_URL}`);
  
  try {
    const connection = new Connection(RPC_URL, 'confirmed');
    const version = await connection.getVersion();
    console.log(`   ✅ Conectado - Versión: ${version['solana-core']}\n`);
  } catch (error) {
    console.log(`   ❌ Error de conexión: ${error}\n`);
    return;
  }

  // 2. Verificar Platform Wallet
  console.log('2️⃣ Verificando Platform Wallet...');
  
  if (PLATFORM_WALLET === 'YOUR_PLATFORM_WALLET_ADDRESS_HERE') {
    console.log('   ⚠️  Platform wallet no configurada');
    console.log('   📝 Actualizar en src/lib/solana.ts línea 13\n');
  } else {
    try {
      const publicKey = new PublicKey(PLATFORM_WALLET);
      const connection = new Connection(RPC_URL, 'confirmed');
      const balance = await connection.getBalance(publicKey);
      
      console.log(`   ✅ Wallet válida: ${PLATFORM_WALLET}`);
      console.log(`   💰 Balance: ${(balance / LAMPORTS_PER_SOL).toFixed(4)} SOL\n`);
    } catch (error) {
      console.log(`   ❌ Wallet inválida: ${error}\n`);
    }
  }

  // 3. Verificar variables de entorno
  console.log('3️⃣ Verificando variables de entorno...');
  
  const envVars = [
    'VITE_SOLANA_RPC_URL',
    'VITE_SOLANA_NETWORK',
    'VITE_SUPABASE_URL',
    'VITE_SUPABASE_PUBLISHABLE_KEY'
  ];

  let allSet = true;
  envVars.forEach(varName => {
    const value = process.env[varName];
    if (value) {
      console.log(`   ✅ ${varName}: Set`);
    } else {
      console.log(`   ❌ ${varName}: Not set`);
      allSet = false;
    }
  });

  if (!allSet) {
    console.log('\n   ⚠️  Algunas variables no están configuradas');
    console.log('   📝 Revisar archivo .env\n');
  } else {
    console.log('   ✅ Todas las variables configuradas\n');
  }

  // 4. Resumen
  console.log('📊 RESUMEN:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('Network: MAINNET');
  console.log(`RPC: ${RPC_URL}`);
  console.log(`Platform Wallet: ${PLATFORM_WALLET}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  // 5. Próximos pasos
  console.log('🚀 PRÓXIMOS PASOS:');
  console.log('1. Actualizar PLATFORM_FEE_WALLET en src/lib/solana.ts');
  console.log('2. Probar en modo Demo primero');
  console.log('3. Hacer transacción de prueba pequeña en modo Real');
  console.log('4. Monitorear transacciones en https://explorer.solana.com\n');
}

// Ejecutar verificación
checkSetup().catch(console.error);
