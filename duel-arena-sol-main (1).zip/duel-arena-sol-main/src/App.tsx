import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { WalletProvider } from "@/components/WalletProvider";
import { Footer } from "@/components/Footer";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Header } from "@/components/Header";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Admin from "./pages/Admin";
import Matchmaking from "./pages/Matchmaking";
import CreateChallenge from "./pages/CreateChallenge";
import AcceptChallenge from "./pages/AcceptChallenge";
import Game from "./pages/Game";
import RecentGames from "./pages/RecentGames";
import MyGames from "./pages/MyGames";
import Token from "./pages/Token";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <WalletProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <SidebarProvider>
            <div className="flex min-h-screen w-full">
              <AppSidebar />
              <main className="flex-1 flex flex-col">
                <Header />
                <Routes>
                  <Route path="/" element={<Index />} />
                  <Route path="/auth" element={<Auth />} />
                  <Route path="/admin" element={<Admin />} />
                  <Route path="/matchmaking" element={<Matchmaking />} />
                  <Route path="/recent-games" element={<RecentGames />} />
                  <Route path="/my-games" element={<MyGames />} />
                  <Route path="/token" element={<Token />} />
                  <Route path="/create" element={<CreateChallenge />} />
                  <Route path="/challenge/:challengeId" element={<AcceptChallenge />} />
                  <Route path="/game/:challengeId" element={<Game />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
                <Footer />
              </main>
            </div>
          </SidebarProvider>
        </BrowserRouter>
      </TooltipProvider>
    </WalletProvider>
  </QueryClientProvider>
);

export default App;
