import { Link, useLocation, useNavigate } from "react-router-dom";
import { Hand, Coins, Dices, Crown, Users, Grid3x3, CircleDot, TrendingUp as CardIcon, Hash, Home, Trophy, Plus, Rocket } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { toast } from "sonner";
import xLogoHeader from '@/assets/x-logo-white.png';

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";

const mainNav = [
  { title: "Home", url: "/", icon: Home },
  { title: "Browse Rooms", url: "/matchmaking", icon: Trophy },
  { title: "$DUEL", url: "/token", icon: Coins },
  { title: "Recent", url: "/recent-games", icon: Trophy },
];

const pvpGames = [
  { title: "Chess", url: "/create?game=chess", icon: Crown },
  { title: "UNO", url: "/create?game=uno", icon: Users },
  { title: "RPS", url: "/create?game=rock-paper-scissors", icon: Hand },
  { title: "Tic Tac Toe", url: "/create?game=tic-tac-toe", icon: Grid3x3 },
  { title: "Connect Four", url: "/create?game=connect-four", icon: CircleDot },
];

const instantGames = [
  { title: "Coin Flip", url: "/create?game=coin-flip", icon: Coins },
  { title: "Dice Roll", url: "/create?game=dice-roll", icon: Dices },
  { title: "Higher Lower", url: "/create?game=higher-lower", icon: CardIcon },
  { title: "Number Duel", url: "/create?game=number-duel", icon: Hash },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const navigate = useNavigate();
  const collapsed = state === 'collapsed';

  const twitterUrl = "https://twitter.com/duelarenaonsol";

  return (
    <Sidebar className={collapsed ? "w-14" : "w-60"}>
      <SidebarContent>
        {/* Main Navigation */}
        <SidebarGroup>
          <SidebarGroupLabel className={collapsed ? "sr-only" : ""}>
            NAVIGATION
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNav.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      className="hover:bg-muted/50"
                      activeClassName="bg-muted text-primary font-medium"
                    >
                      <item.icon className="h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Create Room CTA */}
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <Link
                    to="/create"
                    className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90 font-bold"
                  >
                    <Plus className="h-4 w-4" />
                    {!collapsed && <span>CREATE ROOM</span>}
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* PVP Games */}
        {!collapsed && (
          <SidebarGroup>
            <SidebarGroupLabel>PVP GAMES</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {pvpGames.map((game) => (
                  <SidebarMenuItem key={game.title}>
                    <SidebarMenuButton asChild>
                      <Link to={game.url} className="hover:bg-muted/50">
                        <game.icon className="h-4 w-4" />
                        <span>{game.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Instant Games */}
        {!collapsed && (
          <SidebarGroup>
            <SidebarGroupLabel>INSTANT</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {instantGames.map((game) => (
                  <SidebarMenuItem key={game.title}>
                    <SidebarMenuButton asChild>
                      <Link to={game.url} className="hover:bg-muted/50">
                        <game.icon className="h-4 w-4" />
                        <span>{game.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      {/* Footer - Social */}
      <SidebarFooter>
        {!collapsed && (
          <div className="space-y-3 p-2">
            {/* X Social Link */}
            <a
              href={twitterUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full p-2 rounded-md hover:bg-muted transition-all text-sm font-medium text-muted-foreground hover:text-foreground"
              aria-label="Follow on X"
            >
              <img src={xLogoHeader} alt="X" className="w-4 h-4" />
              <span>Follow</span>
            </a>
          </div>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}
