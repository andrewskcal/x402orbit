import { Link } from 'react-router-dom';
import { Shield, TrendingUp, Coins } from 'lucide-react';
import duelArenaLogo from '@/assets/duel-arena-main-logo.png';
import xLogo from '@/assets/x-logo.png';

export const Footer = () => {
  const xUrl = "https://twitter.com/duelarenaonsol";

  return (
    <footer className="border-t border-border bg-card/50 mt-auto">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Section */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2.5 group">
              <div className="relative">
                <div className="absolute inset-0 bg-primary/10 rounded-lg blur-sm group-hover:bg-primary/20 transition-all" />
                <img src={duelArenaLogo} alt="Duel Arena" className="relative w-12 h-12 group-hover:scale-105 transition-transform" />
              </div>
              <span className="text-xl font-bold text-foreground tracking-tight">
                Duel Arena
              </span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Competitive gaming on Solana. Play, compete, and earn with complete transparency.
            </p>
            <a
              href={xUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
            >
              <img src={xLogo} alt="X" className="w-4 h-4" />
              Follow us on X
            </a>
          </div>

          {/* Platform */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-foreground">Platform</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Games
                </Link>
              </li>
              <li>
                <Link to="/matchmaking" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Matchmaking
                </Link>
              </li>
              <li>
                <Link to="/recent-games" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Recent Games
                </Link>
              </li>
              <li>
                <Link to="/admin" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Test Games
                </Link>
              </li>
            </ul>
          </div>

          {/* Token */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-foreground">$DUEL Token</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/token" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Tokenomics
                </Link>
              </li>
              <li>
                <a 
                  href="https://pump.fun" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  Trade on Pump.fun
                </a>
              </li>
            </ul>
          </div>

          {/* Features */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-foreground">Features</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Shield className="w-4 h-4 text-primary" />
                Blockchain Verified
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <TrendingUp className="w-4 h-4 text-primary" />
                3.75% Platform Fee
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Coins className="w-4 h-4 text-primary" />
                Daily Token Burn
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-border/50 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground text-center md:text-left">
            © {new Date().getFullYear()} Duel Arena. All rights reserved. Built on Solana.
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span>Cryptocurrency investments carry risk.</span>
            <span className="hidden md:inline">•</span>
            <span>Always DYOR before playing.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
