import { LucideIcon } from "lucide-react";

interface GameCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  onClick: () => void;
}

export const GameCard = ({ title, description, icon: Icon, onClick }: GameCardProps) => {
  return (
    <div
      className="group relative overflow-hidden rounded-xl border-2 border-border bg-card hover:border-primary/50 transition-all duration-300 cursor-pointer hover:scale-[1.02]"
      onClick={onClick}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.08] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

      <div className="relative p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="w-14 h-14 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
            <Icon className="w-7 h-7 text-primary" />
          </div>
          <div className="px-3 py-1.5 rounded-lg bg-muted text-xs font-bold text-foreground border border-border">
            1v1
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-xl font-black text-foreground tracking-tight">{title}</h3>
          <p className="text-sm text-muted-foreground font-medium">{description}</p>
        </div>

        <div className="flex items-center justify-between mt-6 pt-4 border-t border-border/50">
          <span className="text-xs text-muted-foreground font-bold">MIN 0.000001 SOL</span>
          <div className="flex items-center gap-1 text-primary font-bold text-sm group-hover:translate-x-1 transition-transform">
            PLAY
            <span className="text-lg">→</span>
          </div>
        </div>
      </div>
    </div>
  );
};
