import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { SidebarTrigger } from '@/components/ui/sidebar';
import duelArenaLogo from '@/assets/duel-arena-main-logo.png';
import xLogoHeader from '@/assets/x-logo-white.png';

export const Header = () => {
  const { user, signOut } = useAuth();
  const twitterUrl = "https://twitter.com/duelarenaonsol";
  

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-background/98 border-b border-border shadow-sm">
      <div className="container mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Left: Sidebar Toggle & Logo */}
        <div className="flex items-center gap-3">
          <SidebarTrigger className="lg:hidden" />
          <Link to="/" className="flex items-center gap-2.5 group flex-shrink-0">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/10 rounded-lg blur-sm group-hover:bg-primary/20 transition-all" />
              <img src={duelArenaLogo} alt="Duel Arena" className="relative w-12 h-12 group-hover:scale-105 transition-transform" />
            </div>
            <span className="text-foreground text-xl font-bold tracking-tight">Duel Arena</span>
          </Link>
        </div>

        {/* Right: Social, Auth, Wallet */}
        <div className="flex items-center gap-3 flex-shrink-0">
          <a href={twitterUrl} target="_blank" rel="noopener noreferrer" className="hidden lg:flex items-center justify-center w-9 h-9 rounded-md hover:bg-muted transition-all" aria-label="Follow on X">
            <img src={xLogoHeader} alt="X" className="w-4 h-4" />
          </a>
          
          {user && (
            <>
              <Button 
                asChild
                variant="ghost" 
                size="sm" 
                className="hidden sm:flex h-9 px-3 text-sm text-muted-foreground hover:text-foreground hover:bg-muted"
              >
                <Link to="/my-games">My Games</Link>
              </Button>
              <Button 
                onClick={signOut} 
                variant="ghost" 
                size="sm" 
                className="hidden sm:flex h-9 px-3 text-sm text-muted-foreground hover:text-foreground hover:bg-muted"
              >
                Sign Out
              </Button>
            </>
          )}
          
          <div className="wallet-adapter-button-container [&_button]:!h-9 [&_button]:!text-sm [&_button]:!px-4 [&_button]:!py-0 [&_button]:!min-w-[120px]">
            <WalletMultiButton />
          </div>
        </div>
      </div>
    </header>
  );
};