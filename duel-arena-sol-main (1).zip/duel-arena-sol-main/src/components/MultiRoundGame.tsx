import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trophy } from 'lucide-react';

interface MultiRoundGameProps {
  totalRounds: number;
  children: (props: {
    onRoundEnd: (won: boolean) => void;
    currentRound: number;
  }) => React.ReactNode;
  onMatchEnd: (won: boolean) => void;
  gameName: string;
}

export const MultiRoundGame = ({ 
  totalRounds, 
  children, 
  onMatchEnd,
  gameName 
}: MultiRoundGameProps) => {
  const [playerWins, setPlayerWins] = useState(0);
  const [opponentWins, setOpponentWins] = useState(0);
  const [currentRound, setCurrentRound] = useState(1);

  const roundsToWin = Math.ceil(totalRounds / 2);

  const handleRoundEnd = (won: boolean) => {
    const newPlayerWins = won ? playerWins + 1 : playerWins;
    const newOpponentWins = won ? opponentWins : opponentWins + 1;

    setPlayerWins(newPlayerWins);
    setOpponentWins(newOpponentWins);

    // Check if someone won the match
    if (newPlayerWins >= roundsToWin) {
      setTimeout(() => onMatchEnd(true), 1500);
      return;
    }
    
    if (newOpponentWins >= roundsToWin) {
      setTimeout(() => onMatchEnd(false), 1500);
      return;
    }

    // Move to next round
    setTimeout(() => {
      setCurrentRound(currentRound + 1);
    }, 2000);
  };

  return (
    <div className="space-y-4">
      {/* Round Progress Card */}
      <Card className="border-2 border-primary/30 bg-gradient-to-br from-primary/5 to-secondary/5">
        <CardHeader className="pb-3">
          <CardTitle className="text-center text-lg flex items-center justify-center gap-2">
            <Trophy className="w-5 h-5 text-primary" />
            <span>Best of {totalRounds} - First to {roundsToWin}</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary">{playerWins}</div>
              <div className="text-xs text-muted-foreground">Your Wins</div>
            </div>
            <div className="space-y-2">
              <div className="text-sm text-muted-foreground">Round {currentRound}</div>
              <div className="h-1 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${(currentRound / totalRounds) * 100}%` }}
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-secondary">{opponentWins}</div>
              <div className="text-xs text-muted-foreground">Opp. Wins</div>
            </div>
          </div>
          
          {/* Visual round indicators */}
          <div className="flex justify-center gap-2">
            {Array.from({ length: totalRounds }).map((_, i) => {
              const roundNum = i + 1;
              let status: 'future' | 'current' | 'player-won' | 'opponent-won' = 'future';
              
              if (roundNum < currentRound) {
                // Determine who won this past round
                const playerWinsAtRound = Math.min(playerWins, roundNum);
                const opponentWinsAtRound = Math.min(opponentWins, roundNum);
                if (playerWinsAtRound > i) status = 'player-won';
                else if (opponentWinsAtRound > i) status = 'opponent-won';
              } else if (roundNum === currentRound) {
                status = 'current';
              }
              
              return (
                <div
                  key={i}
                  className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-bold transition-all ${
                    status === 'current'
                      ? 'border-primary bg-primary text-primary-foreground scale-110 animate-pulse'
                      : status === 'player-won'
                      ? 'border-primary bg-primary/20 text-primary'
                      : status === 'opponent-won'
                      ? 'border-secondary bg-secondary/20 text-secondary'
                      : 'border-muted bg-muted text-muted-foreground'
                  }`}
                >
                  {roundNum}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Game Component */}
      {children({ onRoundEnd: handleRoundEnd, currentRound })}
    </div>
  );
};
