import { useState, useEffect, useCallback } from 'react';
import { Chess, Square } from 'chess.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { Clock, Trophy, Flag } from 'lucide-react';

interface ChessGameState {
  fen: string;
  moveHistory: string[];
  currentTurn: 'w' | 'b';
  whiteTime: number; // in seconds
  blackTime: number;
  lastMoveTimestamp: number;
  gameStatus: 'active' | 'checkmate' | 'draw' | 'stalemate' | 'timeout';
  winner?: 'white' | 'black';
}

interface ChessGameProps {
  onGameEnd: (won: boolean) => void;
  isCreator: boolean;
  challengeId: string;
}

const INITIAL_TIME = 600; // 10 minutes per player in seconds

export const ChessGame = ({ onGameEnd, isCreator, challengeId }: ChessGameProps) => {
  const [game, setGame] = useState(new Chess());
  const [gameState, setGameState] = useState<ChessGameState | null>(null);
  const [playerColor] = useState<'white' | 'black'>(isCreator ? 'white' : 'black');
  const [whiteTime, setWhiteTime] = useState(INITIAL_TIME);
  const [blackTime, setBlackTime] = useState(INITIAL_TIME);
  const [loading, setLoading] = useState(true);
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [possibleMoves, setPossibleMoves] = useState<Square[]>([]);
  
  // Check if this is a test game (no database sync needed)
  const isTestGame = challengeId.startsWith('test-');

  const isMyTurn = gameState?.currentTurn === (playerColor === 'white' ? 'w' : 'b');
  const myTime = playerColor === 'white' ? whiteTime : blackTime;
  const opponentTime = playerColor === 'white' ? blackTime : whiteTime;

  // Piece symbols - use same outline symbols for both colors, differentiated by color only
  const pieceSymbols: { [key: string]: string } = {
    'wp': '♙', 'wn': '♘', 'wb': '♗', 'wr': '♖', 'wq': '♕', 'wk': '♔',
    'bp': '♙', 'bn': '♘', 'bb': '♗', 'br': '♖', 'bq': '♕', 'bk': '♔',
  };

  // Initialize or fetch game state
  useEffect(() => {
    if (isTestGame) {
      // For test games, initialize locally without database
      const initialState: ChessGameState = {
        fen: new Chess().fen(),
        moveHistory: [],
        currentTurn: 'w',
        whiteTime: INITIAL_TIME,
        blackTime: INITIAL_TIME,
        lastMoveTimestamp: Date.now(),
        gameStatus: 'active',
      };
      updateLocalState(initialState);
      setLoading(false);
      return;
    }

    initializeOrFetchGame();

    const channel = supabase
      .channel(`chess-game-${challengeId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'challenges',
          filter: `id=eq.${challengeId}`,
        },
        (payload) => {
          console.log('[Chess] Real-time update received:', payload);
          const newGameState = payload.new.game_state as unknown as ChessGameState;
          if (newGameState?.fen) {
            console.log('[Chess] Updating to new state:', newGameState);
            updateLocalState(newGameState);
          }
        }
      )
      .subscribe((status) => {
        console.log('[Chess] Subscription status:', status);
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [challengeId, isCreator, isTestGame]);

  // Timer countdown
  useEffect(() => {
    if (!gameState || gameState.gameStatus !== 'active') return;

    const interval = setInterval(() => {
      const now = Date.now();
      const elapsed = Math.floor((now - gameState.lastMoveTimestamp) / 1000);

      if (gameState.currentTurn === 'w') {
        const newWhiteTime = Math.max(0, gameState.whiteTime - elapsed);
        setWhiteTime(newWhiteTime);
        setBlackTime(gameState.blackTime);

        if (newWhiteTime === 0 && isMyTurn) {
          handleTimeout();
        }
      } else {
        const newBlackTime = Math.max(0, gameState.blackTime - elapsed);
        setBlackTime(newBlackTime);
        setWhiteTime(gameState.whiteTime);

        if (newBlackTime === 0 && isMyTurn) {
          handleTimeout();
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [gameState, isMyTurn]);

  const initializeOrFetchGame = async () => {
    console.log('[Chess] Fetching game state for challenge:', challengeId);
    
    const { data: challenge, error } = await supabase
      .from('challenges')
      .select('game_state')
      .eq('id', challengeId)
      .single();

    if (error) {
      console.error('[Chess] Error fetching challenge:', error);
      setLoading(false);
      return;
    }

    const existingState = challenge?.game_state as unknown as ChessGameState | null;
    console.log('[Chess] Existing state:', existingState);

    if (existingState?.fen) {
      console.log('[Chess] Found existing state, using it');
      updateLocalState(existingState);
      setLoading(false);
    } else if (isCreator) {
      console.log('[Chess] Creator initializing new game');
      const initialState: ChessGameState = {
        fen: new Chess().fen(),
        moveHistory: [],
        currentTurn: 'w',
        whiteTime: INITIAL_TIME,
        blackTime: INITIAL_TIME,
        lastMoveTimestamp: Date.now(),
        gameStatus: 'active',
      };

      const { error: updateError } = await supabase
        .from('challenges')
        .update({ game_state: initialState as any })
        .eq('id', challengeId);

      if (updateError) {
        console.error('[Chess] Error initializing game:', updateError);
      } else {
        console.log('[Chess] Game initialized successfully');
      }

      updateLocalState(initialState);
      setLoading(false);
    } else {
      console.log('[Chess] Non-creator waiting for game initialization...');
      // Non-creator should wait for real-time update
    }
  };

  const updateLocalState = (state: ChessGameState) => {
    setGameState(state);
    const chessInstance = new Chess(state.fen);
    setGame(chessInstance);

    // Update timers
    const now = Date.now();
    const elapsed = Math.floor((now - state.lastMoveTimestamp) / 1000);

    if (state.currentTurn === 'w') {
      setWhiteTime(Math.max(0, state.whiteTime - elapsed));
      setBlackTime(state.blackTime);
    } else {
      setBlackTime(Math.max(0, state.blackTime - elapsed));
      setWhiteTime(state.whiteTime);
    }

    // Check game end conditions
    if (state.gameStatus !== 'active') {
      handleGameEnd(state);
    }
  };

  const handleGameEnd = (state: ChessGameState) => {
    if (state.gameStatus === 'checkmate') {
      const playerWon = state.winner === playerColor;
      setTimeout(() => onGameEnd(playerWon), 2000);
    } else if (state.gameStatus === 'timeout') {
      const playerWon = state.winner === playerColor;
      setTimeout(() => onGameEnd(playerWon), 2000);
    } else if (state.gameStatus === 'draw' || state.gameStatus === 'stalemate') {
      toast.info('Game is a draw, creating new challenge...');
      setTimeout(() => window.location.reload(), 2000);
    }
  };

  const handleTimeout = async () => {
    if (!gameState) return;

    const winner = playerColor === 'white' ? 'black' : 'white';
    const updatedState: ChessGameState = {
      ...gameState,
      gameStatus: 'timeout',
      winner,
    };

    await supabase
      .from('challenges')
      .update({ game_state: updatedState as any })
      .eq('id', challengeId);

    toast.error('Time out! You lost.');
  };

  const handleSquareClick = (square: Square) => {
    if (!gameState || !isMyTurn || gameState.gameStatus !== 'active') {
      return;
    }

    // If no piece is selected, select this square if it has our piece
    if (!selectedSquare) {
      const piece = game.get(square);
      if (piece && piece.color === (playerColor === 'white' ? 'w' : 'b')) {
        setSelectedSquare(square);
        const moves = game.moves({ square, verbose: true });
        setPossibleMoves(moves.map(m => m.to as Square));
      }
      return;
    }

    // If clicking the same square, deselect
    if (selectedSquare === square) {
      setSelectedSquare(null);
      setPossibleMoves([]);
      return;
    }

    // Try to make the move
    makeMove(selectedSquare, square);
  };

  const makeMove = async (from: Square, to: Square) => {
    if (!gameState || !isMyTurn || gameState.gameStatus !== 'active') {
      toast.error("It's not your turn!");
      return;
    }

    const gameCopy = new Chess(gameState.fen);

    try {
      const move = gameCopy.move({
        from,
        to,
        promotion: 'q',
      });

      if (!move) {
        toast.error('Invalid move!');
        setSelectedSquare(null);
        setPossibleMoves([]);
        return;
      }

      const now = Date.now();
      const elapsed = Math.floor((now - gameState.lastMoveTimestamp) / 1000);

      const newWhiteTime = gameState.currentTurn === 'w' 
        ? Math.max(0, gameState.whiteTime - elapsed)
        : gameState.whiteTime;
      const newBlackTime = gameState.currentTurn === 'b'
        ? Math.max(0, gameState.blackTime - elapsed)
        : gameState.blackTime;

      let gameStatus: ChessGameState['gameStatus'] = 'active';
      let winner: 'white' | 'black' | undefined = undefined;

      if (gameCopy.isCheckmate()) {
        gameStatus = 'checkmate';
        winner = gameCopy.turn() === 'w' ? 'black' : 'white';
        toast.success(winner === playerColor ? 'Checkmate! You won!' : 'Checkmate! You lost.');
      } else if (gameCopy.isDraw()) {
        gameStatus = 'draw';
        toast.info('Draw!');
      } else if (gameCopy.isStalemate()) {
        gameStatus = 'stalemate';
        toast.info('Stalemate!');
      } else if (gameCopy.isCheck()) {
        toast.warning('Check!');
      }

      const updatedState: ChessGameState = {
        fen: gameCopy.fen(),
        moveHistory: [...gameState.moveHistory, move.san],
        currentTurn: gameCopy.turn(),
        whiteTime: newWhiteTime,
        blackTime: newBlackTime,
        lastMoveTimestamp: now,
        gameStatus,
        winner,
      };

      if (isTestGame) {
        updateLocalState(updatedState);
      } else {
        const { error } = await supabase
          .from('challenges')
          .update({ game_state: updatedState as any })
          .eq('id', challengeId);

        if (error) {
          console.error('[Chess] Error updating state:', error);
          toast.error('Failed to update game state');
        }
      }

      setSelectedSquare(null);
      setPossibleMoves([]);
    } catch (error) {
      console.error('[Chess] Invalid move error:', error);
      toast.error('Invalid move!');
      setSelectedSquare(null);
      setPossibleMoves([]);
    }
  };

  const renderBoard = () => {
    const board = game.board();
    const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
    const ranks = playerColor === 'white' ? [8, 7, 6, 5, 4, 3, 2, 1] : [1, 2, 3, 4, 5, 6, 7, 8];

    return (
      <div className="inline-block border-4 border-border/50 rounded-lg overflow-hidden shadow-2xl">
        {ranks.map((rank) => (
          <div key={rank} className="flex">
            {files.map((file, fileIndex) => {
              const square = `${file}${rank}` as Square;
              const piece = game.get(square);
              const isLight = (rank + fileIndex) % 2 === 0;
              const isSelected = selectedSquare === square;
              const isPossibleMove = possibleMoves.includes(square);

              return (
                <div
                  key={square}
                  onClick={() => handleSquareClick(square)}
                  className={`w-16 h-16 flex items-center justify-center text-5xl cursor-pointer transition-colors select-none relative ${
                    isLight ? 'bg-[#f0d9b5]' : 'bg-[#b58863]'
                  } ${isSelected ? 'bg-yellow-300/50' : ''} ${
                    isPossibleMove ? 'bg-green-300/30' : ''
                  } hover:brightness-95`}
                >
                  {piece && (
                    <span 
                      style={{
                        color: piece.color === 'w' ? '#ffffff' : '#1a1a1a',
                        textShadow: piece.color === 'w' 
                          ? '0 0 3px #000, 0 0 5px #000, 1px 1px 2px #000' 
                          : '0 0 2px rgba(255,255,255,0.3)'
                      }}
                    >
                      {pieceSymbols[`${piece.color}${piece.type}`]}
                    </span>
                  )}
                  {isPossibleMove && !piece && (
                    <div className="absolute w-3 h-3 bg-green-500/60 rounded-full" />
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    );
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getTimeColor = (seconds: number): string => {
    if (seconds <= 30) return 'text-red-500';
    if (seconds <= 60) return 'text-yellow-500';
    return 'text-foreground';
  };

  if (loading || !gameState) {
    return <div className="text-center">Loading chess game...</div>;
  }

  return (
    <Card className="border-border bg-card shadow-2xl">
      <CardHeader className="pb-4">
        <CardTitle className="text-center text-2xl bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
          Chess Battle
        </CardTitle>
        <div className="flex items-center justify-between pt-2">
          <Badge variant={playerColor === 'white' ? 'default' : 'secondary'} className="text-xs">
            You: {playerColor === 'white' ? '♔ White' : '♚ Black'}
          </Badge>
          <div className={`px-4 py-2 rounded-lg font-bold text-sm ${
            isMyTurn 
              ? 'bg-primary text-primary-foreground animate-pulse shadow-lg' 
              : 'bg-muted text-muted-foreground'
          }`}>
            {isMyTurn ? '⚡ YOUR TURN' : "⏳ OPPONENT'S TURN"}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Opponent Timer (Top) */}
        <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg border border-border/50">
          <div className="flex items-center gap-2">
            <div className="text-2xl">{playerColor === 'white' ? '♚' : '♔'}</div>
            <span className="text-sm font-medium">Opponent</span>
          </div>
          <div className={`flex items-center gap-2 ${getTimeColor(opponentTime)} font-mono text-lg font-bold`}>
            <Clock className="w-4 h-4" />
            {formatTime(opponentTime)}
          </div>
        </div>

        {/* Chessboard */}
        <div className="flex justify-center">
          {renderBoard()}
        </div>

        {/* Player Timer (Bottom) */}
        <div className={`flex items-center justify-between p-3 rounded-lg border-2 ${
          isMyTurn ? 'bg-primary/10 border-primary/50' : 'bg-muted/50 border-border/50'
        }`}>
          <div className="flex items-center gap-2">
            <div className="text-2xl">{playerColor === 'white' ? '♔' : '♚'}</div>
            <span className="text-sm font-medium">You</span>
          </div>
          <div className={`flex items-center gap-2 ${getTimeColor(myTime)} font-mono text-xl font-bold`}>
            <Clock className="w-5 h-5" />
            {formatTime(myTime)}
          </div>
        </div>

        {/* Game Status */}
        {gameState.gameStatus !== 'active' && (
          <div className="p-4 bg-accent/20 border border-accent rounded-lg text-center">
            <div className="flex items-center justify-center gap-2 text-lg font-bold">
              {gameState.gameStatus === 'checkmate' && (
                <>
                  <Trophy className="w-5 h-5" />
                  <span>Checkmate! {gameState.winner === playerColor ? 'You Won!' : 'You Lost!'}</span>
                </>
              )}
              {gameState.gameStatus === 'timeout' && (
                <>
                  <Flag className="w-5 h-5" />
                  <span>Time Out! {gameState.winner === playerColor ? 'You Won!' : 'You Lost!'}</span>
                </>
              )}
              {(gameState.gameStatus === 'draw' || gameState.gameStatus === 'stalemate') && (
                <span>Draw - {gameState.gameStatus === 'stalemate' ? 'Stalemate' : 'Draw'}</span>
              )}
            </div>
          </div>
        )}

        {/* Move History */}
        <div className="space-y-2">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <span>Move History</span>
            <Badge variant="outline" className="text-xs">{gameState.moveHistory.length} moves</Badge>
          </h3>
          <div className="h-32 overflow-y-auto bg-muted/30 p-3 rounded-lg border border-border/30 text-xs font-mono">
            {gameState.moveHistory.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No moves yet</p>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {gameState.moveHistory.map((move, index) => (
                  <div key={index} className="flex items-center gap-1">
                    <span className="text-muted-foreground font-semibold">
                      {Math.floor(index / 2) + 1}.
                    </span>
                    <span className="font-medium">{move}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};