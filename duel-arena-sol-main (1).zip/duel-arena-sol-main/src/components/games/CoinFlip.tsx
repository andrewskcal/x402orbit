import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Coins, Loader2, Zap, Trophy, Skull } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useWallet } from "@solana/wallet-adapter-react";

type Choice = "heads" | "tails" | null;

interface CoinFlipProps {
  onGameEnd: (won: boolean) => void;
  challengeId: string;
  isCreator: boolean;
}

export const CoinFlip = ({ onGameEnd, challengeId, isCreator }: CoinFlipProps) => {
  const { publicKey } = useWallet();
  const [playerChoice, setPlayerChoice] = useState<Choice>(null);
  const [opponentChoice, setOpponentChoice] = useState<Choice>(null);
  const [result, setResult] = useState<Choice>(null);
  const [waitingForOpponent, setWaitingForOpponent] = useState(false);
  const [roundProcessed, setRoundProcessed] = useState(false);
  const [isTie, setIsTie] = useState(false);
  const [countdown, setCountdown] = useState(30);
  const [gameStartTime, setGameStartTime] = useState<number | null>(null);

  // Initialize game start time
  useEffect(() => {
    if (!challengeId) return;

    const initGameTime = async () => {
      const { data } = await supabase.from("challenges").select("game_state").eq("id", challengeId).single();

      const gameState = data?.game_state as any;

      if (!gameState?.startTime) {
        // Set start time if it doesn't exist
        const startTime = Date.now();
        await supabase
          .from("challenges")
          .update({
            game_state: { startTime },
          })
          .eq("id", challengeId);
        setGameStartTime(startTime);
      } else {
        setGameStartTime(gameState.startTime);
      }
    };

    initGameTime();
  }, [challengeId]);

  // Countdown timer
  useEffect(() => {
    if (!gameStartTime || result || isTie) return;

    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - gameStartTime) / 1000);
      const remaining = Math.max(0, 30 - elapsed);
      setCountdown(remaining);

      if (remaining === 0) {
        clearInterval(timer);
        // Time's up - check who made a choice
        checkTimeout();
      }
    }, 100);

    return () => clearInterval(timer);
  }, [gameStartTime, result, isTie, playerChoice]);

  const checkTimeout = async () => {
    const { data } = await supabase.from("challenges").select("game_state").eq("id", challengeId).single();

    const gameState = data?.game_state as any;
    const myRole = isCreator ? "creator" : "opponent";
    const theirRole = isCreator ? "opponent" : "creator";

    const iMadeChoice = gameState?.[myRole];
    const theyMadeChoice = gameState?.[theirRole];

    // If I made a choice but opponent didn't, I win
    if (iMadeChoice && !theyMadeChoice) {
      onGameEnd(true);
    }
    // If opponent made a choice but I didn't, I lose
    else if (!iMadeChoice && theyMadeChoice) {
      onGameEnd(false);
    }
    // If neither made a choice, creator wins by default
    else if (!iMadeChoice && !theyMadeChoice) {
      onGameEnd(isCreator);
    }
  };

  useEffect(() => {
    if (!challengeId) return;

    const channel = supabase
      .channel(`game-${challengeId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "challenges",
          filter: `id=eq.${challengeId}`,
        },
        async (payload) => {
          const gameState = payload.new.game_state as any;
          if (!gameState) return;

          const myRole = isCreator ? "creator" : "opponent";
          const theirRole = isCreator ? "opponent" : "creator";

          // Check if BOTH players have made their choices and coin hasn't been flipped yet
          if (gameState[myRole] && gameState[theirRole] && !roundProcessed && !gameState.coinResult) {
            setOpponentChoice(gameState[theirRole]);
            setWaitingForOpponent(false);

            // Check for tie BEFORE flipping the coin
            if (gameState[myRole] === gameState[theirRole]) {
              setIsTie(true);
              setRoundProcessed(true);

              // Reset after showing tie message
              setTimeout(() => {
                resetRound();
              }, 3000);
              return;
            }

            setRoundProcessed(true);

            // Only the CREATOR flips the coin and stores the result
            if (isCreator) {
              setTimeout(async () => {
                const coinResult: Choice = Math.random() < 0.5 ? "heads" : "tails";
                console.log("Coin flipped:", coinResult);

                // Store the coin result in the database
                const { data: currentChallenge } = await supabase
                  .from("challenges")
                  .select("game_state")
                  .eq("id", challengeId)
                  .single();

                const currentState = (currentChallenge?.game_state as any) || {};

                await supabase
                  .from("challenges")
                  .update({
                    game_state: { ...currentState, coinResult },
                  })
                  .eq("id", challengeId);

                setResult(coinResult);

                // Determine winner after showing result
                setTimeout(() => {
                  const myChoice = gameState[myRole];
                  const won = myChoice === coinResult;
                  console.log("Creator result:", { myChoice, coinResult, won });
                  onGameEnd(won);
                }, 2500);
              }, 1500);
            }
          }

          // If the coin result has been set, show it to the opponent
          if (gameState.coinResult && !isCreator && !result) {
            console.log("Opponent received coin result:", gameState.coinResult);
            setResult(gameState.coinResult);
            setOpponentChoice(gameState[theirRole]);

            setTimeout(() => {
              const myChoice = gameState[myRole];
              const won = myChoice === gameState.coinResult;
              console.log("Opponent result:", { myChoice, coinResult: gameState.coinResult, won });
              onGameEnd(won);
            }, 2500);
          }
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [challengeId, isCreator, roundProcessed, result]);

  const resetRound = async () => {
    // Clear the game state to start a new round with new start time
    const newStartTime = Date.now();
    const { error } = await supabase
      .from("challenges")
      .update({
        game_state: { startTime: newStartTime },
      })
      .eq("id", challengeId);

    if (error) {
      console.error("Error resetting round:", error);
    }

    // Reset local state
    setPlayerChoice(null);
    setOpponentChoice(null);
    setResult(null);
    setWaitingForOpponent(false);
    setRoundProcessed(false);
    setIsTie(false);
    setGameStartTime(newStartTime);
    setCountdown(30);
  };

  const handleChoice = async (choice: Choice) => {
    if (!publicKey) return;

    setPlayerChoice(choice);
    setWaitingForOpponent(true);

    const myRole = isCreator ? "creator" : "opponent";

    // Fetch current game state first
    const { data: currentChallenge, error: fetchError } = await supabase
      .from("challenges")
      .select("game_state")
      .eq("id", challengeId)
      .maybeSingle();

    if (fetchError) {
      console.error("Error fetching game state:", fetchError);
      return;
    }

    const currentState = (currentChallenge?.game_state as any) || {};

    // Update game state with player's choice
    const { error: updateError } = await supabase
      .from("challenges")
      .update({
        game_state: { ...currentState, [myRole]: choice },
      })
      .eq("id", challengeId);

    if (updateError) {
      console.error("Error updating game state:", updateError);
    }
  };

  const getCountdownColor = () => {
    if (countdown > 20) return "text-green-500";
    if (countdown > 10) return "text-yellow-500";
    return "text-red-500";
  };

  return (
    <Card className="border-2 border-purple-500/50 bg-gradient-to-br from-slate-950 via-purple-950/20 to-slate-950 shadow-2xl shadow-purple-500/20">
      <CardHeader className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 via-pink-600/10 to-purple-600/10 animate-pulse"></div>
        <CardTitle className="text-center text-4xl font-black bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent relative z-10 tracking-wider">
          ⚡ COIN FLIP ⚡
        </CardTitle>

        {/* Countdown Timer */}
        {!result && !isTie && (
          <div className="mt-4 relative z-10">
            <div
              className={`text-center text-6xl font-black ${getCountdownColor()} transition-colors duration-300 ${countdown <= 5 ? "animate-pulse scale-110" : ""}`}
            >
              {countdown}s
            </div>
            <div className="w-full bg-slate-800 h-3 rounded-full mt-2 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  countdown > 20 ? "bg-green-500" : countdown > 10 ? "bg-yellow-500" : "bg-red-500"
                }`}
                style={{ width: `${(countdown / 30) * 100}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Turn Indicator */}
        {!result && !isTie && (
          <div
            className={`mt-4 p-4 rounded-xl border-4 text-center font-black uppercase tracking-widest text-xl relative z-10 ${
              !playerChoice
                ? "bg-purple-500/30 border-purple-400 text-purple-300 animate-pulse shadow-lg shadow-purple-500/50"
                : "bg-slate-800/50 border-yellow-500/50 text-yellow-400"
            }`}
          >
            {!playerChoice ? (
              <span className="flex items-center justify-center gap-2">
                <Zap className="w-6 h-6" />
                YOUR TURN - CHOOSE NOW!
                <Zap className="w-6 h-6" />
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">⏳ WAITING FOR OPPONENT...</span>
            )}
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-6 relative z-10">
        {isTie ? (
          <div className="text-center py-12 space-y-6 animate-pulse">
            <div className="text-8xl animate-bounce">🤝</div>
            <p className="text-4xl font-black text-yellow-400 tracking-wider">IT'S A TIE!</p>
            <p className="text-xl text-purple-300">
              Both chose <span className="uppercase font-bold text-yellow-400">{playerChoice}</span>
            </p>
            <p className="text-lg text-slate-400">Restarting in 3 seconds...</p>
          </div>
        ) : !playerChoice ? (
          <div className="grid grid-cols-2 gap-6">
            <Button
              onClick={() => handleChoice("heads")}
              className="h-40 flex flex-col gap-4 bg-gradient-to-br from-purple-600 to-purple-800 hover:from-purple-500 hover:to-purple-700 border-4 border-purple-400 hover:border-purple-300 transition-all transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/50 group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <Coins className="w-16 h-16 text-yellow-400 group-hover:rotate-12 transition-transform" />
              <span className="text-2xl font-black tracking-wider relative z-10">HEADS</span>
              <Zap className="w-6 h-6 absolute top-2 right-2 text-yellow-400 opacity-0 group-hover:opacity-100 animate-pulse" />
            </Button>
            <Button
              onClick={() => handleChoice("tails")}
              className="h-40 flex flex-col gap-4 bg-gradient-to-br from-pink-600 to-pink-800 hover:from-pink-500 hover:to-pink-700 border-4 border-pink-400 hover:border-pink-300 transition-all transform hover:scale-105 hover:shadow-2xl hover:shadow-pink-500/50 group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <Coins className="w-16 h-16 rotate-180 text-yellow-400 group-hover:-rotate-[168deg] transition-transform" />
              <span className="text-2xl font-black tracking-wider relative z-10">TAILS</span>
              <Zap className="w-6 h-6 absolute top-2 right-2 text-yellow-400 opacity-0 group-hover:opacity-100 animate-pulse" />
            </Button>
          </div>
        ) : waitingForOpponent ? (
          <div className="text-center py-12 space-y-6">
            <div className="relative inline-block">
              <Loader2 className="w-20 h-20 animate-spin text-purple-400" />
              <Zap className="w-8 h-8 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-yellow-400 animate-pulse" />
            </div>
            <div className="space-y-3">
              <p className="text-2xl font-bold text-purple-300">YOU CHOSE:</p>
              <div
                className={`inline-flex items-center gap-4 px-8 py-4 rounded-xl border-4 ${
                  playerChoice === "heads" ? "bg-purple-600/30 border-purple-400" : "bg-pink-600/30 border-pink-400"
                }`}
              >
                <Coins className={`w-12 h-12 text-yellow-400 ${playerChoice === "tails" ? "rotate-180" : ""}`} />
                <span className="text-4xl font-black uppercase tracking-wider text-white">{playerChoice}</span>
              </div>
              <p className="text-xl text-slate-400 mt-6 animate-pulse">Waiting for opponent to lock in...</p>
            </div>
          </div>
        ) : (
          <div className="space-y-8 py-8">
            <div className="flex justify-center">
              <div
                className={`w-48 h-48 rounded-full flex items-center justify-center border-8 relative ${
                  !result
                    ? "bg-gradient-to-br from-purple-600/40 to-pink-600/40 border-purple-400 animate-spin"
                    : playerChoice === result
                      ? "bg-gradient-to-br from-green-600/40 to-emerald-600/40 border-green-400"
                      : "bg-gradient-to-br from-red-600/40 to-rose-600/40 border-red-400"
                }`}
              >
                {!result ? (
                  <>
                    <Coins className="w-24 h-24 text-yellow-400 animate-pulse" />
                    <div className="absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse"></div>
                  </>
                ) : (
                  <Coins className={`w-24 h-24 text-yellow-400 ${result === "tails" ? "rotate-180" : ""}`} />
                )}
              </div>
            </div>
            <div className="text-center space-y-4">
              <div className="flex justify-around text-lg">
                <div className="space-y-2">
                  <p className="text-slate-400 font-semibold">YOU</p>
                  <div
                    className={`px-6 py-3 rounded-lg border-2 ${
                      playerChoice === "heads"
                        ? "bg-purple-600/20 border-purple-400 text-purple-300"
                        : "bg-pink-600/20 border-pink-400 text-pink-300"
                    }`}
                  >
                    <span className="uppercase font-black text-xl">{playerChoice}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="text-slate-400 font-semibold">OPPONENT</p>
                  <div
                    className={`px-6 py-3 rounded-lg border-2 ${
                      opponentChoice === "heads"
                        ? "bg-purple-600/20 border-purple-400 text-purple-300"
                        : "bg-pink-600/20 border-pink-400 text-pink-300"
                    }`}
                  >
                    <span className="uppercase font-black text-xl">{opponentChoice}</span>
                  </div>
                </div>
              </div>
              {result && (
                <div className="space-y-4 pt-4">
                  <div className="text-center">
                    <p className="text-xl text-slate-400 mb-2">COIN LANDED ON:</p>
                    <div
                      className={`inline-block px-8 py-4 rounded-xl border-4 ${
                        result === "heads" ? "bg-purple-600/30 border-purple-400" : "bg-pink-600/30 border-pink-400"
                      }`}
                    >
                      <span className="uppercase font-black text-4xl text-yellow-400">{result}</span>
                    </div>
                  </div>
                  <div
                    className={`p-8 rounded-2xl border-4 ${
                      playerChoice === result
                        ? "bg-green-600/30 border-green-400 shadow-xl shadow-green-500/50"
                        : "bg-red-600/30 border-red-400 shadow-xl shadow-red-500/50"
                    }`}
                  >
                    {playerChoice === result ? (
                      <div className="flex items-center justify-center gap-4">
                        <Trophy className="w-16 h-16 text-yellow-400 animate-bounce" />
                        <p className="text-5xl font-black text-green-400 tracking-wider">YOU WIN!</p>
                        <Trophy className="w-16 h-16 text-yellow-400 animate-bounce" />
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-4">
                        <Skull className="w-16 h-16 text-red-400 animate-pulse" />
                        <p className="text-5xl font-black text-red-400 tracking-wider">YOU LOSE!</p>
                        <Skull className="w-16 h-16 text-red-400 animate-pulse" />
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
