import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useWallet } from '@solana/wallet-adapter-react';

interface ConnectFourProps {
  onGameEnd: (won: boolean) => void;
  challengeId: string;
  isCreator: boolean;
}

type Cell = 'red' | 'yellow' | null;
type Board = Cell[][];

export const ConnectFour = ({ onGameEnd, challengeId, isCreator }: ConnectFourProps) => {
  const { publicKey } = useWallet();
  const [board, setBoard] = useState<Board>(Array(6).fill(null).map(() => Array(7).fill(null)));
  const [isMyTurn, setIsMyTurn] = useState(isCreator); // Creator (red) goes first
  const [gameOver, setGameOver] = useState(false);
  const [winner, setWinner] = useState<'player' | 'opponent' | 'draw' | null>(null);

  const myColor: Cell = isCreator ? 'red' : 'yellow';
  const opponentColor: Cell = isCreator ? 'yellow' : 'red';

  useEffect(() => {
    if (!challengeId) return;

    const channel = supabase
      .channel(`game-${challengeId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'challenges',
          filter: `id=eq.${challengeId}`,
        },
        (payload) => {
          const gameState = payload.new.game_state as any;
          if (!gameState?.board) return;

          setBoard(gameState.board);
          setIsMyTurn(gameState.currentTurn === myColor);

          const winnerCheck = checkWinner(gameState.board);
          if (winnerCheck) {
            setGameOver(true);
            setWinner(winnerCheck === myColor ? 'player' : 'opponent');
            onGameEnd(winnerCheck === myColor);
          } else if (isBoardFull(gameState.board)) {
            setGameOver(true);
            setWinner('draw');
            onGameEnd(false);
          }
        }
      )
      .subscribe();

    loadGameState();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [challengeId, isCreator]);

  const loadGameState = async () => {
    const { data } = await supabase
      .from('challenges')
      .select('game_state')
      .eq('id', challengeId)
      .single();

    const gameState = data?.game_state as any;
    if (gameState?.board) {
      setBoard(gameState.board);
      setIsMyTurn(gameState.currentTurn === myColor);
    } else if (isCreator) {
      // Only creator initializes game state
      const initialState = {
        board: Array(6).fill(null).map(() => Array(7).fill(null)),
        currentTurn: 'red'
      };
      await supabase
        .from('challenges')
        .update({ game_state: initialState })
        .eq('id', challengeId);
    }
  };

  const checkWinner = (currentBoard: Board): Cell => {
    // Check horizontal
    for (let row = 0; row < 6; row++) {
      for (let col = 0; col < 4; col++) {
        if (currentBoard[row][col] &&
            currentBoard[row][col] === currentBoard[row][col + 1] &&
            currentBoard[row][col] === currentBoard[row][col + 2] &&
            currentBoard[row][col] === currentBoard[row][col + 3]) {
          return currentBoard[row][col];
        }
      }
    }

    // Check vertical
    for (let col = 0; col < 7; col++) {
      for (let row = 0; row < 3; row++) {
        if (currentBoard[row][col] &&
            currentBoard[row][col] === currentBoard[row + 1][col] &&
            currentBoard[row][col] === currentBoard[row + 2][col] &&
            currentBoard[row][col] === currentBoard[row + 3][col]) {
          return currentBoard[row][col];
        }
      }
    }

    // Check diagonal (down-right)
    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 4; col++) {
        if (currentBoard[row][col] &&
            currentBoard[row][col] === currentBoard[row + 1][col + 1] &&
            currentBoard[row][col] === currentBoard[row + 2][col + 2] &&
            currentBoard[row][col] === currentBoard[row + 3][col + 3]) {
          return currentBoard[row][col];
        }
      }
    }

    // Check diagonal (up-right)
    for (let row = 3; row < 6; row++) {
      for (let col = 0; col < 4; col++) {
        if (currentBoard[row][col] &&
            currentBoard[row][col] === currentBoard[row - 1][col + 1] &&
            currentBoard[row][col] === currentBoard[row - 2][col + 2] &&
            currentBoard[row][col] === currentBoard[row - 3][col + 3]) {
          return currentBoard[row][col];
        }
      }
    }

    return null;
  };

  const isBoardFull = (currentBoard: Board): boolean => {
    return currentBoard[0].every(cell => cell !== null);
  };

  const dropPiece = (col: number, currentBoard: Board, player: Cell): Board | null => {
    const newBoard = currentBoard.map(row => [...row]);
    for (let row = 5; row >= 0; row--) {
      if (newBoard[row][col] === null) {
        newBoard[row][col] = player;
        return newBoard;
      }
    }
    return null;
  };

  const handleColumnClick = async (col: number) => {
    if (gameOver || !isMyTurn || board[0][col] !== null || !publicKey) return;

    const newBoard = dropPiece(col, board, myColor);
    if (!newBoard) return;

    const nextTurn = myColor === 'red' ? 'yellow' : 'red';

    await supabase
      .from('challenges')
      .update({
        game_state: {
          board: newBoard,
          currentTurn: nextTurn
        }
      })
      .eq('id', challengeId);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Connect Four</CardTitle>
        <CardDescription>
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-bold ${
            gameOver 
              ? 'bg-muted text-muted-foreground'
              : isMyTurn 
                ? 'bg-primary text-primary-foreground animate-pulse shadow-lg' 
                : 'bg-muted text-muted-foreground'
          }`}>
            {gameOver 
              ? winner === 'player' 
                ? 'You Win!' 
                : winner === 'opponent' 
                  ? 'Opponent Wins!' 
                  : 'Draw!'
              : isMyTurn 
                ? `⚡ YOUR TURN (${myColor === 'red' ? 'RED' : 'YELLOW'})` 
                : `⏳ OPPONENT'S TURN`}
          </div>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {board.map((row, rowIndex) => (
            <div key={rowIndex} className="flex gap-2">
              {row.map((cell, colIndex) => (
                <Button
                  key={colIndex}
                  variant="outline"
                  className={`w-12 h-12 p-0 rounded-full ${
                    cell === 'red' ? 'bg-red-500 hover:bg-red-600' :
                    cell === 'yellow' ? 'bg-yellow-500 hover:bg-yellow-600' :
                    'bg-muted hover:bg-muted/80'
                  }`}
                  onClick={() => handleColumnClick(colIndex)}
                  disabled={gameOver || !isMyTurn || board[0][colIndex] !== null}
                />
              ))}
            </div>
          ))}
        </div>
        {gameOver && (
          <div className="text-center mt-4">
            <p className="text-lg font-semibold">
              {winner === 'player' && '🎉 Victory!'}
              {winner === 'opponent' && '😞 Better luck next time!'}
              {winner === 'draw' && '🤝 It\'s a draw!'}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};