import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dices, Loader2, Trophy, Skull, Zap, Flame, Target } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useWallet } from "@solana/wallet-adapter-react";

interface DiceRollProps {
  onGameEnd: (won: boolean) => void;
  challengeId: string;
  isCreator: boolean;
}

export const DiceRoll = ({ onGameEnd, challengeId, isCreator }: DiceRollProps) => {
  const { publicKey } = useWallet();
  const [playerRoll, setPlayerRoll] = useState<number | null>(null);
  const [opponentRoll, setOpponentRoll] = useState<number | null>(null);
  const [hasRolled, setHasRolled] = useState(false);
  const [waitingForOpponent, setWaitingForOpponent] = useState(false);
  const [isRolling, setIsRolling] = useState(false);
  const [countdown, setCountdown] = useState(30);
  const [gameStartTime, setGameStartTime] = useState<number | null>(null);
  const roundProcessedRef = useRef(false);

  // Initialize game start time
  useEffect(() => {
    if (!challengeId) return;

    const initGameTime = async () => {
      const { data } = await supabase.from("challenges").select("game_state").eq("id", challengeId).single();

      const gameState = data?.game_state as any;

      if (!gameState?.startTime) {
        const startTime = Date.now();
        await supabase
          .from("challenges")
          .update({
            game_state: { startTime },
          })
          .eq("id", challengeId);
        setGameStartTime(startTime);
      } else {
        setGameStartTime(gameState.startTime);
      }
    };

    initGameTime();
  }, [challengeId]);

  // Countdown timer
  useEffect(() => {
    if (!gameStartTime || playerRoll !== null || opponentRoll !== null) return;

    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - gameStartTime) / 1000);
      const remaining = Math.max(0, 30 - elapsed);
      setCountdown(remaining);

      if (remaining === 0) {
        clearInterval(timer);
        checkTimeout();
      }
    }, 100);

    return () => clearInterval(timer);
  }, [gameStartTime, playerRoll, opponentRoll]);

  const checkTimeout = async () => {
    const { data } = await supabase.from("challenges").select("game_state").eq("id", challengeId).single();

    const gameState = data?.game_state as any;
    const myRole = isCreator ? "creator" : "opponent";
    const theirRole = isCreator ? "opponent" : "creator";

    const iMadeRoll = gameState?.[myRole];
    const theyMadeRoll = gameState?.[theirRole];

    if (iMadeRoll && !theyMadeRoll) {
      onGameEnd(true);
    } else if (!iMadeRoll && theyMadeRoll) {
      onGameEnd(false);
    } else if (!iMadeRoll && !theyMadeRoll) {
      onGameEnd(isCreator);
    }
  };

  // Real-time subscription
  useEffect(() => {
    if (!challengeId) return;

    console.log("Setting up real-time subscription for Dice Roll");

    const channel = supabase
      .channel(`game-dice-${challengeId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "challenges",
          filter: `id=eq.${challengeId}`,
        },
        (payload) => {
          console.log("Dice Game state updated:", payload.new);
          const gameState = payload.new.game_state as any;
          if (!gameState) return;

          const myRole = isCreator ? "creator" : "opponent";
          const theirRole = isCreator ? "opponent" : "creator";

          // Both players have rolled
          if (gameState[myRole] && gameState[theirRole] && !roundProcessedRef.current) {
            console.log("Both rolls made:", gameState);
            roundProcessedRef.current = true;

            setOpponentRoll(gameState[theirRole]);
            setWaitingForOpponent(false);

            setTimeout(() => {
              const myRoll = gameState[myRole];
              const theirRoll = gameState[theirRole];

              if (myRoll === theirRoll) {
                // Tie - reset and roll again
                setTimeout(() => {
                  resetRound();
                }, 3000);
              } else {
                const won = myRoll > theirRoll;
                setTimeout(() => onGameEnd(won), 2500);
              }
            }, 1500);
          }
        },
      )
      .subscribe();

    return () => {
      console.log("Cleaning up Dice Roll subscription");
      supabase.removeChannel(channel);
    };
  }, [challengeId, isCreator]);

  const resetRound = async () => {
    console.log("Resetting round");
    const newStartTime = Date.now();

    await supabase
      .from("challenges")
      .update({
        game_state: { startTime: newStartTime },
      })
      .eq("id", challengeId);

    setPlayerRoll(null);
    setOpponentRoll(null);
    setHasRolled(false);
    setWaitingForOpponent(false);
    setIsRolling(false);
    setGameStartTime(newStartTime);
    setCountdown(30);
    roundProcessedRef.current = false;
  };

  const handleRoll = async () => {
    if (!publicKey || isRolling) return;

    console.log("Player rolling dice");
    setIsRolling(true);

    // Simulate dice rolling animation
    let rollCount = 0;
    const rollInterval = setInterval(() => {
      setPlayerRoll(Math.floor(Math.random() * 6) + 1);
      rollCount++;
      if (rollCount >= 10) {
        clearInterval(rollInterval);
        const finalRoll = Math.floor(Math.random() * 6) + 1;
        setPlayerRoll(finalRoll);
        setIsRolling(false);
        setHasRolled(true);
        setWaitingForOpponent(true);
        updateGameState(finalRoll);
      }
    }, 100);
  };

  const updateGameState = async (roll: number) => {
    const myRole = isCreator ? "creator" : "opponent";

    const { data: currentChallenge, error: fetchError } = await supabase
      .from("challenges")
      .select("game_state")
      .eq("id", challengeId)
      .single();

    if (fetchError) {
      console.error("Error fetching game state:", fetchError);
      return;
    }

    const currentState = (currentChallenge?.game_state as any) || {};
    console.log("Current game state:", currentState);

    const newState = { ...currentState, [myRole]: roll };
    console.log("Updating game state to:", newState);

    const { error: updateError } = await supabase
      .from("challenges")
      .update({
        game_state: newState,
      })
      .eq("id", challengeId);

    if (updateError) {
      console.error("Error updating game state:", updateError);
    } else {
      console.log("Game state updated successfully");
    }
  };

  const getDiceEmoji = (num: number | null) => {
    if (num === null) return "🎲";
    return ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"][num - 1] || "🎲";
  };

  const getCountdownColor = () => {
    if (countdown > 20) return "text-green-500";
    if (countdown > 10) return "text-yellow-500";
    return "text-red-500";
  };

  const getResult = () => {
    if (playerRoll === null || opponentRoll === null) return null;
    if (playerRoll > opponentRoll) return "WIN";
    if (playerRoll < opponentRoll) return "LOSE";
    return "TIE";
  };

  const result = getResult();

  return (
    <Card className="border-2 border-purple-500/50 bg-gradient-to-br from-slate-950 via-purple-950/20 to-slate-950 shadow-2xl shadow-purple-500/20">
      <CardHeader className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 via-pink-600/10 to-purple-600/10 animate-pulse"></div>
        <CardTitle className="text-center text-4xl font-black bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent relative z-10 tracking-wider">
          🎲 DEGEN DICE DUEL 🎲
        </CardTitle>

        {/* Countdown Timer */}
        {!result && playerRoll === null && opponentRoll === null && (
          <div className="mt-4 relative z-10">
            <div
              className={`text-center text-6xl font-black ${getCountdownColor()} transition-colors duration-300 ${
                countdown <= 5 ? "animate-pulse scale-110" : ""
              }`}
            >
              {countdown}s
            </div>
            <div className="w-full bg-slate-800 h-3 rounded-full mt-2 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  countdown > 20 ? "bg-green-500" : countdown > 10 ? "bg-yellow-500" : "bg-red-500"
                }`}
                style={{ width: `${(countdown / 30) * 100}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Turn Indicator */}
        {!result && (
          <div
            className={`mt-4 p-4 rounded-xl border-4 text-center font-black uppercase tracking-widest text-xl relative z-10 ${
              !hasRolled
                ? "bg-purple-500/30 border-purple-400 text-purple-300 animate-pulse shadow-lg shadow-purple-500/50"
                : "bg-slate-800/50 border-yellow-500/50 text-yellow-400"
            }`}
          >
            {!hasRolled ? (
              <span className="flex items-center justify-center gap-2">
                <Target className="w-6 h-6" />
                ROLL THE DICE!
                <Target className="w-6 h-6" />
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">⏳ OPPONENT'S ROLL...</span>
            )}
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-6 relative z-10">
        {result === "TIE" ? (
          <div className="text-center py-12 space-y-6 animate-pulse">
            <div className="text-8xl animate-bounce">🤝</div>
            <p className="text-4xl font-black text-yellow-400 tracking-wider">IT'S A TIE!</p>
            <p className="text-xl text-purple-300">
              Both rolled <span className="uppercase font-bold text-yellow-400">{playerRoll}</span>
            </p>
            <p className="text-lg text-slate-400">Rematch in 3 seconds...</p>
          </div>
        ) : !hasRolled ? (
          <div className="text-center space-y-6 py-8">
            <div className="space-y-4">
              <p className="text-2xl font-bold text-purple-300">HIGHEST ROLL WINS!</p>
              <div className="text-8xl animate-bounce">🎲</div>
              <p className="text-xl text-slate-400">Time to test your luck, degen!</p>
            </div>
            <Button
              onClick={handleRoll}
              disabled={isRolling}
              className="w-full h-24 text-3xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 border-4 border-purple-400 font-black tracking-wider uppercase transition-all transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/50 group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <Flame className="w-10 h-10 mr-3 animate-pulse" />
              {isRolling ? "ROLLING..." : "ROLL DICE"}
              <Flame className="w-10 h-10 ml-3 animate-pulse" />
            </Button>
          </div>
        ) : waitingForOpponent ? (
          <div className="text-center py-12 space-y-6">
            <div className="space-y-4">
              <p className="text-2xl font-bold text-purple-300">YOUR ROLL:</p>
              <div className="relative inline-block">
                <div className="text-9xl font-black text-purple-400">{getDiceEmoji(playerRoll)}</div>
                <div className="text-6xl font-black text-white mt-2">{playerRoll}</div>
              </div>
            </div>
            <div className="relative inline-block mt-8">
              <Loader2 className="w-20 h-20 animate-spin text-purple-400" />
              <Dices className="w-8 h-8 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-pink-400 animate-pulse" />
            </div>
            <p className="text-xl text-slate-400 animate-pulse">Waiting for opponent...</p>
          </div>
        ) : (
          <div className="space-y-8 py-8">
            <div className="grid grid-cols-2 gap-8">
              {/* Player */}
              <div className="text-center space-y-4">
                <p className="text-xl font-bold text-slate-400">YOU</p>
                <div
                  className={`h-40 flex flex-col items-center justify-center rounded-xl border-4 bg-gradient-to-br shadow-xl transition-all ${
                    result === "WIN"
                      ? "from-green-600 to-green-800 border-green-400 shadow-green-500/50 scale-110"
                      : result === "LOSE"
                        ? "from-red-600/50 to-red-800/50 border-red-400/50 shadow-red-500/30"
                        : "from-purple-600 to-purple-800 border-purple-400 shadow-purple-500/50"
                  }`}
                >
                  <div className="text-7xl">{getDiceEmoji(playerRoll)}</div>
                  <div className="text-5xl font-black text-white mt-2">{playerRoll}</div>
                </div>
              </div>

              {/* Opponent */}
              <div className="text-center space-y-4">
                <p className="text-xl font-bold text-slate-400">OPPONENT</p>
                <div
                  className={`h-40 flex flex-col items-center justify-center rounded-xl border-4 bg-gradient-to-br shadow-xl transition-all ${
                    result === "LOSE"
                      ? "from-green-600 to-green-800 border-green-400 shadow-green-500/50 scale-110"
                      : result === "WIN"
                        ? "from-red-600/50 to-red-800/50 border-red-400/50 shadow-red-500/30"
                        : "from-pink-600 to-pink-800 border-pink-400 shadow-pink-500/50"
                  }`}
                >
                  <div className="text-7xl">{getDiceEmoji(opponentRoll)}</div>
                  <div className="text-5xl font-black text-white mt-2">{opponentRoll}</div>
                </div>
              </div>
            </div>

            {/* Battle Animation */}
            {opponentRoll && !result && (
              <div className="flex justify-center">
                <Zap className="w-16 h-16 text-yellow-400 animate-ping" />
              </div>
            )}

            {/* Result */}
            {result && (
              <div
                className={`p-8 rounded-2xl border-4 ${
                  result === "WIN"
                    ? "bg-green-600/30 border-green-400 shadow-xl shadow-green-500/50"
                    : "bg-red-600/30 border-red-400 shadow-xl shadow-red-500/50"
                }`}
              >
                {result === "WIN" ? (
                  <div className="flex items-center justify-center gap-4">
                    <Trophy className="w-16 h-16 text-yellow-400 animate-bounce" />
                    <p className="text-5xl font-black text-green-400 tracking-wider">VICTORY!</p>
                    <Trophy className="w-16 h-16 text-yellow-400 animate-bounce" />
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-4">
                    <Skull className="w-16 h-16 text-red-400 animate-pulse" />
                    <p className="text-5xl font-black text-red-400 tracking-wider">DEFEAT!</p>
                    <Skull className="w-16 h-16 text-red-400 animate-pulse" />
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
