import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Spade, Heart, Club, Diamond, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useWallet } from '@solana/wallet-adapter-react';

interface HigherLowerProps {
  onGameEnd: (won: boolean) => void;
  challengeId: string;
  isCreator: boolean;
}

type Suit = 'spades' | 'hearts' | 'clubs' | 'diamonds';
type CardValue = 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14; // 11=J, 12=Q, 13=K, 14=A

interface GameCard {
  value: CardValue;
  suit: Suit;
}

export const HigherLower = ({ onGameEnd, challengeId, isCreator }: HigherLowerProps) => {
  const { publicKey } = useWallet();
  const [playerCard, setPlayerCard] = useState<GameCard | null>(null);
  const [opponentCard, setOpponentCard] = useState<GameCard | null>(null);
  const [result, setResult] = useState<'win' | 'lose' | 'draw' | null>(null);
  const [waiting, setWaiting] = useState(false);

  useEffect(() => {
    if (!challengeId) return;

    const channel = supabase
      .channel(`game-${challengeId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'challenges',
          filter: `id=eq.${challengeId}`,
        },
        (payload) => {
          const gameState = payload.new.game_state as any;
          if (!gameState) return;

          const myRole = isCreator ? 'creator' : 'opponent';
          const theirRole = isCreator ? 'opponent' : 'creator';

          if (gameState[myRole]) {
            setPlayerCard(gameState[myRole]);
          }

          if (gameState[theirRole]) {
            setOpponentCard(gameState[theirRole]);
            setWaiting(false);

            // Determine winner
            const myCard = gameState[myRole];
            const theirCard = gameState[theirRole];

            if (myCard.value > theirCard.value) {
              setResult('win');
              onGameEnd(true);
            } else if (myCard.value < theirCard.value) {
              setResult('lose');
              onGameEnd(false);
            } else {
              setResult('draw');
              onGameEnd(false);
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [challengeId, isCreator]);

  const drawCard = (): GameCard => {
    const suits: Suit[] = ['spades', 'hearts', 'clubs', 'diamonds'];
    const values: CardValue[] = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
    return {
      value: values[Math.floor(Math.random() * values.length)],
      suit: suits[Math.floor(Math.random() * suits.length)]
    };
  };

  const getCardName = (value: CardValue): string => {
    switch (value) {
      case 11: return 'J';
      case 12: return 'Q';
      case 13: return 'K';
      case 14: return 'A';
      default: return value.toString();
    }
  };

  const getSuitIcon = (suit: Suit) => {
    switch (suit) {
      case 'spades': return Spade;
      case 'hearts': return Heart;
      case 'clubs': return Club;
      case 'diamonds': return Diamond;
    }
  };

  const getSuitColor = (suit: Suit): string => {
    return suit === 'hearts' || suit === 'diamonds' ? 'text-red-500' : 'text-foreground';
  };

  const handleDraw = async () => {
    if (!publicKey) return;
    
    setWaiting(true);
    const card = drawCard();
    setPlayerCard(card);

    const myRole = isCreator ? 'creator' : 'opponent';
    
    // Fetch current game state first
    const { data: currentChallenge } = await supabase
      .from('challenges')
      .select('game_state')
      .eq('id', challengeId)
      .single();

    const currentState = (currentChallenge?.game_state as any) || {};

    await supabase
      .from('challenges')
      .update({
        game_state: { ...currentState, [myRole]: card } as any
      })
      .eq('id', challengeId);
  };

  const renderCard = (card: GameCard | null, label: string) => {
    if (!card) return null;
    
    const SuitIcon = getSuitIcon(card.suit);
    const suitColor = getSuitColor(card.suit);

    return (
      <div className="text-center">
        <p className="text-sm text-muted-foreground mb-2">{label}</p>
        <div className="w-32 h-48 bg-card border-2 border-border rounded-lg flex flex-col items-center justify-center p-4">
          <div className={`text-4xl font-bold ${suitColor}`}>
            {getCardName(card.value)}
          </div>
          <SuitIcon className={`w-12 h-12 ${suitColor} mt-2`} />
        </div>
      </div>
    );
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Higher or Lower</CardTitle>
        <CardDescription>
          {result === null ? 'Draw a card to play!' : 
           result === 'win' ? '🎉 You Win! Your card was higher!' :
           result === 'lose' ? '😞 You Lose! Opponent\'s card was higher!' :
           '🤝 It\'s a draw! Same card value!'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {!playerCard ? (
          <div className="text-center py-8">
            <Button
              onClick={handleDraw}
              disabled={waiting}
              size="lg"
              className="bg-primary hover:bg-primary/90"
            >
              Draw Card
            </Button>
          </div>
        ) : waiting ? (
          <div className="text-center py-8">
            <Loader2 className="w-12 h-12 animate-spin mx-auto text-primary mb-4" />
            <p className="text-muted-foreground">Waiting for opponent...</p>
          </div>
        ) : (
          <div className="flex justify-center gap-8">
            {renderCard(playerCard, 'Your Card')}
            {renderCard(opponentCard, 'Opponent\'s Card')}
          </div>
        )}

        {result && (
          <div className="text-center">
            <p className="text-lg font-semibold">
              {result === 'win' && 'Victory!'}
              {result === 'lose' && 'Better luck next time!'}
              {result === 'draw' && 'It\'s a tie!'}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};