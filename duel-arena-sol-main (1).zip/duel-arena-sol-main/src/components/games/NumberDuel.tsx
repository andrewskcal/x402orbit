import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useWallet } from '@solana/wallet-adapter-react';

interface NumberDuelProps {
  onGameEnd: (won: boolean) => void;
  challengeId: string;
  isCreator: boolean;
}

export const NumberDuel = ({ onGameEnd, challengeId, isCreator }: NumberDuelProps) => {
  const { publicKey } = useWallet();
  const [playerNumber, setPlayerNumber] = useState<number | null>(null);
  const [opponentNumber, setOpponentNumber] = useState<number | null>(null);
  const [targetNumber, setTargetNumber] = useState<number | null>(null);
  const [inputValue, setInputValue] = useState('');
  const [result, setResult] = useState<'win' | 'lose' | 'draw' | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [waiting, setWaiting] = useState(false);

  useEffect(() => {
    if (!challengeId) return;

    const channel = supabase
      .channel(`game-${challengeId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'challenges',
          filter: `id=eq.${challengeId}`,
        },
        (payload) => {
          const gameState = payload.new.game_state as any;
          if (!gameState) return;

          const myRole = isCreator ? 'creator' : 'opponent';
          const theirRole = isCreator ? 'opponent' : 'creator';

          if (gameState[myRole]?.number !== undefined) {
            setPlayerNumber(gameState[myRole].number);
          }

          if (gameState[theirRole]?.number !== undefined) {
            setOpponentNumber(gameState[theirRole].number);
            setWaiting(false);

            // Both players have submitted, generate target if not exists
            if (!gameState.target) {
              if (isCreator) {
                // Only creator generates the target
                const target = Math.floor(Math.random() * 100) + 1;
                supabase
                  .from('challenges')
                  .update({
                    game_state: { ...gameState, target } as any
                  })
                  .eq('id', challengeId);
              }
            } else {
              setTargetNumber(gameState.target);

              // Calculate winner
              const myNum = gameState[myRole].number;
              const theirNum = gameState[theirRole].number;
              const target = gameState.target;

              const myDistance = Math.abs(myNum - target);
              const theirDistance = Math.abs(theirNum - target);

              if (myDistance < theirDistance) {
                setResult('win');
                onGameEnd(true);
              } else if (myDistance > theirDistance) {
                setResult('lose');
                onGameEnd(false);
              } else {
                setResult('draw');
                onGameEnd(false);
              }
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [challengeId, isCreator]);

  const handleSubmit = async () => {
    const playerGuess = parseInt(inputValue);
    
    if (isNaN(playerGuess) || playerGuess < 1 || playerGuess > 100 || !publicKey) {
      return;
    }

    setHasSubmitted(true);
    setPlayerNumber(playerGuess);
    setWaiting(true);

    const myRole = isCreator ? 'creator' : 'opponent';
    
    // Fetch current game state first
    const { data: currentChallenge } = await supabase
      .from('challenges')
      .select('game_state')
      .eq('id', challengeId)
      .single();

    const currentState = (currentChallenge?.game_state as any) || {};

    await supabase
      .from('challenges')
      .update({
        game_state: { ...currentState, [myRole]: { number: playerGuess } } as any
      })
      .eq('id', challengeId);
  };

  const getDistance = (num: number, target: number) => {
    return Math.abs(num - target);
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Number Duel</CardTitle>
        <CardDescription>
          {!hasSubmitted 
            ? 'Pick a number between 1-100. Closest to the target wins!' 
            : waiting
              ? 'Waiting for opponent...'
              : result === null
                ? 'Calculating results...'
                : result === 'win'
                  ? '🎉 You Win! Closer to the target!'
                  : result === 'lose'
                    ? '😞 You Lose! Opponent was closer!'
                    : '🤝 It\'s a draw! Same distance!'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {!hasSubmitted ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="number">Your Number (1-100)</Label>
              <Input
                id="number"
                type="number"
                min="1"
                max="100"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Enter a number"
              />
            </div>
            <Button
              onClick={handleSubmit}
              disabled={!inputValue || parseInt(inputValue) < 1 || parseInt(inputValue) > 100}
              className="w-full bg-primary hover:bg-primary/90"
            >
              Submit Number
            </Button>
          </div>
        ) : waiting ? (
          <div className="text-center py-8">
            <Loader2 className="w-12 h-12 animate-spin mx-auto text-primary mb-4" />
            <p className="text-muted-foreground">Waiting for opponent to choose...</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="text-center p-6 bg-primary/10 rounded-lg border border-primary/20">
              <p className="text-sm text-muted-foreground mb-2">Target Number</p>
              <p className="text-5xl font-bold text-primary">{targetNumber}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Your Pick</p>
                <p className="text-3xl font-bold">{playerNumber}</p>
                <p className="text-xs text-muted-foreground mt-2">
                  Distance: {targetNumber && playerNumber ? getDistance(playerNumber, targetNumber) : '-'}
                </p>
              </div>

              <div className="text-center p-4 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Opponent's Pick</p>
                <p className="text-3xl font-bold">{opponentNumber}</p>
                <p className="text-xs text-muted-foreground mt-2">
                  Distance: {targetNumber && opponentNumber ? getDistance(opponentNumber, targetNumber) : '-'}
                </p>
              </div>
            </div>

            {result && (
              <div className="text-center p-4 bg-accent/10 rounded-lg">
                <p className="text-lg font-semibold">
                  {result === 'win' && '🎉 Victory!'}
                  {result === 'lose' && '😞 Better luck next time!'}
                  {result === 'draw' && '🤝 It\'s a tie!'}
                </p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};