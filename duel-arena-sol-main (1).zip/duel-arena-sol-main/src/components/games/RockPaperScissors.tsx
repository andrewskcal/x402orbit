import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Hand, Scissors, Square, Loader2, Zap, Trophy, Skull, Swords } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useWallet } from "@solana/wallet-adapter-react";

type Choice = "rock" | "paper" | "scissors" | null;

interface RockPaperScissorsProps {
  onGameEnd: (won: boolean) => void;
  challengeId: string;
  isCreator: boolean;
}

export const RockPaperScissors = ({ onGameEnd, challengeId, isCreator }: RockPaperScissorsProps) => {
  const { publicKey } = useWallet();
  const [playerChoice, setPlayerChoice] = useState<Choice>(null);
  const [opponentChoice, setOpponentChoice] = useState<Choice>(null);
  const [result, setResult] = useState<string>("");
  const [waitingForOpponent, setWaitingForOpponent] = useState(false);
  const [countdown, setCountdown] = useState(30);
  const [gameStartTime, setGameStartTime] = useState<number | null>(null);
  const roundProcessedRef = useRef(false);

  const choices: Choice[] = ["rock", "paper", "scissors"];

  // Initialize game start time
  useEffect(() => {
    if (!challengeId) return;

    const initGameTime = async () => {
      const { data } = await supabase.from("challenges").select("game_state").eq("id", challengeId).single();

      const gameState = data?.game_state as any;

      if (!gameState?.startTime) {
        const startTime = Date.now();
        await supabase
          .from("challenges")
          .update({
            game_state: { startTime },
          })
          .eq("id", challengeId);
        setGameStartTime(startTime);
      } else {
        setGameStartTime(gameState.startTime);
      }
    };

    initGameTime();
  }, [challengeId]);

  // Countdown timer
  useEffect(() => {
    if (!gameStartTime || result) return;

    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - gameStartTime) / 1000);
      const remaining = Math.max(0, 30 - elapsed);
      setCountdown(remaining);

      if (remaining === 0) {
        clearInterval(timer);
        checkTimeout();
      }
    }, 100);

    return () => clearInterval(timer);
  }, [gameStartTime, result, playerChoice]);

  const checkTimeout = async () => {
    const { data } = await supabase.from("challenges").select("game_state").eq("id", challengeId).single();

    const gameState = data?.game_state as any;
    const myRole = isCreator ? "creator" : "opponent";
    const theirRole = isCreator ? "opponent" : "creator";

    const iMadeChoice = gameState?.[myRole];
    const theyMadeChoice = gameState?.[theirRole];

    if (iMadeChoice && !theyMadeChoice) {
      onGameEnd(true);
    } else if (!iMadeChoice && theyMadeChoice) {
      onGameEnd(false);
    } else if (!iMadeChoice && !theyMadeChoice) {
      onGameEnd(isCreator);
    }
  };

  useEffect(() => {
    if (!challengeId) return;

    console.log("Setting up real-time subscription for RPS");

    const channel = supabase
      .channel(`game-rps-${challengeId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "challenges",
          filter: `id=eq.${challengeId}`,
        },
        (payload) => {
          console.log("RPS Game state updated:", payload.new);
          const gameState = payload.new.game_state as any;
          if (!gameState) return;

          const myRole = isCreator ? "creator" : "opponent";
          const theirRole = isCreator ? "opponent" : "creator";

          if (gameState[myRole] && gameState[theirRole] && !roundProcessedRef.current) {
            console.log("Both choices made:", gameState);
            roundProcessedRef.current = true;

            setOpponentChoice(gameState[theirRole]);
            setWaitingForOpponent(false);

            setTimeout(() => {
              const myChoice = gameState[myRole];
              const theirChoice = gameState[theirRole];

              if (myChoice === theirChoice) {
                setResult("DRAW");
                setTimeout(() => {
                  resetRound();
                }, 3000);
              } else {
                const won = determineWinner(myChoice, theirChoice);
                setResult(won ? "WIN" : "LOSE");
                setTimeout(() => onGameEnd(won), 2500);
              }
            }, 1500);
          }
        },
      )
      .subscribe();

    return () => {
      console.log("Cleaning up RPS subscription");
      supabase.removeChannel(channel);
    };
  }, [challengeId, isCreator]);

  const getIcon = (choice: Choice) => {
    switch (choice) {
      case "rock":
        return Hand;
      case "paper":
        return Square;
      case "scissors":
        return Scissors;
      default:
        return Hand;
    }
  };

  const getChoiceColor = (choice: Choice) => {
    switch (choice) {
      case "rock":
        return {
          bg: "from-red-600 to-red-800",
          border: "border-red-400",
          hover: "hover:from-red-500 hover:to-red-700",
          shadow: "shadow-red-500/50",
        };
      case "paper":
        return {
          bg: "from-blue-600 to-blue-800",
          border: "border-blue-400",
          hover: "hover:from-blue-500 hover:to-blue-700",
          shadow: "shadow-blue-500/50",
        };
      case "scissors":
        return {
          bg: "from-green-600 to-green-800",
          border: "border-green-400",
          hover: "hover:from-green-500 hover:to-green-700",
          shadow: "shadow-green-500/50",
        };
      default:
        return {
          bg: "from-gray-600 to-gray-800",
          border: "border-gray-400",
          hover: "hover:from-gray-500 hover:to-gray-700",
          shadow: "shadow-gray-500/50",
        };
    }
  };

  const determineWinner = (player: Choice, opponent: Choice): boolean => {
    if (player === opponent) return false;
    if (player === "rock" && opponent === "scissors") return true;
    if (player === "paper" && opponent === "rock") return true;
    if (player === "scissors" && opponent === "paper") return true;
    return false;
  };

  const resetRound = async () => {
    console.log("Resetting round");
    const newStartTime = Date.now();

    await supabase
      .from("challenges")
      .update({
        game_state: { startTime: newStartTime },
      })
      .eq("id", challengeId);

    setPlayerChoice(null);
    setOpponentChoice(null);
    setResult("");
    setGameStartTime(newStartTime);
    setCountdown(30);
    roundProcessedRef.current = false;
  };

  const handleChoice = async (choice: Choice) => {
    if (!publicKey) return;

    console.log("Player chose:", choice);
    setPlayerChoice(choice);
    setWaitingForOpponent(true);

    const myRole = isCreator ? "creator" : "opponent";

    const { data: currentChallenge, error: fetchError } = await supabase
      .from("challenges")
      .select("game_state")
      .eq("id", challengeId)
      .single();

    if (fetchError) {
      console.error("Error fetching game state:", fetchError);
      return;
    }

    const currentState = (currentChallenge?.game_state as any) || {};
    console.log("Current game state:", currentState);

    const newState = { ...currentState, [myRole]: choice };
    console.log("Updating game state to:", newState);

    const { error: updateError } = await supabase
      .from("challenges")
      .update({
        game_state: newState,
      })
      .eq("id", challengeId);

    if (updateError) {
      console.error("Error updating game state:", updateError);
    } else {
      console.log("Game state updated successfully");
    }
  };

  const getCountdownColor = () => {
    if (countdown > 20) return "text-green-500";
    if (countdown > 10) return "text-yellow-500";
    return "text-red-500";
  };

  return (
    <Card className="border-2 border-cyan-500/50 bg-gradient-to-br from-slate-950 via-cyan-950/20 to-slate-950 shadow-2xl shadow-cyan-500/20">
      <CardHeader className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-600/10 via-blue-600/10 to-cyan-600/10 animate-pulse"></div>
        <CardTitle className="text-center text-4xl font-black bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-400 bg-clip-text text-transparent relative z-10 tracking-wider">
          ⚔️ ROCK PAPER SCISSORS ⚔️
        </CardTitle>

        {/* Countdown Timer */}
        {!result && (
          <div className="mt-4 relative z-10">
            <div
              className={`text-center text-6xl font-black ${getCountdownColor()} transition-colors duration-300 ${countdown <= 5 ? "animate-pulse scale-110" : ""}`}
            >
              {countdown}s
            </div>
            <div className="w-full bg-slate-800 h-3 rounded-full mt-2 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  countdown > 20 ? "bg-green-500" : countdown > 10 ? "bg-yellow-500" : "bg-red-500"
                }`}
                style={{ width: `${(countdown / 30) * 100}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Turn Indicator */}
        {!result && (
          <div
            className={`mt-4 p-4 rounded-xl border-4 text-center font-black uppercase tracking-widest text-xl relative z-10 ${
              !playerChoice
                ? "bg-cyan-500/30 border-cyan-400 text-cyan-300 animate-pulse shadow-lg shadow-cyan-500/50"
                : "bg-slate-800/50 border-yellow-500/50 text-yellow-400"
            }`}
          >
            {!playerChoice ? (
              <span className="flex items-center justify-center gap-2">
                <Swords className="w-6 h-6" />
                CHOOSE YOUR WEAPON!
                <Swords className="w-6 h-6" />
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">⏳ OPPONENT'S MOVE...</span>
            )}
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-6 relative z-10">
        {result === "DRAW" ? (
          <div className="text-center py-12 space-y-6 animate-pulse">
            <div className="text-8xl animate-bounce">🤝</div>
            <p className="text-4xl font-black text-yellow-400 tracking-wider">IT'S A DRAW!</p>
            <p className="text-xl text-cyan-300">
              Both chose <span className="uppercase font-bold text-yellow-400">{playerChoice}</span>
            </p>
            <p className="text-lg text-slate-400">Rematch in 3 seconds...</p>
          </div>
        ) : !playerChoice ? (
          <div className="grid grid-cols-3 gap-4">
            {choices.map((choice) => {
              const Icon = getIcon(choice);
              const colors = getChoiceColor(choice);
              return (
                <Button
                  key={choice}
                  onClick={() => handleChoice(choice)}
                  className={`h-40 flex flex-col gap-4 bg-gradient-to-br ${colors.bg} ${colors.hover} border-4 ${colors.border} transition-all transform hover:scale-105 hover:shadow-2xl hover:${colors.shadow} group relative overflow-hidden`}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <Icon className="w-16 h-16 text-yellow-400 group-hover:scale-110 transition-transform" />
                  <span className="text-xl font-black tracking-wider uppercase relative z-10">{choice}</span>
                  <Zap className="w-6 h-6 absolute top-2 right-2 text-yellow-400 opacity-0 group-hover:opacity-100 animate-pulse" />
                </Button>
              );
            })}
          </div>
        ) : waitingForOpponent ? (
          <div className="text-center py-12 space-y-6">
            <div className="relative inline-block">
              <Loader2 className="w-20 h-20 animate-spin text-cyan-400" />
              <Swords className="w-8 h-8 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-yellow-400 animate-pulse" />
            </div>
            <div className="space-y-3">
              <p className="text-2xl font-bold text-cyan-300">YOU CHOSE:</p>
              <div
                className={`inline-flex items-center gap-4 px-8 py-4 rounded-xl border-4 bg-gradient-to-br ${getChoiceColor(playerChoice).bg} ${getChoiceColor(playerChoice).border}`}
              >
                {(() => {
                  const Icon = getIcon(playerChoice);
                  return <Icon className="w-12 h-12 text-yellow-400" />;
                })()}
                <span className="text-4xl font-black uppercase tracking-wider text-white">{playerChoice}</span>
              </div>
              <p className="text-xl text-slate-400 mt-6 animate-pulse">Waiting for opponent's move...</p>
            </div>
          </div>
        ) : (
          <div className="space-y-8 py-8">
            <div className="grid grid-cols-2 gap-8">
              <div className="text-center space-y-4">
                <p className="text-xl font-bold text-slate-400">YOU</p>
                <div
                  className={`h-32 flex items-center justify-center rounded-xl border-4 bg-gradient-to-br ${getChoiceColor(playerChoice).bg} ${getChoiceColor(playerChoice).border} shadow-xl ${getChoiceColor(playerChoice).shadow}`}
                >
                  {(() => {
                    const Icon = getIcon(playerChoice);
                    return <Icon className="w-16 h-16 text-yellow-400" />;
                  })()}
                </div>
                <p className="uppercase font-black text-2xl text-white">{playerChoice}</p>
              </div>
              <div className="text-center space-y-4">
                <p className="text-xl font-bold text-slate-400">OPPONENT</p>
                <div
                  className={`h-32 flex items-center justify-center rounded-xl border-4 bg-gradient-to-br ${getChoiceColor(opponentChoice).bg} ${getChoiceColor(opponentChoice).border} shadow-xl ${getChoiceColor(opponentChoice).shadow}`}
                >
                  {opponentChoice &&
                    (() => {
                      const Icon = getIcon(opponentChoice);
                      return <Icon className="w-16 h-16 text-yellow-400" />;
                    })()}
                </div>
                <p className="uppercase font-black text-2xl text-white">{opponentChoice || "..."}</p>
              </div>
            </div>

            {/* Battle Animation */}
            {opponentChoice && !result && (
              <div className="flex justify-center">
                <Swords className="w-16 h-16 text-yellow-400 animate-ping" />
              </div>
            )}

            {result && (
              <div
                className={`p-8 rounded-2xl border-4 ${
                  result === "WIN"
                    ? "bg-green-600/30 border-green-400 shadow-xl shadow-green-500/50"
                    : "bg-red-600/30 border-red-400 shadow-xl shadow-red-500/50"
                }`}
              >
                {result === "WIN" ? (
                  <div className="flex items-center justify-center gap-4">
                    <Trophy className="w-16 h-16 text-yellow-400 animate-bounce" />
                    <p className="text-5xl font-black text-green-400 tracking-wider">VICTORY!</p>
                    <Trophy className="w-16 h-16 text-yellow-400 animate-bounce" />
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-4">
                    <Skull className="w-16 h-16 text-red-400 animate-pulse" />
                    <p className="text-5xl font-black text-red-400 tracking-wider">DEFEAT!</p>
                    <Skull className="w-16 h-16 text-red-400 animate-pulse" />
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
