import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Circle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useWallet } from "@solana/wallet-adapter-react";

interface TicTacToeProps {
  onGameEnd: (won: boolean) => void;
  challengeId: string;
  isCreator: boolean;
}

type Player = "X" | "O" | null;
type Board = Player[];

export const TicTacToe = ({ onGameEnd, challengeId, isCreator }: TicTacToeProps) => {
  const { publicKey } = useWallet();
  const [board, setBoard] = useState<Board>(Array(9).fill(null));
  const [currentTurn, setCurrentTurn] = useState<Player>("X");
  const [gameOver, setGameOver] = useState(false);
  const [winner, setWinner] = useState<"player" | "opponent" | "draw" | null>(null);
  const isUpdatingRef = useRef(false);

  const mySymbol: Player = isCreator ? "X" : "O";
  const opponentSymbol: Player = isCreator ? "O" : "X";
  const isMyTurn = currentTurn === mySymbol;

  useEffect(() => {
    if (!challengeId) return;

    let isSubscribed = true;

    // Load initial state
    loadGameState();

    // Set up real-time subscription with better handling
    const channel = supabase
      .channel(`game-${challengeId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "challenges",
          filter: `id=eq.${challengeId}`,
        },
        (payload) => {
          if (!isSubscribed) return;

          const gameState = (payload.new as any)?.game_state;
          if (gameState?.board && !isUpdatingRef.current) {
            console.log("Real-time game state update:", gameState);
            setBoard(gameState.board);
            setCurrentTurn(gameState.currentTurn || "X");
            checkGameEnd(gameState.board);
          }
        },
      )
      .subscribe((status) => {
        console.log("Subscription status:", status);
      });

    return () => {
      isSubscribed = false;
      supabase.removeChannel(channel);
    };
  }, [challengeId]);

  const checkGameEnd = (currentBoard: Board) => {
    if (gameOver) return;

    const winnerSymbol = checkWinner(currentBoard);
    if (winnerSymbol) {
      console.log("Winner found:", winnerSymbol);
      setGameOver(true);
      const didIWin = winnerSymbol === mySymbol;
      setWinner(didIWin ? "player" : "opponent");

      setTimeout(() => {
        resetBoardAndEndRound(didIWin);
      }, 2000);
    } else if (getAvailableMoves(currentBoard).length === 0) {
      console.log("Draw - no moves left");
      setGameOver(true);
      setWinner("draw");

      setTimeout(() => {
        resetBoardAndEndRound(false);
      }, 2000);
    }
  };

  const loadGameState = async () => {
    const { data } = await supabase.from("challenges").select("game_state").eq("id", challengeId).single();

    const gameState = data?.game_state as any;
    if (gameState?.board) {
      console.log("Loading existing game state:", gameState);
      setBoard(gameState.board);
      setCurrentTurn(gameState.currentTurn || "X");
    } else if (isCreator) {
      // Only creator initializes game state
      console.log("Creator initializing game state");
      const initialGameState = {
        ...(gameState || {}),
        board: Array(9).fill(null),
        currentTurn: "X" as Player,
      };

      await supabase.from("challenges").update({ game_state: initialGameState }).eq("id", challengeId);

      setBoard(Array(9).fill(null));
      setCurrentTurn("X");
    }
  };

  const checkWinner = (currentBoard: Board): Player => {
    const winPatterns = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8], // rows
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8], // columns
      [0, 4, 8],
      [2, 4, 6], // diagonals
    ];

    for (const pattern of winPatterns) {
      const [a, b, c] = pattern;
      if (currentBoard[a] && currentBoard[a] === currentBoard[b] && currentBoard[a] === currentBoard[c]) {
        return currentBoard[a];
      }
    }

    return null;
  };

  const getAvailableMoves = (currentBoard: Board): number[] => {
    return currentBoard.map((cell, index) => (cell === null ? index : -1)).filter((i) => i !== -1);
  };

  const resetBoardAndEndRound = async (won: boolean) => {
    // Fetch current game_state to preserve escrow data
    const { data: currentData } = await supabase.from("challenges").select("game_state").eq("id", challengeId).single();

    const preservedState = currentData?.game_state || {};

    // Reset board for next round
    await supabase
      .from("challenges")
      .update({
        game_state: {
          ...preservedState,
          board: Array(9).fill(null),
          currentTurn: "X" as Player,
        },
      })
      .eq("id", challengeId);

    // Reset local state
    setBoard(Array(9).fill(null));
    setCurrentTurn("X");
    setGameOver(false);
    setWinner(null);

    // Call onGameEnd
    onGameEnd(won);
  };

  const handleCellClick = async (index: number) => {
    // Validation checks
    if (gameOver) {
      console.log("Game is over");
      return;
    }

    if (board[index] !== null) {
      console.log("Cell already taken");
      return;
    }

    if (!publicKey) {
      console.log("No wallet connected");
      return;
    }

    if (currentTurn !== mySymbol) {
      console.log("Not your turn:", { currentTurn, mySymbol });
      return;
    }

    console.log("Making move at position:", index, "as", mySymbol);

    // Set updating flag to prevent real-time override
    isUpdatingRef.current = true;

    const newBoard = [...board];
    newBoard[index] = mySymbol;
    const nextTurn: Player = mySymbol === "X" ? "O" : "X";

    // Optimistically update local state
    setBoard(newBoard);
    setCurrentTurn(nextTurn);

    try {
      // Fetch current game_state first to preserve escrow and other data
      const { data: currentData, error: fetchError } = await supabase
        .from("challenges")
        .select("game_state")
        .eq("id", challengeId)
        .single();

      if (fetchError) {
        console.error("Error fetching current game state:", fetchError);
        await loadGameState();
        return;
      }

      const preservedState = currentData?.game_state || {};
      console.log("Current game state before update:", preservedState);

      // Merge new board and turn with existing state
      const updatedGameState = {
        ...preservedState,
        board: newBoard,
        currentTurn: nextTurn,
      };

      console.log("Updating with new game state:", updatedGameState);

      const { error: updateError } = await supabase
        .from("challenges")
        .update({
          game_state: updatedGameState,
        })
        .eq("id", challengeId);

      if (updateError) {
        console.error("Update error:", updateError);
        // Revert on error
        await loadGameState();
        return;
      }

      console.log("Move successfully saved to database");

      // Check if this move ended the game
      checkGameEnd(newBoard);
    } catch (error) {
      console.error("Unexpected error:", error);
      await loadGameState();
    } finally {
      // Clear updating flag after a short delay
      setTimeout(() => {
        isUpdatingRef.current = false;
      }, 500);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Tic Tac Toe</CardTitle>
        <CardDescription>
          <div
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-bold ${
              gameOver
                ? "bg-muted text-muted-foreground"
                : isMyTurn
                  ? "bg-primary text-primary-foreground animate-pulse shadow-lg"
                  : "bg-muted text-muted-foreground"
            }`}
          >
            {gameOver
              ? winner === "player"
                ? "You Win!"
                : winner === "opponent"
                  ? "Opponent Wins!"
                  : "Draw!"
              : isMyTurn
                ? `⚡ YOUR TURN (${mySymbol})`
                : `⏳ OPPONENT'S TURN (${opponentSymbol})`}
          </div>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-2 mb-4">
          {board.map((cell, index) => (
            <Button
              key={index}
              variant="outline"
              className={`h-20 text-2xl font-bold ${
                !gameOver && isMyTurn && cell === null
                  ? "hover:bg-primary/10 hover:scale-105 cursor-pointer transition-all"
                  : ""
              } ${cell !== null ? "cursor-not-allowed" : ""}`}
              onClick={() => handleCellClick(index)}
              disabled={gameOver || !isMyTurn || cell !== null}
            >
              {cell === "X" && <X className="w-8 h-8 text-primary" />}
              {cell === "O" && <Circle className="w-8 h-8 text-secondary" />}
            </Button>
          ))}
        </div>
        {gameOver && (
          <div className="text-center">
            <p className="text-lg font-semibold mb-2">
              {winner === "player" && "🎉 Victory!"}
              {winner === "opponent" && "😞 Better luck next time!"}
              {winner === "draw" && "🤝 It's a draw!"}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
