import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';

type UnoColor = 'red' | 'blue' | 'green' | 'yellow' | 'wild';
type UnoCardType = 'number' | 'skip' | 'reverse' | 'draw2' | 'wild' | 'wild4';

interface UnoCard {
  id: string;
  color: UnoColor;
  value: string;
  type: UnoCardType;
}

interface UnoGameState {
  deck: UnoCard[];
  discardPile: UnoCard[];
  player1Hand: UnoCard[];
  player2Hand: UnoCard[];
  currentPlayer: 'player1' | 'player2';
  direction: 1 | -1;
  initialized: boolean;
}

interface UnoGameProps {
  onGameEnd: (won: boolean) => void;
  challengeId: string;
  isCreator: boolean;
}

export const UnoGame = ({ onGameEnd, challengeId, isCreator }: UnoGameProps) => {
  const [gameState, setGameState] = useState<UnoGameState | null>(null);
  const [myHand, setMyHand] = useState<UnoCard[]>([]);
  const [opponentCardCount, setOpponentCardCount] = useState(7);
  const [topCard, setTopCard] = useState<UnoCard | null>(null);
  const [currentTurn, setCurrentTurn] = useState<'player1' | 'player2'>('player1');
  const [isMyTurn, setIsMyTurn] = useState(false);
  const [loading, setLoading] = useState(true);

  // Check if this is a test game
  const isTestGame = challengeId.startsWith('test-');
  const playerRole = isCreator ? 'player1' : 'player2';

  useEffect(() => {
    if (isTestGame) {
      // For test games, initialize locally without database
      const newDeck = createDeck();
      const player1Hand = newDeck.slice(0, 7);
      const player2Hand = newDeck.slice(7, 14);
      const firstCard = newDeck[14];
      const remainingDeck = newDeck.slice(15);

      const initialState: UnoGameState = {
        deck: remainingDeck,
        discardPile: [firstCard],
        player1Hand,
        player2Hand,
        currentPlayer: 'player1',
        direction: 1,
        initialized: true,
      };

      updateLocalState(initialState);
      setLoading(false);
      return;
    }

    initializeOrFetchGame();
    
    const channel = supabase
      .channel(`uno-game-${challengeId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'challenges',
          filter: `id=eq.${challengeId}`,
        },
        (payload) => {
          console.log('[UNO] Real-time update received:', payload);
          const newGameState = payload.new.game_state as UnoGameState;
          if (newGameState?.initialized) {
            console.log('[UNO] Updating to new state');
            updateLocalState(newGameState);
          }
        }
      )
      .subscribe((status) => {
        console.log('[UNO] Subscription status:', status);
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [challengeId, isCreator, isTestGame]);

  const createDeck = (): UnoCard[] => {
    const colors: UnoColor[] = ['red', 'blue', 'green', 'yellow'];
    const deck: UnoCard[] = [];
    let idCounter = 0;

    colors.forEach(color => {
      deck.push({ id: `${idCounter++}`, color, value: '0', type: 'number' });
      for (let i = 1; i <= 9; i++) {
        deck.push({ id: `${idCounter++}`, color, value: i.toString(), type: 'number' });
        deck.push({ id: `${idCounter++}`, color, value: i.toString(), type: 'number' });
      }
    });

    colors.forEach(color => {
      for (let i = 0; i < 2; i++) {
        deck.push({ id: `${idCounter++}`, color, value: 'Skip', type: 'skip' });
        deck.push({ id: `${idCounter++}`, color, value: 'Reverse', type: 'reverse' });
        deck.push({ id: `${idCounter++}`, color, value: '+2', type: 'draw2' });
      }
    });

    for (let i = 0; i < 4; i++) {
      deck.push({ id: `${idCounter++}`, color: 'wild', value: 'Wild', type: 'wild' });
      deck.push({ id: `${idCounter++}`, color: 'wild', value: '+4', type: 'wild4' });
    }

    return shuffleDeck(deck);
  };

  const shuffleDeck = (deck: UnoCard[]): UnoCard[] => {
    const shuffled = [...deck];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  const initializeOrFetchGame = async () => {
    console.log('[UNO] Fetching game state for challenge:', challengeId);
    
    const { data: challenge, error } = await supabase
      .from('challenges')
      .select('game_state')
      .eq('id', challengeId)
      .single();

    if (error) {
      console.error('[UNO] Error fetching challenge:', error);
      setLoading(false);
      return;
    }

    const existingState = challenge?.game_state as unknown as UnoGameState | null;
    console.log('[UNO] Existing state:', existingState);

    if (existingState?.initialized) {
      console.log('[UNO] Found existing state, using it');
      updateLocalState(existingState);
      setLoading(false);
    } else if (isCreator) {
      console.log('[UNO] Creator initializing new game');
      const newDeck = createDeck();
      const player1Hand = newDeck.slice(0, 7);
      const player2Hand = newDeck.slice(7, 14);
      const firstCard = newDeck[14];
      const remainingDeck = newDeck.slice(15);

      const initialState: UnoGameState = {
        deck: remainingDeck,
        discardPile: [firstCard],
        player1Hand,
        player2Hand,
        currentPlayer: 'player1',
        direction: 1,
        initialized: true,
      };

      const { error: updateError } = await supabase
        .from('challenges')
        .update({ game_state: initialState as any })
        .eq('id', challengeId);

      if (updateError) {
        console.error('[UNO] Error initializing game:', updateError);
      } else {
        console.log('[UNO] Game initialized successfully');
      }

      updateLocalState(initialState);
      setLoading(false);
    } else {
      console.log('[UNO] Non-creator waiting for game initialization...');
    }
  };

  const updateLocalState = (state: UnoGameState) => {
    setGameState(state);
    setMyHand(playerRole === 'player1' ? state.player1Hand : state.player2Hand);
    setOpponentCardCount(playerRole === 'player1' ? state.player2Hand.length : state.player1Hand.length);
    setTopCard(state.discardPile[state.discardPile.length - 1]);
    setCurrentTurn(state.currentPlayer);
    setIsMyTurn(state.currentPlayer === playerRole);

    // Check win conditions
    const myCards = playerRole === 'player1' ? state.player1Hand : state.player2Hand;
    const opponentCards = playerRole === 'player1' ? state.player2Hand : state.player1Hand;

    if (myCards.length === 0) {
      setTimeout(() => onGameEnd(true), 500);
    } else if (opponentCards.length === 0) {
      setTimeout(() => onGameEnd(false), 500);
    }
  };

  const canPlayCard = (card: UnoCard): boolean => {
    if (!topCard) return false;
    if (card.color === 'wild') return true;
    if (card.color === topCard.color) return true;
    if (card.value === topCard.value) return true;
    return false;
  };

  const playCard = async (card: UnoCard) => {
    console.log('[UNO] playCard called:', { card, isMyTurn, gameState: gameState?.currentPlayer });
    
    if (!isMyTurn || !gameState) {
      toast.error("It's not your turn!");
      return;
    }

    if (!canPlayCard(card)) {
      toast.error("Can't play this card!");
      return;
    }

    const updatedHand = myHand.filter(c => c.id !== card.id);
    const updatedDiscard = [...gameState.discardPile, card];

    let nextPlayer: 'player1' | 'player2' = currentTurn === 'player1' ? 'player2' : 'player1';
    let updatedDirection = gameState.direction;

    // Handle special cards
    if (card.type === 'reverse') {
      updatedDirection = gameState.direction === 1 ? -1 : 1;
      nextPlayer = currentTurn; // In 2-player, reverse acts like skip
    } else if (card.type === 'skip') {
      // Skip stays on current player's turn in 2-player
      nextPlayer = currentTurn;
    }

    const updatedState: UnoGameState = {
      ...gameState,
      discardPile: updatedDiscard,
      player1Hand: playerRole === 'player1' ? updatedHand : gameState.player1Hand,
      player2Hand: playerRole === 'player2' ? updatedHand : gameState.player2Hand,
      currentPlayer: nextPlayer,
      direction: updatedDirection,
    };

    if (isTestGame) {
      updateLocalState(updatedState);
      if (updatedHand.length === 1) {
        toast.success('UNO! You have one card left!');
      }
      return;
    }

    console.log('[UNO] Updating database with new state:', updatedState);

    const { data, error } = await supabase
      .from('challenges')
      .update({ game_state: updatedState as any })
      .eq('id', challengeId)
      .select();

    if (error) {
      console.error('[UNO] Error updating state:', error);
      toast.error('Failed to update game state');
      return;
    }

    console.log('[UNO] Database updated successfully:', data);

    if (updatedHand.length === 1) {
      toast.success('UNO! You have one card left!');
    }
  };

  const drawCard = async () => {
    console.log('[UNO] drawCard called:', { isMyTurn, deckLength: gameState?.deck.length });
    
    if (!isMyTurn || !gameState) {
      toast.error("It's not your turn!");
      return;
    }

    if (gameState.deck.length === 0) {
      toast.error('Deck is empty!');
      return;
    }

    const drawnCard = gameState.deck[0];
    const remainingDeck = gameState.deck.slice(1);
    const updatedHand = [...myHand, drawnCard];

    const nextPlayer: 'player1' | 'player2' = currentTurn === 'player1' ? 'player2' : 'player1';

    const updatedState: UnoGameState = {
      ...gameState,
      deck: remainingDeck,
      player1Hand: playerRole === 'player1' ? updatedHand : gameState.player1Hand,
      player2Hand: playerRole === 'player2' ? updatedHand : gameState.player2Hand,
      currentPlayer: nextPlayer,
    };

    if (isTestGame) {
      updateLocalState(updatedState);
      toast.info('Drew a card');
      return;
    }

    console.log('[UNO] Updating database after draw');

    const { data, error } = await supabase
      .from('challenges')
      .update({ game_state: updatedState as any })
      .eq('id', challengeId)
      .select();

    if (error) {
      console.error('[UNO] Error updating state:', error);
      toast.error('Failed to draw card');
      return;
    }

    console.log('[UNO] Draw successful:', data);
    toast.info('Drew a card');
  };

  const getCardColor = (color: UnoColor): string => {
    switch (color) {
      case 'red': return 'bg-red-500';
      case 'blue': return 'bg-blue-500';
      case 'green': return 'bg-green-500';
      case 'yellow': return 'bg-yellow-500';
      case 'wild': return 'bg-gradient-to-br from-red-500 via-blue-500 to-green-500';
      default: return 'bg-gray-500';
    }
  };

  if (loading || !gameState) {
    return <div className="text-center">Loading game...</div>;
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="text-center text-2xl bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
          UNO Battle
        </CardTitle>
        <div className="text-center space-y-1">
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-sm ${
            isMyTurn 
              ? 'bg-primary text-primary-foreground animate-pulse shadow-lg' 
              : 'bg-muted text-muted-foreground'
          }`}>
            {isMyTurn ? '⚡ YOUR TURN' : "⏳ OPPONENT'S TURN"}
          </div>
          <p className="text-xs text-muted-foreground">Cards in deck: {gameState.deck.length}</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Opponent */}
        <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
          <span className="text-sm font-semibold">Opponent</span>
          <span className="text-sm">{opponentCardCount} cards</span>
        </div>

        {/* Game Area */}
        <div className="flex justify-center items-center gap-4">
          <Button onClick={drawCard} variant="outline" disabled={!isMyTurn}>
            Draw Card
            <div className="ml-2 w-8 h-8 rounded bg-muted flex items-center justify-center text-xs">
              {gameState.deck.length}
            </div>
          </Button>

          {/* Discard Pile */}
          {topCard && (
            <div className={cn(
              'w-20 h-28 rounded-lg flex items-center justify-center text-white font-bold text-lg shadow-lg',
              getCardColor(topCard.color)
            )}>
              {topCard.value}
            </div>
          )}
        </div>

        {/* Player Hand */}
        <div>
          <p className="text-sm font-semibold mb-2">Your Hand ({myHand.length} cards):</p>
          <div className="flex gap-2 flex-wrap justify-center">
            {myHand.map((card) => (
              <button
                key={card.id}
                onClick={() => playCard(card)}
                disabled={!isMyTurn || !canPlayCard(card)}
                className={cn(
                  'w-16 h-24 rounded-lg flex items-center justify-center text-white font-bold shadow-lg transition-all',
                  getCardColor(card.color),
                  isMyTurn && canPlayCard(card) 
                    ? 'hover:scale-110 hover:shadow-xl cursor-pointer' 
                    : 'opacity-50 cursor-not-allowed'
                )}
              >
                {card.value}
              </button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};