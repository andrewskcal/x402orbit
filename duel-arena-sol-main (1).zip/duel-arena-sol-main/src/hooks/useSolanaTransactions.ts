import { useWallet } from '@solana/wallet-adapter-react';
import { useState, useCallback } from 'react';
import { toast } from 'sonner';
import {
  getSolBalance,
  validateBalance,
  sendDepositToEscrow,
  distributeFunds,
  refundDeposit,
  verifyTransaction,
} from '@/lib/solana';

export function useSolanaTransactions() {
  const wallet = useWallet();
  const [isProcessing, setIsProcessing] = useState(false);
  const [balance, setBalance] = useState<number | null>(null);

  /**
   * Get user's SOL balance
   */
  const fetchBalance = useCallback(async () => {
    if (!wallet.publicKey) {
      setBalance(null);
      return null;
    }

    try {
      const bal = await getSolBalance(wallet.publicKey);
      setBalance(bal);
      return bal;
    } catch (error) {
      console.error('Error fetching balance:', error);
      toast.error('Failed to fetch balance');
      return null;
    }
  }, [wallet.publicKey]);

  /**
   * Validate if user can make a bet
   */
  const canMakeBet = useCallback(async (betAmount: number) => {
    if (!wallet.publicKey) {
      toast.error('Please connect your wallet');
      return false;
    }

    try {
      const validation = await validateBalance(wallet.publicKey, betAmount);
      
      if (!validation.valid) {
        toast.error(validation.message || 'Invalid bet amount');
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error validating balance:', error);
      toast.error('Failed to validate balance');
      return false;
    }
  }, [wallet.publicKey]);

  /**
   * Send deposit to escrow
   */
  const deposit = useCallback(async (betAmount: number, challengeId: string) => {
    if (!wallet.publicKey) {
      toast.error('Please connect your wallet');
      return null;
    }

    setIsProcessing(true);
    
    try {
      // Validate balance first
      const canBet = await canMakeBet(betAmount);
      if (!canBet) {
        setIsProcessing(false);
        return null;
      }

      toast.info('Preparing transaction...', { duration: 2000 });

      const result = await sendDepositToEscrow(wallet, betAmount, challengeId);
      
      toast.success(`Deposit successful! ${betAmount} SOL locked in escrow`, {
        description: `TX: ${result.signature.slice(0, 8)}...`,
      });

      // Refresh balance
      await fetchBalance();

      return result;
    } catch (error: any) {
      console.error('Deposit error:', error);
      
      if (error.message.includes('User rejected')) {
        toast.error('Transaction cancelled');
      } else if (error.message.includes('insufficient')) {
        toast.error('Insufficient funds for transaction');
      } else {
        toast.error('Deposit failed', {
          description: error.message || 'Please try again',
        });
      }
      
      return null;
    } finally {
      setIsProcessing(false);
    }
  }, [wallet, canMakeBet, fetchBalance]);

  /**
   * Distribute funds to winner
   */
  const payout = useCallback(async (
    challengeId: string,
    winnerAddress: string,
    totalAmount: number
  ) => {
    setIsProcessing(true);
    
    try {
      toast.info('Processing payout...', { duration: 2000 });

      const signature = await distributeFunds(
        wallet,
        challengeId,
        winnerAddress,
        totalAmount
      );

      const winnerAmount = totalAmount * (1 - 0.0375);
      
      toast.success(`Payout successful!`, {
        description: `Winner received ${winnerAmount.toFixed(4)} SOL`,
      });

      return signature;
    } catch (error: any) {
      console.error('Payout error:', error);
      toast.error('Payout failed', {
        description: error.message || 'Please try again',
      });
      return null;
    } finally {
      setIsProcessing(false);
    }
  }, [wallet]);

  /**
   * Refund deposit
   */
  const refund = useCallback(async (
    challengeId: string,
    recipientAddress: string,
    amount: number
  ) => {
    setIsProcessing(true);
    
    try {
      toast.info('Processing refund...', { duration: 2000 });

      const signature = await refundDeposit(
        wallet,
        challengeId,
        recipientAddress,
        amount
      );

      toast.success(`Refund successful!`, {
        description: `${amount} SOL returned`,
      });

      await fetchBalance();

      return signature;
    } catch (error: any) {
      console.error('Refund error:', error);
      toast.error('Refund failed', {
        description: error.message || 'Please try again',
      });
      return null;
    } finally {
      setIsProcessing(false);
    }
  }, [wallet, fetchBalance]);

  /**
   * Verify a transaction
   */
  const verify = useCallback(async (signature: string) => {
    try {
      return await verifyTransaction(signature);
    } catch (error) {
      console.error('Verification error:', error);
      return false;
    }
  }, []);

  return {
    balance,
    isProcessing,
    fetchBalance,
    canMakeBet,
    deposit,
    payout,
    refund,
    verify,
  };
}
