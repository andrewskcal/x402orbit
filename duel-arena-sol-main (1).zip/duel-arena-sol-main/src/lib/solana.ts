import { 
  Connection, 
  PublicKey, 
  Transaction, 
  SystemProgram,
  LAMPORTS_PER_SOL,
  Keypair,
  TransactionMessage,
  VersionedTransaction
} from '@solana/web3.js';
import { WalletContextState } from '@solana/wallet-adapter-react';

// Platform fee wallet - Production wallet for receiving platform fees
export const PLATFORM_FEE_WALLET = new PublicKey('2D9kEZjkU16nWYj5HwtFaSVkGNkFyHGAsN7N28ohSq18');

// Fee configuration
export const PLATFORM_FEE_PERCENTAGE = 3.75; // 3.75%
export const MIN_BET_AMOUNT = 0.00001; // SOL
export const RENT_EXEMPT_MINIMUM = 0.00089088; // Minimum rent-exempt balance for escrow accounts

/**
 * Get Solana connection with Helius RPC
 */
export function getSolanaConnection(): Connection {
  const rpcUrl = import.meta.env.VITE_SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com';
  return new Connection(rpcUrl, 'confirmed');
}

/**
 * Get user's SOL balance
 */
export async function getSolBalance(publicKey: PublicKey): Promise<number> {
  try {
    const connection = getSolanaConnection();
    const balance = await connection.getBalance(publicKey);
    return balance / LAMPORTS_PER_SOL;
  } catch (error) {
    console.error('Error getting SOL balance:', error);
    throw error;
  }
}

/**
 * Validate if user has enough SOL for bet
 */
export async function validateBalance(
  publicKey: PublicKey, 
  betAmount: number
): Promise<{ valid: boolean; balance: number; message?: string }> {
  try {
    const balance = await getSolBalance(publicKey);
    const requiredAmount = betAmount + 0.002; // Add buffer for transaction fees + rent
    
    if (balance < requiredAmount) {
      return {
        valid: false,
        balance,
        message: `Insufficient balance. You have ${balance.toFixed(4)} SOL, need ${requiredAmount.toFixed(4)} SOL`
      };
    }
    
    if (betAmount < MIN_BET_AMOUNT) {
      return {
        valid: false,
        balance,
        message: `Minimum bet is ${MIN_BET_AMOUNT} SOL`
      };
    }
    
    return { valid: true, balance };
  } catch (error) {
    console.error('Error validating balance:', error);
    throw error;
  }
}

/**
 * Browser-compatible SHA-256 hash function
 */
async function sha256(message: string): Promise<Uint8Array> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  return new Uint8Array(hashBuffer);
}

/**
 * Create escrow account for a challenge
 * Returns the escrow account public key
 */
export async function createEscrowAccount(challengeId: string): Promise<Keypair> {
  // Generate deterministic keypair from challenge ID using browser's Web Crypto API
  const hash = await sha256(challengeId);
  return Keypair.fromSeed(hash.slice(0, 32));
}

/**
 * Send deposit transaction to escrow - Creates account if needed, otherwise transfers
 */
export async function sendDepositToEscrow(
  wallet: WalletContextState,
  betAmount: number,
  challengeId: string
): Promise<{ signature: string; escrowAccount: string }> {
  if (!wallet.publicKey || !wallet.signTransaction) {
    throw new Error('Wallet not connected');
  }

  try {
    const connection = getSolanaConnection();
    const escrowKeypair = await createEscrowAccount(challengeId);
    
    const betLamports = Math.floor(betAmount * LAMPORTS_PER_SOL);
    const rentLamports = Math.floor(RENT_EXEMPT_MINIMUM * LAMPORTS_PER_SOL);

    // Check if escrow account exists
    const accountInfo = await connection.getAccountInfo(escrowKeypair.publicKey);
    
    const instructions = [];

    if (!accountInfo) {
      // Account doesn't exist - create it with rent + bet amount
      console.log('Creating new escrow account with deposit...');
      instructions.push(
        SystemProgram.createAccount({
          fromPubkey: wallet.publicKey,
          newAccountPubkey: escrowKeypair.publicKey,
          lamports: rentLamports + betLamports,
          space: 0,
          programId: SystemProgram.programId,
        })
      );
    } else {
      // Account exists - just transfer
      console.log('Transferring to existing escrow...');
      instructions.push(
        SystemProgram.transfer({
          fromPubkey: wallet.publicKey,
          toPubkey: escrowKeypair.publicKey,
          lamports: betLamports,
        })
      );
    }

    const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('confirmed');

    // If creating account, need to sign with escrow keypair too
    if (!accountInfo) {
      // Use legacy transaction for multi-sig
      const legacyTx = new Transaction();
      legacyTx.recentBlockhash = blockhash;
      legacyTx.feePayer = wallet.publicKey;
      legacyTx.add(...instructions);
      
      // Simulate transaction first to catch errors (with sigVerify: false)
      try {
        const simulation = await connection.simulateTransaction(legacyTx, undefined, false);
        if (simulation.value.err) {
          throw new Error(`Transaction simulation failed: ${JSON.stringify(simulation.value.err)}`);
        }
      } catch (simError) {
        console.warn('Simulation warning (may be ok):', simError);
      }
      
      // IMPORTANT: Sign with Phantom FIRST (to avoid warning)
      const walletSignedTx = await wallet.signTransaction(legacyTx);
      
      // Then add escrow signature
      walletSignedTx.partialSign(escrowKeypair);
      
      const signature = await connection.sendRawTransaction(
        walletSignedTx.serialize(),
        { skipPreflight: false, preflightCommitment: 'confirmed' }
      );
      
      await connection.confirmTransaction({
        signature,
        blockhash,
        lastValidBlockHeight
      }, 'confirmed');

      console.log('Deposit successful (new escrow):', signature);
      return {
        signature,
        escrowAccount: escrowKeypair.publicKey.toString()
      };
    } else {
      // Just transfer - simpler with VersionedTransaction
      const messageV0 = new TransactionMessage({
        payerKey: wallet.publicKey,
        recentBlockhash: blockhash,
        instructions,
      }).compileToV0Message();

      const transaction = new VersionedTransaction(messageV0);
      const signedTransaction = await wallet.signTransaction(transaction);

      const signature = await connection.sendRawTransaction(
        signedTransaction.serialize(),
        { skipPreflight: false, preflightCommitment: 'confirmed' }
      );
      
      await connection.confirmTransaction({
        signature,
        blockhash,
        lastValidBlockHeight
      }, 'confirmed');

      console.log('Deposit successful (existing escrow):', signature);
      return {
        signature,
        escrowAccount: escrowKeypair.publicKey.toString()
      };
    }
  } catch (error) {
    console.error('Error sending deposit:', error);
    throw error;
  }
}

/**
 * Distribute funds from escrow to winner and platform
 */
export async function distributeFunds(
  wallet: WalletContextState,
  challengeId: string,
  winnerAddress: string,
  totalAmount: number
): Promise<string> {
  if (!wallet.publicKey || !wallet.signTransaction) {
    throw new Error('Wallet not connected');
  }

  try {
    const connection = getSolanaConnection();
    const escrowKeypair = await createEscrowAccount(challengeId);
    const winnerPubkey = new PublicKey(winnerAddress);
    
    // Get actual escrow balance
    const escrowBalance = await connection.getBalance(escrowKeypair.publicKey);
    
    // We need to leave enough for transaction fees (5000 lamports minimum)
    const txFeeLamports = 5000;
    const distributableLamports = escrowBalance - txFeeLamports;
    
    if (distributableLamports <= 0) {
      throw new Error('Insufficient funds in escrow for distribution');
    }
    
    const platformFeeLamports = Math.floor(distributableLamports * (PLATFORM_FEE_PERCENTAGE / 100));
    const winnerLamports = distributableLamports - platformFeeLamports;

    console.log('Distribution breakdown:', {
      escrowBalance: escrowBalance / LAMPORTS_PER_SOL,
      distributable: distributableLamports / LAMPORTS_PER_SOL,
      platformFee: platformFeeLamports / LAMPORTS_PER_SOL,
      winner: winnerLamports / LAMPORTS_PER_SOL,
      txFee: txFeeLamports / LAMPORTS_PER_SOL
    });

    const transaction = new Transaction();

    // Transfer to winner
    transaction.add(
      SystemProgram.transfer({
        fromPubkey: escrowKeypair.publicKey,
        toPubkey: winnerPubkey,
        lamports: winnerLamports,
      })
    );

    // Transfer platform fee
    transaction.add(
      SystemProgram.transfer({
        fromPubkey: escrowKeypair.publicKey,
        toPubkey: PLATFORM_FEE_WALLET,
        lamports: platformFeeLamports,
      })
    );

    // Get recent blockhash
    const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = escrowKeypair.publicKey;

    // Sign with escrow keypair
    transaction.sign(escrowKeypair);

    // Send and confirm transaction
    const signature = await connection.sendRawTransaction(transaction.serialize(), {
      skipPreflight: false,
      preflightCommitment: 'finalized'
    });
    
    await connection.confirmTransaction({
      signature,
      blockhash,
      lastValidBlockHeight
    }, 'finalized');

    console.log('Distribution successful:', signature);

    return signature;
  } catch (error) {
    console.error('Error distributing funds:', error);
    throw error;
  }
}

/**
 * Refund deposit from escrow (for cancelled games)
 */
export async function refundDeposit(
  challengeId: string,
  recipientAddress: string
): Promise<string> {
  try {
    const connection = getSolanaConnection();
    const escrowKeypair = await createEscrowAccount(challengeId);
    const recipientPubkey = new PublicKey(recipientAddress);
    
    // Get actual escrow balance
    const escrowBalance = await connection.getBalance(escrowKeypair.publicKey);
    
    // Keep minimum for transaction fee
    const txFeeLamports = 15000;
    const refundLamports = escrowBalance - txFeeLamports;
    
    if (refundLamports <= 0) {
      throw new Error('Insufficient funds in escrow for refund');
    }

    console.log('Refund breakdown:', {
      escrowBalance: escrowBalance / LAMPORTS_PER_SOL,
      refund: refundLamports / LAMPORTS_PER_SOL,
      txFee: txFeeLamports / LAMPORTS_PER_SOL
    });

    const transaction = new Transaction().add(
      SystemProgram.transfer({
        fromPubkey: escrowKeypair.publicKey,
        toPubkey: recipientPubkey,
        lamports: refundLamports,
      })
    );

    const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = escrowKeypair.publicKey;

    transaction.sign(escrowKeypair);

    const signature = await connection.sendRawTransaction(transaction.serialize(), {
      skipPreflight: false,
      preflightCommitment: 'finalized'
    });
    
    await connection.confirmTransaction({
      signature,
      blockhash,
      lastValidBlockHeight
    }, 'finalized');

    console.log('Refund successful:', signature);

    return signature;
  } catch (error) {
    console.error('Error refunding deposit:', error);
    throw error;
  }
}

/**
 * Verify transaction on-chain
 */
export async function verifyTransaction(signature: string): Promise<boolean> {
  try {
    const connection = getSolanaConnection();
    const status = await connection.getSignatureStatus(signature);
    
    return status?.value?.confirmationStatus === 'confirmed' || 
           status?.value?.confirmationStatus === 'finalized';
  } catch (error) {
    console.error('Error verifying transaction:', error);
    return false;
  }
}
