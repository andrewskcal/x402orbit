import { useState, useEffect } from "react";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { useWallet } from "@solana/wallet-adapter-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Loader2, Clock, AlertCircle, Wallet } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useSolanaTransactions } from "@/hooks/useSolanaTransactions";

const AcceptChallenge = () => {
  const { challengeId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { publicKey } = useWallet();
  const [isDepositing, setIsDepositing] = useState(false);
  const [challenge, setChallenge] = useState<any>(null);
  const [isExpired, setIsExpired] = useState(false);
  const { user, session, requireAuth, loading: authLoading } = useAuth();
  const { balance, fetchBalance, deposit, isProcessing } = useSolanaTransactions();

  const gameType = searchParams.get("game");
  const amount = searchParams.get("amount");
  const creator = searchParams.get("creator");
  const roundsParam = searchParams.get("rounds");
  const rounds = roundsParam ? parseInt(roundsParam) : 2;

  // Fetch balance when wallet connects
  useEffect(() => {
    if (publicKey) {
      fetchBalance();
    }
  }, [publicKey, fetchBalance]);

  useEffect(() => {
    if (!authLoading) {
      requireAuth();
    }
  }, [authLoading]);

  useEffect(() => {
    const fetchChallenge = async () => {
      const { data, error } = await supabase.from("challenges").select("*").eq("id", challengeId).single();

      if (error) {
        toast.error("Challenge not found");
        navigate("/");
        return;
      }

      setChallenge(data);

      // Check if challenge has expired
      if (data.expires_at) {
        const expirationTime = new Date(data.expires_at);
        const now = new Date();
        if (now > expirationTime) {
          setIsExpired(true);
          toast.error("This challenge has expired");
        }
      }
    };

    if (challengeId) {
      fetchChallenge();
    }
  }, [challengeId, navigate]);

  const getGameTitle = () => {
    switch (gameType) {
      case "chess":
        return "Chess";
      case "uno":
        return "UNO";
      case "rock-paper-scissors":
        return "Rock Paper Scissors";
      case "coin-flip":
        return "Coin Flip";
      case "dice-roll":
        return "Dice Roll";
      case "tic-tac-toe":
        return "Tic Tac Toe";
      case "connect-four":
        return "Connect Four";
      case "higher-lower":
        return "Higher or Lower";
      case "number-duel":
        return "Number Duel";
      default:
        return "Game";
    }
  };

  const handleDeposit = async () => {
    if (!publicKey || !user || !session) {
      toast.error("Please connect your wallet and sign in");
      return;
    }

    if (!challenge) {
      toast.error("Challenge not found");
      return;
    }

    if (isExpired) {
      toast.error("This challenge has expired");
      return;
    }

    setIsDepositing(true);

    try {
      let depositResult = null;

      // Process real deposit - ALWAYS REAL MONEY
      const betAmount = parseFloat(amount || "0");

      // Send deposit to escrow
      depositResult = await deposit(betAmount, challengeId!);

      if (!depositResult) {
        throw new Error("Deposit failed");
      }

      toast.success("Deposit confirmed! Joining game...", { duration: 2000 });

      console.log("Updating challenge with opponent wallet:", publicKey.toString());
      console.log("Challenge ID:", challengeId);

      const { data: updateData, error: updateError } = await supabase
        .from("challenges")
        .update({
          opponent_wallet: publicKey.toString().toLowerCase(), // FIX: Store as lowercase to match creator_wallet
          opponent_deposited: !!depositResult,
          status: "in_progress",
          started_at: new Date().toISOString(),
          game_state: depositResult
            ? {
                ...challenge.game_state,
                opponent_tx: depositResult.signature,
              }
            : challenge.game_state,
        })
        .eq("id", challengeId)
        .select();

      console.log("Update result:", updateData, updateError);

      if (!updateData || updateData.length === 0) {
        console.error("Challenge update did not return data");
        throw new Error("Failed to update challenge - no data returned");
      }

      console.log("Successfully updated challenge:", updateData[0]);

      if (updateError) {
        console.error("Failed to update challenge:", updateError);
        throw updateError;
      }

      toast.success("Challenge accepted! Funds locked in escrow", { duration: 3000 });

      await new Promise((resolve) => setTimeout(resolve, 1000));

      // FIX: Use lowercase for navigation consistency
      navigate(
        `/game/${challengeId}?game=${gameType}&amount=${amount}&creator=${creator}&opponent=${publicKey.toString().toLowerCase()}&rounds=${rounds}`,
      );
    } catch (error: any) {
      console.error("Failed to accept challenge:", error);

      if (error.message?.includes("User rejected")) {
        toast.error("Transaction cancelled");
      } else {
        toast.error("Failed to accept challenge: " + (error?.message || "Please try again"));
      }
    } finally {
      setIsDepositing(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="max-w-md mx-auto">
          <Card className="border border-border bg-card shadow-lg">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl font-semibold text-foreground">Join Room</CardTitle>
                  <CardDescription className="mt-1">Ready to play {getGameTitle()}?</CardDescription>
                </div>
                <Badge variant="default" className="bg-success text-success-foreground">
                  Real SOL
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-5">
              {/* Balance Display */}
              {publicKey && balance !== null && (
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg border border-border">
                  <div className="flex items-center gap-2">
                    <Wallet className="w-4 h-4 text-primary" />
                    <span className="text-sm font-semibold">Your Balance:</span>
                  </div>
                  <span className="text-sm font-black text-primary">{balance.toFixed(4)} SOL</span>
                </div>
              )}

              {isExpired && (
                <Alert variant="destructive" className="bg-destructive/10 border-destructive/30">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>Room expired</AlertDescription>
                </Alert>
              )}

              <div className="p-4 bg-muted rounded-md space-y-2.5">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Game:</span>
                  <span className="font-semibold">{getGameTitle()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rounds:</span>
                  <span className="font-semibold">Best of {rounds}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Bet:</span>
                  <span className="font-semibold">{amount} SOL</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">You Win:</span>
                  <span className="font-semibold text-accent">
                    {amount ? (parseFloat(amount) * 2 * 0.9625).toFixed(4) : "0.0000"} SOL
                  </span>
                </div>
                <div className="pt-2 border-t border-border">
                  <p className="text-xs text-muted-foreground">96.25% payout • 3.75% platform fee</p>
                </div>
                {challenge?.expires_at && !isExpired && (
                  <div className="pt-3 border-t border-border flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    Expires in 5 min
                  </div>
                )}
              </div>

              <div className="space-y-2.5">
                <Button
                  onClick={handleDeposit}
                  disabled={isDepositing || isProcessing || !publicKey || !user || isExpired}
                  className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 text-primary-foreground font-bold h-11 text-base uppercase tracking-wide"
                  size="lg"
                >
                  {isDepositing || isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Depositing...
                    </>
                  ) : isExpired ? (
                    "Room Expired"
                  ) : (
                    <>Deposit {amount} SOL & Join</>
                  )}
                </Button>
                {!isExpired && (
                  <p className="text-xs text-center text-muted-foreground">
                    You will be prompted to approve the transaction
                  </p>
                )}
                <Button
                  onClick={() => navigate("/matchmaking")}
                  variant="outline"
                  size="sm"
                  className="w-full"
                  disabled={isDepositing || isProcessing}
                >
                  Back to Rooms
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AcceptChallenge;
