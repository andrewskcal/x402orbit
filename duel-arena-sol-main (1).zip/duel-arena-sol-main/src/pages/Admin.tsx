import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Gamepad2 } from 'lucide-react';
import { toast } from 'sonner';

const Admin = () => {
  const navigate = useNavigate();

  const games = [
    // 1v1 Competitive Games Only
    { id: 'chess', name: 'Chess', desc: 'Strategic board game' },
    { id: 'uno', name: 'UNO', desc: '1v1 card battle' },
    { id: 'rock-paper-scissors', name: 'Rock Paper Scissors', desc: 'Best of multiple rounds' },
    { id: 'coin-flip', name: 'Coin Flip', desc: 'Heads or tails' },
    { id: 'dice-roll', name: 'Dice Roll', desc: 'Highest roll wins' },
    { id: 'tic-tac-toe', name: 'Tic Tac Toe', desc: 'Classic 3x3 grid' },
    { id: 'connect-four', name: 'Connect Four', desc: 'Connect 4 in a row' },
    { id: 'higher-lower', name: 'Higher or Lower', desc: 'Higher card wins' },
    { id: 'number-duel', name: 'Number Duel', desc: 'Closest to target' },
  ];

  const playGame = (gameId: string) => {
    const testUrl = `/game/test-${gameId}?game=${gameId}&amount=0&creator=test&opponent=test&rounds=2`;
    
    // Copy link to clipboard for easy sharing
    const fullUrl = `${window.location.origin}${testUrl}`;
    navigator.clipboard.writeText(fullUrl);
    
    toast.success('Test link copied!', {
      description: 'Share with friends to play without deposits or wallets.'
    });
    
    navigate(testUrl);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 pt-24 pb-12">
        <Card className="max-w-2xl mx-auto border border-border bg-card shadow-lg">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-2xl font-semibold">
              <Gamepad2 className="w-5 h-5 text-primary" />
              Test Games
            </CardTitle>
            <CardDescription>
              No deposits, no wallets. Share links with friends to test instantly.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {games.map((game) => (
                <Button
                  key={game.id}
                  onClick={() => playGame(game.id)}
                  variant="outline"
                  className="w-full justify-start h-auto py-3 hover:bg-muted hover:border-primary/40"
                >
                  <div className="text-left">
                    <div className="font-medium text-sm">{game.name}</div>
                    <div className="text-xs text-muted-foreground">{game.desc}</div>
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Admin;