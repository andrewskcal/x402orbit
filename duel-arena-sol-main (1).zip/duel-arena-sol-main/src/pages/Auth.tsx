import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useWallet } from "@solana/wallet-adapter-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Wallet, Shield, Zap } from "lucide-react";

const Auth = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { publicKey, connected, signMessage } = useWallet();
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  // Get the page they were on before auth, or default to home
  const from = (location.state as any)?.from || "/";

  useEffect(() => {
    // Scroll to top on page load
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    // Check if user is already logged in
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        navigate(from, { replace: true });
      }
    });
  }, [navigate, from]);

  useEffect(() => {
    // Auto-authenticate when wallet connects
    if (!publicKey || !connected || !signMessage || isAuthenticating) return;

    const authenticateWallet = async () => {
      // Check if user already has a valid session
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        console.log("User already has valid session");
        navigate(from, { replace: true });
        return;
      }

      setIsAuthenticating(true);
      
      try {
        const walletAddress = publicKey.toString();
        console.log("Authenticating wallet:", walletAddress);

        // Create deterministic credentials from wallet address
        const walletEmail = `${walletAddress}@wallet.duelarena.app`;
        const passwordSource = `duelarena:${walletAddress}`;
        
        // Generate password hash
        const encoder = new TextEncoder();
        const data: Uint8Array = encoder.encode(passwordSource);
        const hashBuffer: ArrayBuffer = await crypto.subtle.digest('SHA-256', data as BufferSource);
        const uint8Array = new Uint8Array(hashBuffer);
        const password = Array.from(uint8Array)
          .map(b => b.toString(16).padStart(2, '0'))
          .join('')
          .substring(0, 64);

        // Try to sign in first
        let { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
          email: walletEmail,
          password: password,
        });

        if (signInError && signInError.message?.includes('Invalid login credentials')) {
          // User doesn't exist, create new account
          console.log("Creating new user account...");
          
          const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
            email: walletEmail,
            password: password,
            options: {
              data: {
                wallet_address: walletAddress,
              }
            }
          });

          if (signUpError) {
            throw signUpError;
          }

          // After signup, sign in
          if (signUpData.user) {
            const { data: newSignIn, error: newSignInError } = await supabase.auth.signInWithPassword({
              email: walletEmail,
              password: password,
            });

            if (newSignInError) {
              throw newSignInError;
            }

            signInData = newSignIn;
          }
        } else if (signInError) {
          throw signInError;
        }

        // Link wallet address to user
        if (signInData?.user) {
          const walletAddressLower = walletAddress.toLowerCase();
          
          // Upsert wallet address
          const { error: walletError } = await supabase
            .from('user_wallets')
            .upsert({
              user_id: signInData.user.id,
              wallet_address: walletAddressLower,
            }, {
              onConflict: 'user_id,wallet_address',
            });

          if (walletError) {
            console.error("Error linking wallet:", walletError);
            // Don't throw - user is still authenticated
          }

          toast.success("Wallet connected! Redirecting...");
          setTimeout(() => {
            navigate(from, { replace: true });
          }, 1000);
        }

      } catch (error: any) {
        console.error("Auth error:", error);
        toast.error("Failed to authenticate. Please try again.");
        setIsAuthenticating(false);
      }
    };

    authenticateWallet();
  }, [publicKey, connected, signMessage, navigate, from, isAuthenticating]);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 flex items-center justify-center min-h-[calc(100vh-80px)]">
        <Card className="w-full max-w-lg border border-border bg-card shadow-lg">
          <CardHeader className="text-center space-y-3 pb-6">
            <div className="flex justify-center">
              <div className="p-3 rounded-lg bg-primary/10">
                <Wallet className="w-10 h-10 text-primary" />
              </div>
            </div>
            <CardTitle className="text-2xl font-semibold text-foreground">
              Connect Wallet
            </CardTitle>
            <CardDescription>
              Sign in with Phantom to start playing
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex justify-center">
              <WalletMultiButton className="!bg-primary !text-primary-foreground !font-medium !px-6 !py-2.5 !text-sm !rounded-md hover:!bg-primary/90 !transition-colors" />
            </div>

            {publicKey && (
              <div className="p-3 bg-muted rounded-md">
                <p className="text-sm text-center text-muted-foreground">
                  <span className="font-medium text-foreground">Connected:</span>{' '}
                  {publicKey.toString().slice(0, 8)}...{publicKey.toString().slice(-8)}
                </p>
                <p className="text-xs text-center text-muted-foreground mt-1.5">
                  {isAuthenticating ? 'Authenticating...' : 'Redirecting...'}
                </p>
              </div>
            )}

            <div className="grid grid-cols-1 gap-3 pt-3 border-t border-border">
              <div className="flex items-start gap-2.5">
                <Shield className="w-4 h-4 text-primary mt-0.5" />
                <div>
                  <h4 className="font-medium text-sm">Secure</h4>
                  <p className="text-xs text-muted-foreground">Your wallet, your identity</p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <Zap className="w-4 h-4 text-primary mt-0.5" />
                <div>
                  <h4 className="font-medium text-sm">Instant</h4>
                  <p className="text-xs text-muted-foreground">Start playing in seconds</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Auth;
