import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useWallet } from "@solana/wallet-adapter-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Loader2,
  Clock,
  Crown,
  Users,
  Hand,
  Coins,
  Dices,
  Grid3x3,
  CircleDot,
  TrendingUp as CardIcon,
  Hash,
  ChevronLeft,
  Wallet,
} from "lucide-react";
import { GameType } from "@/types/game";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useSolanaTransactions } from "@/hooks/useSolanaTransactions";

type Step = "select-game" | "configure" | "waiting";

const GAMES = [
  { type: "rock-paper-scissors" as GameType, icon: Hand, name: "Rock Paper Scissors", desc: "Quick reflex showdown" },
  { type: "coin-flip" as GameType, icon: Coins, name: "Coin Flip", desc: "Pure 50/50 luck" },
  { type: "dice-roll" as GameType, icon: Dices, name: "Dice Roll", desc: "Highest roll wins" },
  { type: "chess" as GameType, icon: Crown, name: "Chess", desc: "Strategy & tactics" },
  { type: "uno" as GameType, icon: Users, name: "UNO", desc: "Classic card game" },
  { type: "tic-tac-toe" as GameType, icon: Grid3x3, name: "Tic Tac Toe", desc: "3 in a row" },
  { type: "connect-four" as GameType, icon: CircleDot, name: "Connect Four", desc: "4 in a row wins" },
  { type: "higher-lower" as GameType, icon: CardIcon, name: "Higher or Lower", desc: "Card prediction" },
  { type: "number-duel" as GameType, icon: Hash, name: "Number Duel", desc: "Closest guess" },
];

const CreateChallenge = () => {
  const [searchParams] = useSearchParams();
  const urlGame = searchParams.get("game") as GameType;
  const { publicKey } = useWallet();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>(urlGame ? "configure" : "select-game");
  const [selectedGame, setSelectedGame] = useState<GameType | null>(urlGame || null);
  const [amount, setAmount] = useState("");
  const [rounds, setRounds] = useState(1);
  const [roomCreated, setRoomCreated] = useState(false);
  const [challengeId, setChallengeId] = useState("");
  const [isDepositing, setIsDepositing] = useState(false);
  const { user, session, requireAuth, loading: authLoading } = useAuth();
  const { balance, fetchBalance, deposit, isProcessing } = useSolanaTransactions();

  // Fetch balance when wallet connects
  useEffect(() => {
    if (publicKey) {
      fetchBalance();
    }
  }, [publicKey, fetchBalance]);

  // Listen to URL param changes to update selected game
  useEffect(() => {
    const gameParam = searchParams.get("game") as GameType;
    if (gameParam && gameParam !== selectedGame) {
      setSelectedGame(gameParam);
      setStep("configure");
    }
  }, [searchParams]);

  useEffect(() => {
    if (!authLoading) {
      requireAuth();
    }
  }, [authLoading]);

  // Scroll to top when page loads
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  // Subscribe to challenge updates to detect when opponent joins
  useEffect(() => {
    if (!challengeId || !publicKey) return;

    console.log("Room created, waiting for player to join...");

    let hasNavigated = false;

    // Polling to check if opponent joined
    const pollInterval = setInterval(async () => {
      if (hasNavigated) return;

      const { data, error } = await supabase
        .from("challenges")
        .select("opponent_wallet, status")
        .eq("id", challengeId)
        .maybeSingle();

      if (error) {
        console.error("Polling error:", error);
        return;
      }

      if (data?.opponent_wallet && !hasNavigated) {
        hasNavigated = true;
        console.log("Player joined! Starting game...");
        toast.success("Player joined! Starting game...");
        navigate(
          `/game/${challengeId}?game=${selectedGame}&amount=${amount}&creator=${publicKey.toString()}&opponent=${data.opponent_wallet}&rounds=${rounds}`,
        );
      }
    }, 1000);

    // Real-time subscription
    const channel = supabase
      .channel(`challenge-updates-${challengeId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "challenges",
          filter: `id=eq.${challengeId}`,
        },
        (payload) => {
          const updatedChallenge = payload.new as any;

          if (updatedChallenge.opponent_wallet && !hasNavigated) {
            hasNavigated = true;
            toast.success("Player joined! Starting game...");
            navigate(
              `/game/${challengeId}?game=${selectedGame}&amount=${amount}&creator=${publicKey.toString()}&opponent=${updatedChallenge.opponent_wallet}&rounds=${rounds}`,
            );
          }
        },
      )
      .subscribe();

    return () => {
      clearInterval(pollInterval);
      supabase.removeChannel(channel);
    };
  }, [challengeId, navigate, selectedGame, amount, rounds, publicKey]);

  const getSelectedGameData = () => {
    return GAMES.find((g) => g.type === selectedGame);
  };

  const handleGameSelect = (game: GameType) => {
    setSelectedGame(game);
    setStep("configure");
  };

  const createChallenge = async () => {
    if (!publicKey) {
      toast.error("Please connect your Phantom wallet to continue");
      navigate("/auth");
      return;
    }

    if (!user || !session) {
      toast.error("Please sign in with your wallet");
      navigate("/auth");
      return;
    }

    if (!selectedGame) {
      toast.error("Please select a game");
      return;
    }

    const betAmount = parseFloat(amount);

    if (!amount) {
      toast.error("Enter bet amount");
      return;
    }

    if (betAmount < 0.00001) {
      toast.error("Minimum bet is 0.00001 SOL");
      return;
    }

    setIsDepositing(true);
    setStep("waiting");

    try {
      // Step 1: Create challenge first to get the ID
      const expirationTime = new Date();
      expirationTime.setMinutes(expirationTime.getMinutes() + 5);

      const { data: challenge, error: createError } = await supabase
        .from("challenges")
        .insert({
          game_type: selectedGame,
          creator_wallet: publicKey.toString().toLowerCase(),
          bet_amount: betAmount,
          creator_deposited: false,
          status: "pending",
          rounds: rounds,
          is_demo: false,
          expires_at: expirationTime.toISOString(),
        })
        .select()
        .single();

      if (createError || !challenge) {
        console.error("Failed to create challenge:", createError);
        throw new Error("Failed to create challenge");
      }

      toast.success("Challenge created! Depositing funds...", { duration: 2000 });

      // Step 2: Send deposit with the challenge ID (this will create escrow)
      const depositResult = await deposit(betAmount, challenge.id);

      if (!depositResult) {
        // Delete the challenge if deposit failed
        await supabase.from("challenges").delete().eq("id", challenge.id);
        throw new Error("Deposit failed");
      }

      toast.success("Deposit confirmed! Opening room...", { duration: 2000 });

      // Step 3: Update challenge to "open" status
      const { error: updateError } = await supabase
        .from("challenges")
        .update({
          creator_deposited: true,
          status: "open",
          game_state: {
            escrow_account: depositResult.escrowAccount,
            creator_tx: depositResult.signature,
          },
        })
        .eq("id", challenge.id);

      if (updateError) {
        console.error("Failed to update challenge:", updateError);
        throw updateError;
      }

      setChallengeId(challenge.id);
      setRoomCreated(true);

      toast.success("Room created! Funds locked in escrow", { duration: 3000 });
    } catch (error: any) {
      console.error("Failed to create room:", error);
      toast.error("Failed: " + (error?.message || "Try again"));
      setStep("configure");
    } finally {
      setIsDepositing(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  const gameData = getSelectedGameData();
  const GameIcon = gameData?.icon;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="max-w-6xl mx-auto">
          {/* Step 1: Select Game */}
          {step === "select-game" && (
            <div className="space-y-8">
              <div className="text-center">
                <h1 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight mb-3 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
                  PICK YOUR GAME
                </h1>
                <p className="text-muted-foreground text-base sm:text-lg">Select your battleground</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {GAMES.map((game) => {
                  const Icon = game.icon;
                  return (
                    <button
                      key={game.type}
                      onClick={() => handleGameSelect(game.type)}
                      className="group relative p-6 rounded-xl bg-gradient-to-br from-card to-card/50 border-2 border-border hover:border-primary/50 transition-all hover:scale-105 text-left"
                    >
                      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                      <div className="relative space-y-4">
                        <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                          <Icon className="w-7 h-7 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-bold text-xl text-foreground mb-1">{game.name}</h3>
                          <p className="text-sm text-muted-foreground">{game.desc}</p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Step 2: Configure Bet & Rounds */}
          {step === "configure" && selectedGame && (
            <div className="max-w-2xl mx-auto space-y-6">
              <button
                onClick={() => setStep("select-game")}
                className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors group"
              >
                <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                <span className="text-sm font-medium">Change Game</span>
              </button>

              <div className="text-center mb-6 sm:mb-8">
                <div className="flex items-center justify-center gap-3 sm:gap-4 mb-3 sm:mb-4">
                  {GameIcon && (
                    <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-xl bg-primary/10 flex items-center justify-center">
                      <GameIcon className="w-6 h-6 sm:w-8 sm:h-8 text-primary" />
                    </div>
                  )}
                  <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    {gameData?.name.toUpperCase()}
                  </h1>
                </div>
                <p className="text-muted-foreground text-sm sm:text-base">Configure your match</p>
              </div>

              <Card className="border-2 border-border bg-gradient-to-b from-card to-card/50 shadow-2xl relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 pointer-events-none" />

                <CardContent className="space-y-6 sm:space-y-8 pt-6 sm:pt-8 pb-6 sm:pb-8 relative z-10">
                  {/* Balance Display */}
                  {publicKey && balance !== null && (
                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg border border-border">
                      <div className="flex items-center gap-2">
                        <Wallet className="w-4 h-4 text-primary" />
                        <span className="text-sm font-semibold">Your Balance:</span>
                      </div>
                      <span className="text-sm font-black text-primary">{balance.toFixed(4)} SOL</span>
                    </div>
                  )}

                  {/* Bet Amount */}
                  <div className="space-y-3 sm:space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-base sm:text-lg font-black uppercase tracking-wider text-foreground flex items-center gap-2">
                        <Coins className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                        BET AMOUNT
                      </Label>
                      <Badge variant="default" className="text-xs px-2 py-0.5 sm:px-2.5 sm:py-1 font-bold bg-success">
                        REAL SOL
                      </Badge>
                    </div>
                    <div className="relative group">
                      <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 via-accent/20 to-secondary/20 rounded-xl blur-sm opacity-0 group-hover:opacity-100 transition-opacity" />
                      <div className="relative bg-gradient-to-br from-background to-muted/30 p-4 sm:p-6 rounded-xl border-2 border-border group-hover:border-primary/50 transition-all">
                        <Input
                          type="number"
                          step="0.01"
                          min="0.00001"
                          max="1000"
                          placeholder="Any amount"
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          className="bg-transparent border-0 h-12 sm:h-16 text-3xl sm:text-5xl font-black text-center text-foreground placeholder:text-muted-foreground/40 focus-visible:ring-0 focus-visible:ring-offset-0 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                        />
                        <div className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 px-2 py-1 sm:px-3 sm:py-1.5 bg-primary/10 rounded-lg border border-primary/20">
                          <span className="text-primary font-black text-base sm:text-xl">SOL</span>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 sm:p-4 bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl border-2 border-primary/20">
                      <div className="flex items-center justify-between">
                        <span className="text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide">
                          Winner Takes:
                        </span>
                        <span className="text-accent font-black text-lg sm:text-2xl">
                          {amount ? (parseFloat(amount) * 2 * 0.9625).toFixed(4) : "0.0000"} SOL
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2 text-right">
                        96.25% payout • 3.75% platform fee
                      </p>
                    </div>
                  </div>


                  {/* Create Button */}
                  <Button
                    onClick={createChallenge}
                    disabled={isDepositing || isProcessing || !publicKey || !user || !amount}
                    className="w-full bg-gradient-to-r from-primary via-accent to-secondary hover:opacity-90 text-primary-foreground font-black h-12 sm:h-16 text-base sm:text-xl uppercase tracking-wider shadow-2xl shadow-primary/40 transition-all hover:scale-105"
                    size="lg"
                  >
                    {isDepositing || isProcessing ? (
                      <>
                        <Loader2 className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3 animate-spin" />
                        DEPOSITING...
                      </>
                    ) : (
                      <>DEPOSIT {amount || "0"} SOL & CREATE</>
                    )}
                  </Button>

                  {amount && (
                    <p className="text-xs text-center text-muted-foreground">
                      You will be prompted to approve the transaction in your wallet
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 3: Waiting for Opponent */}
          {step === "waiting" && roomCreated && (
            <div className="max-w-xl mx-auto">
              <Card className="border-2 border-border bg-gradient-to-b from-card to-card/50 shadow-2xl relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 pointer-events-none animate-pulse" />

                <CardContent className="space-y-6 pt-12 pb-12 text-center relative z-10">
                  <div className="w-20 h-20 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <Loader2 className="w-10 h-10 animate-spin text-primary" />
                  </div>

                  <div>
                    <h2 className="font-black text-3xl uppercase tracking-wide mb-2">WAITING FOR PLAYER</h2>
                    <p className="text-muted-foreground">Room is live • Game starts when someone joins</p>
                  </div>

                  <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span className="font-medium">Expires in 5 minutes</span>
                  </div>

                  <div className="pt-4 space-y-3">
                    <Button
                      onClick={() => navigate("/matchmaking")}
                      className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 h-12 font-bold uppercase tracking-wide"
                    >
                      View in Rooms
                    </Button>
                    <Button
                      onClick={() => {
                        setStep("select-game");
                        setRoomCreated(false);
                        setChallengeId("");
                        setSelectedGame(null);
                      }}
                      variant="outline"
                      className="w-full border-2 hover:bg-muted/50 font-semibold"
                    >
                      Create Another
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreateChallenge;
