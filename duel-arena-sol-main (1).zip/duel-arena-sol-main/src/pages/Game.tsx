import { useState, useEffect } from "react";
import { useSearchParams, useNavigate, useParams } from "react-router-dom";
import { useWallet } from "@solana/wallet-adapter-react";
import { RockPaperScissors } from "@/components/games/RockPaperScissors";
import { CoinFlip } from "@/components/games/CoinFlip";
import { DiceRoll } from "@/components/games/DiceRoll";
import { ChessGame } from "@/components/games/Chess";
import { UnoGame } from "@/components/games/Uno";
import { TicTacToe } from "@/components/games/TicTacToe";
import { ConnectFour } from "@/components/games/ConnectFour";
import { HigherLower } from "@/components/games/HigherLower";
import { NumberDuel } from "@/components/games/NumberDuel";
import { MultiRoundGame } from "@/components/MultiRoundGame";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Trophy, X, Repeat } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSolanaTransactions } from "@/hooks/useSolanaTransactions";

const Game = () => {
  const [searchParams] = useSearchParams();
  const { challengeId } = useParams();
  const navigate = useNavigate();
  const [gameEnded, setGameEnded] = useState(false);
  const [won, setWon] = useState(false);
  const { publicKey } = useWallet();
  const { payout, isProcessing } = useSolanaTransactions();

  const gameType = searchParams.get("game");
  const amount = searchParams.get("amount");
  const creator = searchParams.get("creator");
  const opponent = searchParams.get("opponent");
  const roundsParam = searchParams.get("rounds");
  const rounds = roundsParam ? parseInt(roundsParam) : 2;

  const formatWallet = (wallet: string) => {
    if (!wallet) return "????";
    return "..." + wallet.slice(-4);
  };

  const handleMatchEnd = async (playerWon: boolean) => {
    setWon(playerWon);
    setGameEnded(true);

    if (playerWon && publicKey && challengeId) {
      try {
        const betAmount = parseFloat(amount || "0");
        const totalPot = betAmount * 2;
        const winnerAddress = publicKey.toString();

        // Always distribute funds - no demo mode
        toast.info("Processing payout...", { duration: 2000 });

        const payoutSignature = await payout(challengeId, winnerAddress, totalPot);

        if (!payoutSignature) {
          console.warn("Payout failed but continuing to record winner");
        }

        // Record winner using edge function
        const { error } = await supabase.functions.invoke("record-winner", {
          body: {
            challengeId,
            winnerWallet: winnerAddress,
            gameState: {
              gameType,
              amount: betAmount,
              rounds,
              completedAt: new Date().toISOString(),
              payout_tx: "completed",
            },
          },
        });

        if (error) {
          console.error("Failed to record winner:", error);
          toast.error("Game completed but failed to record result");
        } else {
          const winnings = (betAmount * 2 * 0.9625).toFixed(4);
          toast.success(`Congratulations! You won ${winnings} SOL!`);
        }
      } catch (error) {
        console.error("Error in game completion:", error);
        toast.error("Game completed but there was an issue with the payout");
      }
    } else if (!playerWon) {
      toast.error("Better luck next time!");
    }
  };

  const handleRematch = () => {
    navigate(`/create?game=${gameType}`);
  };

  const renderGame = () => {
    // FIX: Compare lowercase versions to match database storage
    const isCreator = publicKey?.toString().toLowerCase() === creator?.toLowerCase();

    // For single-round games or games that handle their own rounds (like chess/uno)
    if (rounds === 1 || gameType === "chess" || gameType === "uno") {
      switch (gameType) {
        case "chess":
          return <ChessGame onGameEnd={handleMatchEnd} isCreator={isCreator} challengeId={challengeId!} />;
        case "uno":
          return <UnoGame onGameEnd={handleMatchEnd} challengeId={challengeId!} isCreator={isCreator} />;
        case "rock-paper-scissors":
          return <RockPaperScissors onGameEnd={handleMatchEnd} challengeId={challengeId!} isCreator={isCreator} />;
        case "coin-flip":
          return <CoinFlip onGameEnd={handleMatchEnd} challengeId={challengeId!} isCreator={isCreator} />;
        case "dice-roll":
          return <DiceRoll onGameEnd={handleMatchEnd} challengeId={challengeId!} isCreator={isCreator} />;
        case "tic-tac-toe":
          return <TicTacToe onGameEnd={handleMatchEnd} challengeId={challengeId!} isCreator={isCreator} />;
        case "connect-four":
          return <ConnectFour onGameEnd={handleMatchEnd} challengeId={challengeId!} isCreator={isCreator} />;
        case "higher-lower":
          return <HigherLower onGameEnd={handleMatchEnd} challengeId={challengeId!} isCreator={isCreator} />;
        case "number-duel":
          return <NumberDuel onGameEnd={handleMatchEnd} challengeId={challengeId!} isCreator={isCreator} />;
        default:
          return <div>Invalid game type</div>;
      }
    }

    // For multi-round games
    return (
      <MultiRoundGame totalRounds={rounds} onMatchEnd={handleMatchEnd} gameName={gameType || "game"}>
        {({ onRoundEnd, currentRound }) => {
          switch (gameType) {
            case "rock-paper-scissors":
              return (
                <RockPaperScissors
                  onGameEnd={onRoundEnd}
                  challengeId={challengeId!}
                  isCreator={isCreator}
                  key={currentRound}
                />
              );
            case "coin-flip":
              return (
                <CoinFlip onGameEnd={onRoundEnd} challengeId={challengeId!} isCreator={isCreator} key={currentRound} />
              );
            case "dice-roll":
              return (
                <DiceRoll onGameEnd={onRoundEnd} challengeId={challengeId!} isCreator={isCreator} key={currentRound} />
              );
            case "tic-tac-toe":
              return (
                <TicTacToe onGameEnd={onRoundEnd} challengeId={challengeId!} isCreator={isCreator} key={currentRound} />
              );
            case "connect-four":
              return (
                <ConnectFour
                  onGameEnd={onRoundEnd}
                  challengeId={challengeId!}
                  isCreator={isCreator}
                  key={currentRound}
                />
              );
            case "higher-lower":
              return (
                <HigherLower
                  onGameEnd={onRoundEnd}
                  challengeId={challengeId!}
                  isCreator={isCreator}
                  key={currentRound}
                />
              );
            case "number-duel":
              return (
                <NumberDuel
                  onGameEnd={onRoundEnd}
                  challengeId={challengeId!}
                  isCreator={isCreator}
                  key={currentRound}
                />
              );
            default:
              return <div>Invalid game type</div>;
          }
        }}
      </MultiRoundGame>
    );
  };

  if (gameEnded) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-primary/5">
        <div className="container mx-auto px-4 pt-24 pb-12">
          <div className="max-w-md mx-auto">
            <Card className="border-2 border-primary/30 bg-gradient-to-br from-card to-primary/5 text-center shadow-2xl">
              <CardHeader>
                <div className="flex justify-center mb-6">
                  {won ? (
                    <div className="p-6 rounded-full bg-accent/20 border-4 border-accent animate-bounce">
                      <Trophy className="w-20 h-20 text-accent" />
                    </div>
                  ) : (
                    <div className="p-6 rounded-full bg-destructive/20 border-4 border-destructive">
                      <X className="w-20 h-20 text-destructive" />
                    </div>
                  )}
                </div>
                <CardTitle className={`text-4xl font-bold mb-2 ${won ? "text-accent" : "text-destructive"}`}>
                  {won ? "Victory!" : "Defeat"}
                </CardTitle>
                <CardDescription className="text-xl">
                  {won
                    ? `You won ${amount ? (parseFloat(amount) * 2 * 0.9625).toFixed(4) : "0.00"} SOL!`
                    : "Better luck next time!"}
                </CardDescription>
                {rounds > 1 && <p className="text-sm text-muted-foreground mt-2">Best of {rounds} rounds completed</p>}
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={handleRematch}
                  className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground font-semibold py-6 text-lg"
                  size="lg"
                >
                  <Repeat className="w-5 h-5 mr-2" />
                  Create Rematch
                </Button>
                <Button onClick={() => navigate("/")} variant="outline" className="w-full" size="lg">
                  Back to Games
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // FIX: Compare lowercase versions to match database storage
  const isCreator = publicKey?.toString().toLowerCase() === creator?.toLowerCase();
  const myWallet = publicKey?.toString() || "";
  const opponentWallet = isCreator ? opponent : creator;

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-primary/5">
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="max-w-2xl mx-auto space-y-4">
          {/* Player Info Bar */}
          <div className="flex justify-between items-center p-3 bg-card border border-border rounded-lg">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-primary"></div>
              <span className="text-sm">You: {formatWallet(myWallet)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm">Opponent: {formatWallet(opponentWallet || "")}</span>
              <div className="w-2 h-2 rounded-full bg-accent"></div>
            </div>
          </div>

          {renderGame()}
        </div>
      </div>
    </div>
  );
};

export default Game;
