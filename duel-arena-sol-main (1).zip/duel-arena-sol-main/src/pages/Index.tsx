import { useNavigate } from "react-router-dom";
import { useWallet } from "@solana/wallet-adapter-react";
import { GameCard } from "@/components/GameCard";
import {
  Hand,
  Coins,
  Dices,
  Crown,
  Users,
  Shield,
  Zap,
  TrendingUp,
  Grid3x3,
  CircleDot,
  TrendingUp as CardIcon,
  Hash,
  Copy,
  Sparkles,
  Lock,
  CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import solanaLogo from "@/assets/solana-logo.png";

const Index = () => {
  const navigate = useNavigate();
  const { publicKey } = useWallet();
  const { user } = useAuth();

  const handleGameSelect = (gameType: string) => {
    if (!publicKey || !user) {
      toast.error("Please connect your wallet first", {
        description: 'Click "Select Wallet" to get started',
      });
      navigate("/auth", { state: { from: `/create?game=${gameType}` } });
      return;
    }
    navigate(`/create?game=${gameType}`);
  };

  const handleMatchmaking = () => {
    if (!publicKey || !user) {
      toast.error("Please connect your wallet first");
      navigate("/auth", { state: { from: "/matchmaking" } });
      return;
    }
    navigate("/matchmaking");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="container mx-auto px-4 pt-16 sm:pt-20 pb-12 sm:pb-16">
        <div className="text-center max-w-5xl mx-auto space-y-6 sm:space-y-8">
          {/* Powered by Solana Badge */}
          <div className="flex justify-center mb-4 sm:mb-6">
            <div className="inline-flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-3 rounded-full bg-gradient-to-r from-primary/20 via-secondary/20 to-accent/20 border border-primary/30 glow-subtle backdrop-blur-sm">
              <img src={solanaLogo} alt="Solana" className="w-5 h-5 sm:w-6 sm:h-6" />
              <span className="text-xs sm:text-sm font-bold text-foreground uppercase tracking-wider">
                Powered by Solana
              </span>
              <Sparkles className="w-4 h-4 text-primary" />
            </div>
          </div>

          <div className="space-y-4 sm:space-y-6">
            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black leading-none tracking-tighter">
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                DUEL FOR SOL
              </span>
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-bold px-4">
              <span className="text-foreground">Bet. Play. Win.</span>
            </p>
            <div className="inline-flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 rounded-full bg-card/80 backdrop-blur-sm border-2 border-success/40 shadow-lg shadow-success/20">
              <Lock className="w-4 h-4 sm:w-5 sm:h-5 text-success" />
              <span className="text-sm sm:text-base font-bold text-foreground">Smart Contract Escrow</span>
              <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 text-success" />
            </div>
            <p className="text-sm sm:text-base text-muted-foreground max-w-2xl mx-auto px-4">
              On-chain 1v1 games. Escrow holds funds. Winner takes 96.25%.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 sm:gap-4 max-w-4xl mx-auto px-4">
            <div className="px-4 sm:px-5 py-3 sm:py-4 rounded-xl bg-card/50 border border-success/30 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-1">
                <Lock className="w-4 h-4 text-success" />
              </div>
              <div className="text-xs sm:text-sm font-bold text-center text-foreground">Escrow Protected</div>
            </div>
            <div className="px-4 sm:px-5 py-3 sm:py-4 rounded-xl bg-card/50 border border-border/50 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-1">
                <Zap className="w-4 h-4 text-primary" />
              </div>
              <div className="text-xs sm:text-sm font-bold text-center text-foreground">Instant Payouts</div>
            </div>
            <div className="px-4 sm:px-5 py-3 sm:py-4 rounded-xl bg-card/50 border border-border/50 backdrop-blur-sm">
              <div className="text-xl sm:text-2xl font-black text-primary text-center mb-1">3.75%</div>
              <div className="text-xs sm:text-sm font-bold text-center text-foreground">Platform Fee</div>
              <div className="text-[10px] text-muted-foreground text-center mt-1">90% buyback & burn</div>
            </div>
            <div className="px-4 sm:px-5 py-3 sm:py-4 rounded-xl bg-card/50 border border-border/50 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-1">
                <CheckCircle2 className="w-4 h-4 text-primary" />
              </div>
              <div className="text-xs sm:text-sm font-bold text-center text-foreground">On-Chain Proof</div>
            </div>
          </div>

          {/* CA - Prominent Display */}
          <div className="max-w-3xl mx-auto pt-6 sm:pt-10 px-4">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-primary via-secondary to-accent opacity-20 blur-xl group-hover:opacity-30 transition-opacity rounded-2xl"></div>
              <div className="relative bg-card/80 backdrop-blur-sm rounded-2xl border-2 border-primary/40 p-5 sm:p-8">
                <div className="text-center space-y-3 sm:space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/20 border border-primary/30">
                    <Coins className="w-4 h-4 text-primary" />
                    <span className="text-xs font-bold text-primary uppercase tracking-wider">$DUEL Token</span>
                  </div>
                  <div className="flex items-center justify-center gap-2 sm:gap-3 p-3 sm:p-4 bg-background/90 rounded-xl border border-border/50">
                    <code className="text-xs sm:text-sm md:text-base font-mono text-foreground font-bold truncate flex-1">
                      CA_ADDRESS_HERE
                    </code>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText("CA_ADDRESS_HERE");
                        toast.success("Contract address copied!");
                      }}
                      className="p-2.5 hover:bg-primary/20 rounded-lg transition-all hover:scale-105 flex-shrink-0 group"
                      aria-label="Copy contract address"
                    >
                      <Copy className="w-4 h-4 text-primary group-hover:text-secondary transition-colors" />
                    </button>
                  </div>
                  <p className="text-xs text-muted-foreground">90% fees → buyback & burn | Deflationary tokenomics</p>
                </div>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 sm:gap-6 max-w-2xl mx-auto pt-6 sm:pt-8 px-4">
            <div className="text-center p-4 rounded-xl bg-card/30 border border-border/50 backdrop-blur-sm">
              <div className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                0.003 SOL
              </div>
              <div className="text-xs sm:text-sm text-muted-foreground font-bold mt-2 uppercase">Minimum Bet</div>
            </div>
            <div className="text-center p-4 rounded-xl bg-card/30 border border-border/50 backdrop-blur-sm">
              <div className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                96.25%
              </div>
              <div className="text-xs sm:text-sm text-muted-foreground font-bold mt-2 uppercase">Winner Takes</div>
            </div>
          </div>

          {/* CTA */}
          <div className="pt-4 sm:pt-8 px-4">
            <button
              onClick={handleMatchmaking}
              className="relative group px-10 sm:px-16 py-4 sm:py-6 bg-gradient-to-r from-primary via-secondary to-accent text-primary-foreground rounded-xl font-black text-lg sm:text-xl transition-all hover:scale-105 shadow-lg shadow-primary/30 hover:shadow-primary/50 overflow-hidden"
            >
              <span className="relative z-10">BROWSE ROOMS →</span>
              <div className="absolute inset-0 bg-gradient-to-r from-accent via-secondary to-primary opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </button>
            <p className="text-xs sm:text-sm text-muted-foreground mt-4">
              Connect wallet → Pick game → Duel → Get paid instantly
            </p>
          </div>
        </div>
      </section>

      {/* Games Section */}
      <section className="container mx-auto px-4 pb-16 sm:pb-20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-10 sm:mb-16 space-y-4 sm:space-y-6">
            <h2 className="text-4xl sm:text-5xl md:text-6xl font-black">
              <span className="bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
                Pick Your Game
              </span>
            </h2>
            <p className="text-base sm:text-lg text-muted-foreground font-medium max-w-2xl mx-auto px-4">
              Strategy or luck. You choose.
            </p>
          </div>

          {/* Game Categories */}
          <div className="space-y-8 sm:space-y-12">
            {/* Strategy Games */}
            <div className="space-y-4 sm:space-y-6">
              <div className="flex items-center gap-3 px-4">
                <Shield className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-foreground">Strategy Games</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
                <GameCard
                  title="Chess"
                  description="Classic strategy - Checkmate to win"
                  icon={Crown}
                  onClick={() => handleGameSelect("chess")}
                />
                <GameCard
                  title="UNO"
                  description="Card strategy - First to empty hand"
                  icon={Users}
                  onClick={() => handleGameSelect("uno")}
                />
                <GameCard
                  title="Connect Four"
                  description="Strategic drops - 4 in a row wins"
                  icon={CircleDot}
                  onClick={() => handleGameSelect("connect-four")}
                />
                <GameCard
                  title="Tic Tac Toe"
                  description="Quick thinking - 3 in a row wins"
                  icon={Grid3x3}
                  onClick={() => handleGameSelect("tic-tac-toe")}
                />
              </div>
            </div>

            {/* Instant Games */}
            <div className="space-y-4 sm:space-y-6">
              <div className="flex items-center gap-3 px-4">
                <Zap className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-foreground">Instant Games</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
                <GameCard
                  title="Rock Paper Scissors"
                  description="Classic duel - Best of series"
                  icon={Hand}
                  onClick={() => handleGameSelect("rock-paper-scissors")}
                />
                <GameCard
                  title="Coin Flip"
                  description="50/50 chance - Call heads or tails"
                  icon={Coins}
                  onClick={() => handleGameSelect("coin-flip")}
                />
                <GameCard
                  title="Dice Roll"
                  description="Roll the dice - Highest wins"
                  icon={Dices}
                  onClick={() => handleGameSelect("dice-roll")}
                />
                <GameCard
                  title="Higher Lower"
                  description="Predict the next card"
                  icon={CardIcon}
                  onClick={() => handleGameSelect("higher-lower")}
                />
                <GameCard
                  title="Number Duel"
                  description="Pick a number - Closest wins"
                  icon={Hash}
                  onClick={() => handleGameSelect("number-duel")}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="container mx-auto px-4 pb-16 sm:pb-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-black text-center mb-12 sm:mb-16 text-foreground">HOW IT WORKS</h2>

          {/* Escrow Explanation */}
          <div className="mb-12 sm:mb-16 max-w-3xl mx-auto">
            <div className="bg-card/60 backdrop-blur-sm rounded-2xl border border-success/40 p-6 sm:p-8">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Shield className="w-6 h-6 text-success" />
                <h3 className="text-xl sm:text-2xl font-black text-foreground">SMART CONTRACT ESCROW</h3>
              </div>
              <p className="text-center text-sm sm:text-base text-muted-foreground mb-6">
                Bets locked on-chain. Smart contract holds funds. Winner gets paid automatically. It's that simple.
              </p>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="p-3 rounded-lg bg-background/50 border border-success/20">
                  <div className="text-xs sm:text-sm font-bold text-foreground">Trustless</div>
                </div>
                <div className="p-3 rounded-lg bg-background/50 border border-success/20">
                  <div className="text-xs sm:text-sm font-bold text-foreground">Automated</div>
                </div>
                <div className="p-3 rounded-lg bg-background/50 border border-success/20">
                  <div className="text-xs sm:text-sm font-bold text-foreground">Verifiable</div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {[
              {
                step: "1",
                title: "Connect Wallet",
              },
              {
                step: "2",
                title: "Create or Join Room",
              },
              {
                step: "3",
                title: "Play Game",
              },
              {
                step: "4",
                title: "Get Paid",
              },
            ].map((item) => (
              <div key={item.step} className="text-center space-y-3">
                <div className="w-16 h-16 sm:w-18 sm:h-18 mx-auto rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                  <span className="text-2xl sm:text-3xl font-black text-primary">{item.step}</span>
                </div>
                <h3 className="font-bold text-sm sm:text-base">{item.title}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tokenomics */}
      <section className="container mx-auto px-4 pb-16 sm:pb-20">
        <div className="max-w-4xl mx-auto">
          <div className="bg-card/50 backdrop-blur-sm rounded-2xl border border-primary/30 p-6 sm:p-10">
            <div className="text-center space-y-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/30">
                <Coins className="w-5 h-5 text-primary" />
                <span className="text-sm font-bold text-primary uppercase">$DUEL Token</span>
              </div>
              <h3 className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                DEFLATIONARY TOKENOMICS
              </h3>
              <p className="text-muted-foreground max-w-2xl mx-auto font-medium text-sm sm:text-base px-4">
                90% of fees buy back and burn $DUEL. More volume = more burns = supply decrease.
              </p>
              <div className="grid grid-cols-2 gap-4 sm:gap-6 max-w-xl mx-auto pt-4">
                <div className="p-5 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20">
                  <div className="text-4xl sm:text-5xl font-black text-primary mb-2">90%</div>
                  <div className="text-sm font-bold text-foreground">Buyback & Burn</div>
                </div>
                <div className="p-5 rounded-xl bg-gradient-to-br from-secondary/10 to-secondary/5 border border-secondary/20">
                  <div className="text-4xl sm:text-5xl font-black text-secondary mb-2">10%</div>
                  <div className="text-sm font-bold text-foreground">Dev & Ops</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
