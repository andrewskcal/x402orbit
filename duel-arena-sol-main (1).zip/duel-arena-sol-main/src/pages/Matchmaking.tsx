import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useWallet } from "@solana/wallet-adapter-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Crown,
  Users,
  Hand,
  Coins,
  Dices,
  Clock,
  User,
  Grid3x3,
  CircleDot,
  TrendingUp as CardIcon,
  Hash,
} from "lucide-react";
import { GameType } from "@/types/game";
import { supabase } from "@/integrations/supabase/client";

interface OpenChallenge {
  id: string;
  game_type: GameType;
  creator_wallet: string;
  bet_amount: number;
  created_at: string;
  expires_at: string | null;
  is_demo?: boolean;
  rounds?: number;
}

const Matchmaking = () => {
  const navigate = useNavigate();
  const { publicKey } = useWallet();
  const [openChallenges, setOpenChallenges] = useState<OpenChallenge[]>([]);
  const [selectedGame, setSelectedGame] = useState<GameType | "all">("all");

  useEffect(() => {
    loadChallenges();

    // Realtime subscription for new challenges
    const channel = supabase
      .channel("matchmaking-challenges")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "challenges",
        },
        (payload) => {
          console.log("Challenge update:", payload);
          loadChallenges();
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const loadChallenges = async () => {
    const { data, error } = await supabase
      .from("challenges")
      .select("*")
      .eq("status", "open")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error loading challenges:", error);
      return;
    }

    setOpenChallenges(
      (data || []).map((d) => ({
        ...d,
        game_type: d.game_type as GameType,
      })),
    );
  };

  const getGameIcon = (gameType: GameType) => {
    switch (gameType) {
      case "chess":
        return Crown;
      case "uno":
        return Users;
      case "rock-paper-scissors":
        return Hand;
      case "coin-flip":
        return Coins;
      case "dice-roll":
        return Dices;
      case "tic-tac-toe":
        return Grid3x3;
      case "connect-four":
        return CircleDot;
      case "higher-lower":
        return CardIcon;
      case "number-duel":
        return Hash;
    }
  };

  const getGameName = (gameType: GameType) => {
    switch (gameType) {
      case "chess":
        return "Chess";
      case "uno":
        return "UNO";
      case "rock-paper-scissors":
        return "Rock Paper Scissors";
      case "coin-flip":
        return "Coin Flip";
      case "dice-roll":
        return "Dice Roll";
      case "tic-tac-toe":
        return "Tic Tac Toe";
      case "connect-four":
        return "Connect Four";
      case "higher-lower":
        return "Higher or Lower";
      case "number-duel":
        return "Number Duel";
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const seconds = Math.floor((Date.now() - new Date(timestamp).getTime()) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h ago`;
  };

  const isExpired = (expiresAt: string | null) => {
    if (!expiresAt) return false;
    return new Date(expiresAt) < new Date();
  };

  const handleJoinRoom = async (challenge: OpenChallenge) => {
    if (!publicKey) {
      toast.error("Connect wallet first");
      return;
    }

    // Check if room expired
    if (isExpired(challenge.expires_at)) {
      toast.error("This room has expired");
      return;
    }

    // Prevent joining your own room
    if (challenge.creator_wallet === publicKey.toString()) {
      toast.error("Cannot join your own room");
      return;
    }

    const rounds = challenge.rounds || 2;
    navigate(
      `/challenge/${challenge.id}?game=${challenge.game_type}&amount=${challenge.bet_amount}&creator=${challenge.creator_wallet}&rounds=${rounds}`,
    );
  };

  const handleCreateRoom = (gameType: GameType) => {
    if (!publicKey) {
      toast.error("Connect wallet first");
      return;
    }
    navigate(`/create?game=${gameType}`);
  };

  const filteredChallenges =
    selectedGame === "all" ? openChallenges : openChallenges.filter((c) => c.game_type === selectedGame);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 pt-20 sm:pt-24 pb-12">
        <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8">
          {/* Header */}
          <div className="text-center">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black tracking-tight mb-2 sm:mb-3 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
              GAME ROOMS
            </h1>
            <p className="text-muted-foreground text-base sm:text-lg font-medium px-4">Jump in or create your own</p>
          </div>

          {/* Game Filter */}
          <div className="bg-card/50 border-2 border-border rounded-xl p-3 sm:p-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 sm:gap-3">
              <button
                onClick={() => setSelectedGame("all")}
                className={`px-3 sm:px-4 py-2 sm:py-3 rounded-lg font-bold text-xs sm:text-sm uppercase tracking-wide transition-all flex items-center justify-center gap-1.5 sm:gap-2 ${
                  selectedGame === "all"
                    ? "bg-primary text-primary-foreground shadow-lg scale-105"
                    : "bg-muted/30 text-muted-foreground hover:text-foreground hover:bg-muted/60"
                }`}
              >
                ALL
              </button>
              {(
                [
                  "rock-paper-scissors",
                  "coin-flip",
                  "dice-roll",
                  "chess",
                  "uno",
                  "tic-tac-toe",
                  "connect-four",
                  "higher-lower",
                  "number-duel",
                ] as GameType[]
              ).map((game) => {
                const Icon = getGameIcon(game);
                return (
                  <button
                    key={game}
                    onClick={() => setSelectedGame(game)}
                    className={`px-2 sm:px-3 py-2 sm:py-3 rounded-lg font-bold text-xs uppercase tracking-wide transition-all flex items-center justify-center gap-1.5 sm:gap-2 ${
                      selectedGame === game
                        ? "bg-primary text-primary-foreground shadow-lg scale-105"
                        : "bg-muted/30 text-muted-foreground hover:text-foreground hover:bg-muted/60"
                    }`}
                  >
                    {Icon && <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
                    <span className="hidden sm:inline truncate">{getGameName(game)}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Rooms Grid */}
          <div className="grid gap-3">
            {filteredChallenges.length === 0 ? (
              <Card className="border-2 border-border bg-gradient-to-br from-card to-card/50">
                <CardContent className="py-16 text-center space-y-4">
                  <div className="w-20 h-20 mx-auto rounded-full bg-muted/50 flex items-center justify-center mb-4">
                    <Users className="w-10 h-10 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-xl font-bold text-foreground mb-2">No rooms available</p>
                    <p className="text-muted-foreground text-sm">Be the first to create one</p>
                  </div>
                  <Button
                    onClick={() => navigate("/create")}
                    className="bg-gradient-to-r from-primary to-accent hover:opacity-90 font-bold uppercase tracking-wide"
                    size="lg"
                  >
                    Create Room
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredChallenges.map((challenge) => {
                const Icon = getGameIcon(challenge.game_type);
                const isOwnRoom = challenge.creator_wallet === publicKey?.toString();
                const expired = isExpired(challenge.expires_at);
                return (
                  <Card
                    key={challenge.id}
                    className={`border-2 border-border bg-gradient-to-br from-card to-card/50 transition-all ${
                      expired
                        ? "opacity-50 border-destructive/30"
                        : isOwnRoom
                          ? "opacity-60"
                          : "hover:border-primary/50 hover:scale-[1.01]"
                    }`}
                  >
                    <CardContent className="p-3 sm:p-4">
                      {/* Mobile Layout */}
                      <div className="sm:hidden space-y-3">
                        {/* Top Row: Game Icon + Name */}
                        <div className="flex items-center gap-2">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <Icon className="w-5 h-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-black text-sm text-foreground uppercase tracking-wide truncate">
                              {getGameName(challenge.game_type)}
                            </h3>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <User className="w-3 h-3" />
                                {challenge.creator_wallet.slice(-4)}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {formatTimeAgo(challenge.created_at)}
                              </span>
                            </div>
                          </div>
                          {challenge.rounds && challenge.rounds > 1 && (
                            <Badge variant="secondary" className="text-xs font-bold px-1.5 py-0.5 flex-shrink-0">
                              BO{challenge.rounds}
                            </Badge>
                          )}
                        </div>

                        {/* Bottom Row: Bet + Action */}
                        <div className="flex items-center justify-between gap-2">
                          <div>
                            <div className="text-lg font-black text-foreground">{challenge.bet_amount} SOL</div>
                            <p className="text-xs text-accent font-bold">
                              Win {(challenge.bet_amount * 2 * 0.9625).toFixed(2)}
                            </p>
                          </div>
                          <Button
                            onClick={() => handleJoinRoom(challenge)}
                            disabled={isOwnRoom || expired}
                            size="sm"
                            className={`h-9 px-4 font-bold text-xs uppercase tracking-wide flex-shrink-0 ${
                              expired || isOwnRoom
                                ? "bg-muted text-muted-foreground cursor-not-allowed"
                                : "bg-gradient-to-r from-primary to-accent hover:opacity-90"
                            }`}
                          >
                            {expired ? "Expired" : isOwnRoom ? "Yours" : "Join"}
                          </Button>
                        </div>
                      </div>

                      {/* Desktop Layout */}
                      <div className="hidden sm:flex items-center justify-between gap-4 md:gap-6">
                        {/* Left: Game Info */}
                        <div className="flex items-center gap-3 md:gap-4 flex-1">
                          <div className="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <Icon className="w-6 h-6 md:w-7 md:h-7 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-black text-base md:text-lg text-foreground uppercase tracking-wide">
                              {getGameName(challenge.game_type)}
                            </h3>
                            <div className="flex flex-wrap items-center gap-2 md:gap-4 text-xs text-muted-foreground mt-1">
                              <span className="flex items-center gap-1 md:gap-1.5 font-medium">
                                <User className="w-3 h-3 md:w-3.5 md:h-3.5" />
                                {challenge.creator_wallet.slice(0, 4)}...{challenge.creator_wallet.slice(-4)}
                              </span>
                              <span className="flex items-center gap-1 md:gap-1.5 font-medium">
                                <Clock className="w-3 h-3 md:w-3.5 md:h-3.5" />
                                {formatTimeAgo(challenge.created_at)}
                              </span>
                              {challenge.rounds && challenge.rounds > 1 && (
                                <Badge variant="secondary" className="text-xs font-bold px-1.5 py-0.5">
                                  BO{challenge.rounds}
                                </Badge>
                              )}
                              {expired && (
                                <Badge variant="destructive" className="text-xs font-bold px-1.5 py-0.5">
                                  EXPIRED
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Right: Bet & Action */}
                        <div className="flex items-center gap-3 md:gap-4 flex-shrink-0">
                          <div className="text-right">
                            <div className="text-xl md:text-2xl font-black text-foreground">
                              {challenge.bet_amount} SOL
                            </div>
                            <p className="text-xs text-accent font-bold">
                              Win {(challenge.bet_amount * 2 * 0.9625).toFixed(2)} SOL
                            </p>
                          </div>
                          <Button
                            onClick={() => handleJoinRoom(challenge)}
                            disabled={isOwnRoom || expired}
                            className={`h-10 md:h-12 px-4 md:px-6 font-bold text-sm md:text-base uppercase tracking-wide ${
                              expired || isOwnRoom
                                ? "bg-muted text-muted-foreground cursor-not-allowed"
                                : "bg-gradient-to-r from-primary to-accent hover:opacity-90"
                            }`}
                          >
                            {expired ? "Expired" : isOwnRoom ? "Your Room" : "Join"}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>

          {/* Create Room CTA */}
          {filteredChallenges.length > 0 && (
            <div className="text-center pt-6">
              <Button
                onClick={() => navigate("/create")}
                variant="outline"
                className="border-2 border-primary/50 hover:bg-primary/10 font-bold uppercase tracking-wide"
                size="lg"
              >
                + Create New Room
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Matchmaking;
