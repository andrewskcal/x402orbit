import { refundDeposit } from "@/lib/solana";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { ExternalLink, Trophy, Clock, Coins, RefreshCw, PlayCircle, AlertCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

interface Challenge {
  id: string;
  game_type: string;
  bet_amount: number;
  winner_wallet: string | null;
  creator_wallet: string;
  opponent_wallet: string | null;
  status: string;
  completed_at: string | null;
  created_at: string;
  expires_at: string | null;
  rounds: number;
  game_state: any;
}

const MyGames = () => {
  const { user, requireAuth } = useAuth();
  const navigate = useNavigate();
  const [games, setGames] = useState<Challenge[]>([]);
  const [userWallets, setUserWallets] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [refundingChallenges, setRefundingChallenges] = useState<Set<string>>(new Set());

  useEffect(() => {
    requireAuth();
  }, []);

  useEffect(() => {
    if (user) {
      fetchUserGames();
    }
  }, [user]);

  const fetchUserGames = async () => {
    if (!user) return;

    try {
      // Get user's wallets
      const { data: walletData, error: walletError } = await supabase
        .from("user_wallets")
        .select("wallet_address")
        .eq("user_id", user.id);

      if (walletError) throw walletError;

      const wallets = (walletData || []).map((w) => w.wallet_address.toLowerCase());
      setUserWallets(wallets);

      if (wallets.length === 0) {
        setLoading(false);
        return;
      }

      // Fetch all challenges where user is creator or opponent
      const { data, error } = await supabase
        .from("challenges")
        .select("*")
        .or(`creator_wallet.in.(${wallets.join(",")}),opponent_wallet.in.(${wallets.join(",")})`)
        .order("created_at", { ascending: false })
        .limit(100);

      if (error) throw error;
      setGames(data || []);
    } catch (error) {
      console.error("Error fetching user games:", error);
      toast.error("Failed to load your games");
    } finally {
      setLoading(false);
    }
  };

  const determineRefundRecipient = (game: Challenge): { recipient: string; reason: string } | null => {
    const gameState = game.game_state || {};
    const gameType = game.game_type;

    // If no opponent joined at all
    if (!game.opponent_wallet) {
      return {
        recipient: game.creator_wallet,
        reason: "No opponent joined",
      };
    }

    // Check game-specific states
    if (gameType === "rock-paper-scissors") {
      const creatorPlayed = gameState.creator !== null && gameState.creator !== undefined;
      const opponentPlayed = gameState.opponent !== null && gameState.opponent !== undefined;

      if (!creatorPlayed && !opponentPlayed) {
        return {
          recipient: game.creator_wallet,
          reason: "Both players inactive - refund to creator",
        };
      }
      if (!creatorPlayed) {
        return {
          recipient: game.opponent_wallet,
          reason: "Creator abandoned game",
        };
      }
      if (!opponentPlayed) {
        return {
          recipient: game.creator_wallet,
          reason: "Opponent abandoned game",
        };
      }
    }

    if (gameType === "connect-four") {
      const board = gameState.board;
      const hasAnyMoves = board && board.some((row: any[]) => row.some((cell) => cell !== null));

      if (!hasAnyMoves) {
        return {
          recipient: game.creator_wallet,
          reason: "No moves made - refund to creator",
        };
      }
    }

    // For other games, check timestamps
    const createdAt = new Date(game.created_at);
    const now = new Date();
    const minutesElapsed = (now.getTime() - createdAt.getTime()) / 1000 / 60;

    // If game is active but stalled for 5+ minutes
    if (game.status === "active" && minutesElapsed > 5) {
      return {
        recipient: game.creator_wallet,
        reason: "Game stalled - defaulting to creator",
      };
    }

    return null;
  };

  const handleRequestRefund = async (challengeId: string) => {
    if (!user) return;

    const game = games.find((g) => g.id === challengeId);
    if (!game) return;

    const refundInfo = determineRefundRecipient(game);
    if (!refundInfo) {
      toast.error("Cannot determine refund recipient - game may still be active");
      return;
    }

    setRefundingChallenges((prev) => new Set(prev).add(challengeId));

    try {
      // TODO: Call your smart contract refund function here
      // For now, just update the database
      const { error } = await supabase
        .from("challenges")
        .update({
          status: "cancelled",
          winner_wallet: refundInfo.recipient,
          completed_at: new Date().toISOString(),
        })
        .eq("id", challengeId);

      if (error) throw error;

      toast.success(`Refund processed: ${refundInfo.reason}`);
      fetchUserGames();
    } catch (error) {
      console.error("Error requesting refund:", error);
      toast.error("Failed to process refund");
    } finally {
      setRefundingChallenges((prev) => {
        const next = new Set(prev);
        next.delete(challengeId);
        return next;
      });
    }
  };

  const canRequestRefund = (game: Challenge) => {
    // Must be at least 5 minutes old
    const createdAt = new Date(game.created_at);
    const now = new Date();
    const minutesElapsed = (now.getTime() - createdAt.getTime()) / 1000 / 60;

    if (minutesElapsed < 5) return false;

    // Must be in pending or active status
    if (!["pending", "active"].includes(game.status)) return false;

    // Must be either the creator or opponent
    const isParticipant =
      userWallets.includes(game.creator_wallet.toLowerCase()) ||
      (game.opponent_wallet && userWallets.includes(game.opponent_wallet.toLowerCase()));

    return isParticipant;
  };

  const canRejoinGame = (game: Challenge) => {
    const isActive = game.status === "active";
    const notExpired = game.expires_at ? new Date(game.expires_at) > new Date() : true;
    return isActive && notExpired;
  };

  const getGameName = (gameType: string) => {
    const names: Record<string, string> = {
      chess: "Chess",
      uno: "UNO",
      "rock-paper-scissors": "Rock Paper Scissors",
      "coin-flip": "Coin Flip",
      "dice-roll": "Dice Roll",
      "tic-tac-toe": "Tic Tac Toe",
      "connect-four": "Connect Four",
      "higher-lower": "Higher or Lower",
      "number-duel": "Number Duel",
    };
    return names[gameType] || gameType;
  };

  const getSolscanLink = (wallet: string) => {
    return `https://solscan.io/account/${wallet}?cluster=devnet`;
  };

  const shortenAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: any; label: string }> = {
      pending: { variant: "secondary", label: "Pending" },
      active: { variant: "default", label: "Active" },
      completed: { variant: "outline", label: "Completed" },
      cancelled: { variant: "destructive", label: "Cancelled" },
    };
    const config = variants[status] || { variant: "secondary", label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getInactivityWarning = (game: Challenge) => {
    if (!["pending", "active"].includes(game.status)) return null;

    const createdAt = new Date(game.created_at);
    const now = new Date();
    const minutesElapsed = (now.getTime() - createdAt.getTime()) / 1000 / 60;

    if (minutesElapsed >= 5) {
      const refundInfo = determineRefundRecipient(game);
      if (refundInfo) {
        return (
          <div className="mt-2 flex items-start gap-2 text-xs text-amber-500 bg-amber-500/10 p-2 rounded">
            <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>{refundInfo.reason}</span>
          </div>
        );
      }
    }

    return null;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-semibold text-foreground mb-2">My Games</h1>
            <p className="text-muted-foreground mb-3">
              Track your matches, rejoin active games, and request refunds for abandoned games (after 5 minutes)
            </p>
          </div>

          {games.length === 0 ? (
            <Card className="border border-border bg-card">
              <CardContent className="py-12 text-center">
                <Trophy className="w-14 h-14 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground mb-4">No games yet</p>
                <Button asChild>
                  <a href="/matchmaking">Browse Rooms</a>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {games.map((game) => {
                const isWinner = game.winner_wallet && userWallets.includes(game.winner_wallet.toLowerCase());
                const isCreator = userWallets.includes(game.creator_wallet.toLowerCase());

                return (
                  <Card key={game.id} className="border border-border bg-card hover:border-primary/40 transition-all">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg flex items-center gap-2 font-semibold">
                            {isWinner && <Trophy className="w-4 h-4 text-accent" />}
                            {getGameName(game.game_type)}
                            {game.rounds > 1 && (
                              <span className="text-sm font-normal text-muted-foreground">(Best of {game.rounds})</span>
                            )}
                            {getStatusBadge(game.status)}
                          </CardTitle>
                          <CardDescription className="flex items-center gap-1.5 mt-1 text-xs">
                            <Clock className="w-3 h-3" />
                            {formatDistanceToNow(new Date(game.created_at), { addSuffix: true })}
                          </CardDescription>
                          {getInactivityWarning(game)}
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-1.5 text-base font-bold text-accent">
                            <Coins className="w-4 h-4" />
                            {game.bet_amount} SOL
                          </div>
                          {game.status === "completed" && (
                            <div className="text-xs text-muted-foreground">
                              {isWinner ? "Won" : "Lost"}: {isWinner ? (game.bet_amount * 2 * 0.9625).toFixed(3) : "0"}{" "}
                              SOL
                            </div>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <div className="text-xs text-muted-foreground">Creator</div>
                          <div className="flex items-center gap-2">
                            <code className="text-sm bg-muted px-2 py-1 rounded">
                              {shortenAddress(game.creator_wallet)}
                              {isCreator && <span className="text-accent ml-1">(You)</span>}
                            </code>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 w-7 p-0"
                              onClick={() => window.open(getSolscanLink(game.creator_wallet), "_blank")}
                            >
                              <ExternalLink className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="text-xs text-muted-foreground">Opponent</div>
                          {game.opponent_wallet ? (
                            <div className="flex items-center gap-2">
                              <code className="text-sm bg-muted px-2 py-1 rounded">
                                {shortenAddress(game.opponent_wallet)}
                                {!isCreator && <span className="text-accent ml-1">(You)</span>}
                              </code>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-7 w-7 p-0"
                                onClick={() => window.open(getSolscanLink(game.opponent_wallet!), "_blank")}
                              >
                                <ExternalLink className="w-3 h-3" />
                              </Button>
                            </div>
                          ) : (
                            <div className="text-sm text-muted-foreground">Waiting...</div>
                          )}
                        </div>

                        <div className="space-y-2 flex flex-col justify-between">
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Challenge ID</div>
                            <code className="text-xs bg-muted px-2 py-1 rounded block break-all">
                              {game.id.slice(0, 16)}...
                            </code>
                          </div>

                          <div className="flex gap-2">
                            {canRejoinGame(game) && (
                              <Button size="sm" onClick={() => navigate(`/game/${game.id}`)} className="w-full">
                                <PlayCircle className="w-3 h-3 mr-1" />
                                Rejoin Game
                              </Button>
                            )}

                            {canRequestRefund(game) && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleRequestRefund(game.id)}
                                disabled={refundingChallenges.has(game.id)}
                                className="w-full"
                              >
                                {refundingChallenges.has(game.id) ? (
                                  <>
                                    <RefreshCw className="w-3 h-3 mr-1 animate-spin" />
                                    Processing...
                                  </>
                                ) : (
                                  <>
                                    <RefreshCw className="w-3 h-3 mr-1" />
                                    Request Refund
                                  </>
                                )}
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MyGames;
