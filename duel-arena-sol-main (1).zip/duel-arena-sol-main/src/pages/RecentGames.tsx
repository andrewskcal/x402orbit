import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { ExternalLink, Trophy, Clock, Coins } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Challenge {
  id: string;
  game_type: string;
  bet_amount: number;
  winner_wallet: string | null;
  creator_wallet: string;
  opponent_wallet: string | null;
  status: string;
  completed_at: string | null;
  rounds: number;
}

const RecentGames = () => {
  const [games, setGames] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecentGames();
    
    // Real-time subscription for new completed games
    const channel = supabase
      .channel('recent-games')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'challenges',
        },
        (payload) => {
          console.log('Game update:', payload);
          fetchRecentGames();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchRecentGames = async () => {
    try {
      const { data, error } = await supabase
        .from('challenges')
        .select('*')
        .in('status', ['completed', 'active', 'pending'])
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setGames(data || []);
    } catch (error) {
      console.error('Error fetching recent games:', error);
    } finally {
      setLoading(false);
    }
  };

  const getGameName = (gameType: string) => {
    const names: Record<string, string> = {
      'chess': 'Chess',
      'uno': 'UNO',
      'rock-paper-scissors': 'Rock Paper Scissors',
      'coin-flip': 'Coin Flip',
      'dice-roll': 'Dice Roll',
      'tic-tac-toe': 'Tic Tac Toe',
      'connect-four': 'Connect Four',
      'higher-lower': 'Higher or Lower',
      'number-duel': 'Number Duel'
    };
    return names[gameType] || gameType;
  };

  const getSolscanLink = (wallet: string) => {
    return `https://solscan.io/account/${wallet}?cluster=devnet`;
  };

  const shortenAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-semibold text-foreground mb-2">
              Recent Games
            </h1>
            <p className="text-muted-foreground mb-3">
              All recent platform games - view details and verify on Solscan
            </p>
          </div>

          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : games.length === 0 ? (
            <Card className="border border-border bg-card">
              <CardContent className="py-12 text-center">
                <Trophy className="w-14 h-14 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">No games yet</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {games.map((game) => (
                <Card key={game.id} className="border border-border bg-card hover:border-primary/40 transition-all">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg flex items-center gap-2 font-semibold">
                          <Trophy className="w-4 h-4 text-accent" />
                          {getGameName(game.game_type)}
                          {game.rounds > 1 && (
                            <span className="text-sm font-normal text-muted-foreground">
                              (Best of {game.rounds})
                            </span>
                          )}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-1.5 mt-1 text-xs">
                          <Clock className="w-3 h-3" />
                          {game.completed_at ? formatDistanceToNow(new Date(game.completed_at), { addSuffix: true }) : 'Unknown'}
                        </CardDescription>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-1.5 text-base font-bold text-accent">
                          <Coins className="w-4 h-4" />
                          {game.bet_amount} SOL
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Won: {(game.bet_amount * 2 * 0.9625).toFixed(3)}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <div className="text-xs text-muted-foreground">Creator</div>
                        <div className="flex items-center gap-2">
                          <code className="text-sm bg-muted px-2 py-1 rounded">
                            {shortenAddress(game.creator_wallet)}
                          </code>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0"
                            onClick={() => window.open(getSolscanLink(game.creator_wallet), '_blank')}
                          >
                            <ExternalLink className="w-3 h-3" />
                          </Button>
                        </div>
                        {game.winner_wallet === game.creator_wallet && (
                          <div className="text-xs font-semibold text-accent flex items-center gap-1">
                            <Trophy className="w-3 h-3" /> Winner
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <div className="text-xs text-muted-foreground">Opponent</div>
                        {game.opponent_wallet ? (
                          <>
                            <div className="flex items-center gap-2">
                              <code className="text-sm bg-muted px-2 py-1 rounded">
                                {shortenAddress(game.opponent_wallet)}
                              </code>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-7 w-7 p-0"
                                onClick={() => window.open(getSolscanLink(game.opponent_wallet!), '_blank')}
                              >
                                <ExternalLink className="w-3 h-3" />
                              </Button>
                            </div>
                            {game.winner_wallet === game.opponent_wallet && (
                              <div className="text-xs font-semibold text-accent flex items-center gap-1">
                                <Trophy className="w-3 h-3" /> Winner
                              </div>
                            )}
                          </>
                        ) : (
                          <div className="text-sm text-muted-foreground">No opponent</div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <div className="text-xs text-muted-foreground">Challenge ID</div>
                        <code className="text-xs bg-muted px-2 py-1 rounded block break-all">
                          {game.id.slice(0, 16)}...
                        </code>
                        <div className="text-xs text-muted-foreground mb-2">
                          Status: <span className="text-accent font-semibold capitalize">{game.status}</span>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full"
                          onClick={() => window.open(getSolscanLink(game.creator_wallet), '_blank')}
                        >
                          <ExternalLink className="w-3 h-3 mr-1" />
                          View on Solscan
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecentGames;
