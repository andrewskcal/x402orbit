import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, ExternalLink, Flame, TrendingUp, Coins, Users, Twitter } from "lucide-react";
import { toast } from "sonner";
const Token = () => {
  const [copied, setCopied] = useState(false);

  // Replace with your actual contract address
  const contractAddress = "LOADING...";
  const twitterUrl = "https://twitter.com/duelarenaonsol";
  const pumpfunUrl = `https://pump.fun/coin/${contractAddress}`;
  const copyToClipboard = () => {
    navigator.clipboard.writeText(contractAddress);
    setCopied(true);
    toast.success("Contract address copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };
  return <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="max-w-5xl mx-auto space-y-8">
          {/* Twitter Link */}
          <div className="flex justify-center">
            <Button onClick={() => window.open(twitterUrl, "_blank")} className="bg-blue-500 hover:bg-blue-600 text-white font-medium px-6 py-2.5 text-sm" size="lg">
              <Twitter className="w-4 h-4 mr-2" />
              Follow on X
            </Button>
          </div>

          {/* Hero Section */}
          <div className="text-center space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted border border-border text-xs font-medium mb-2">
              <Flame className="w-3.5 h-3.5 text-primary" />
              <span>Deflationary Token</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-foreground">
              $DUEL
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              The official token of Duel Arena - Powering competitive gaming on Solana
            </p>
          </div>

          {/* Contract Address Card */}
          <Card className="border border-border bg-card shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="text-xl flex items-center gap-2 font-semibold">
                <Coins className="w-5 h-5 text-primary" />
                Contract Address
              </CardTitle>
              <CardDescription>Copy and verify on pump.fun</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 p-3 bg-muted rounded-md">
                <code className="flex-1 text-sm break-all font-mono">{contractAddress}</code>
                <Button onClick={copyToClipboard} size="sm" variant="ghost" className="hover:bg-primary/10 flex-shrink-0">
                  {copied ? <span className="text-accent font-medium text-xs">Copied!</span> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              <Button onClick={() => window.open(pumpfunUrl, "_blank")} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium h-10" size="lg">
                <ExternalLink className="w-4 h-4 mr-2" />
                Trade on pump.fun
              </Button>
            </CardContent>
          </Card>

          {/* Tokenomics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Buyback & Burn */}
            <Card className="border border-border bg-card">
              <CardHeader className="pb-3">
                <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center mb-3">
                  <Flame className="w-6 h-6 text-destructive" />
                </div>
                <CardTitle className="text-xl font-semibold">Daily Buyback & Burn</CardTitle>
                <CardDescription>Deflationary mechanism</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-muted rounded-md">
                  <span className="text-sm text-muted-foreground">Allocated to Buyback</span>
                  <span className="text-xl font-bold text-destructive">90%</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  90% of platform fees buy back $DUEL and burn it permanently, reducing supply daily.
                </p>
              </CardContent>
            </Card>

            {/* Development */}
            <Card className="border border-border bg-card">
              <CardHeader className="pb-3">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-xl font-semibold">Development Fund</CardTitle>
                <CardDescription>Platform growth</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-muted rounded-md">
                  <span className="text-sm text-muted-foreground">Development</span>
                  <span className="text-xl font-bold text-primary">10%</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  10% covers development, infrastructure, and platform improvements.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Dev Wallet Allocation */}
          <Card className="border-2 border-accent/30 bg-gradient-to-br from-card to-accent/5 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Coins className="w-6 h-6 text-accent" />
                Dev Wallet Allocation
              </CardTitle>
              <CardDescription>How the development wallet holdings are allocated</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 bg-accent/10 rounded-lg border border-accent/20">
                  <span className="text-sm font-medium">Liquidity (Locked)</span>
                  <span className="text-lg font-bold text-accent">50%</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-primary/10 rounded-lg border border-primary/20">
                  <span className="text-sm font-medium">Community Rewards</span>
                  <span className="text-lg font-bold text-primary">20%</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-secondary/10 rounded-lg border border-secondary/20">
                  
                  <span className="text-lg font-bold text-secondary">15%</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg border border-border">
                  <span className="text-sm font-medium">Team/Dev (Vested)</span>
                  <span className="text-lg font-bold">10%</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg border border-border">
                  <span className="text-sm font-medium">Reserves</span>
                  <span className="text-lg font-bold">5%</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground pt-2">
                The dev wallet's token holdings are allocated according to this distribution, with 50% locked in
                liquidity and team tokens vested.
              </p>
            </CardContent>
          </Card>

          {/* How It Works */}
          <Card className="border-2 border-primary/30 bg-gradient-to-br from-card to-secondary/5">
            <CardHeader>
              <CardTitle className="text-3xl">How The Tokenomics Work</CardTitle>
              <CardDescription className="text-base">Transparent and automated fee distribution</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-3 text-center">
                  <div className="w-16 h-16 mx-auto rounded-full bg-primary/20 flex items-center justify-center border-2 border-primary/30">
                    <Users className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="font-bold text-lg">1. Players Compete</h3>
                  <p className="text-sm text-muted-foreground">
                    Every game generates a 3.75% platform fee from the total pot
                  </p>
                </div>

                <div className="space-y-3 text-center">
                  <div className="w-16 h-16 mx-auto rounded-full bg-destructive/20 flex items-center justify-center border-2 border-destructive/30">
                    <TrendingUp className="w-8 h-8 text-destructive" />
                  </div>
                  <h3 className="font-bold text-lg">2. Daily Buyback</h3>
                  <p className="text-sm text-muted-foreground">
                    90% of fees buy $DUEL tokens from pump.fun automatically
                  </p>
                </div>

                <div className="space-y-3 text-center">
                  <div className="w-16 h-16 mx-auto rounded-full bg-accent/20 flex items-center justify-center border-2 border-accent/30">
                    <Flame className="w-8 h-8 text-accent" />
                  </div>
                  <h3 className="font-bold text-lg">3. Permanent Burn</h3>
                  <p className="text-sm text-muted-foreground">
                    Bought tokens are sent to a burn address, removing them forever
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Why Hold $DUEL */}
          <Card className="border-2 border-accent/30 bg-gradient-to-br from-card to-accent/5">
            <CardHeader>
              <CardTitle className="text-3xl">Why Hold $DUEL?</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start gap-3 p-4 rounded-lg bg-accent/5 border border-accent/20">
                  <Flame className="w-6 h-6 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold mb-1">Deflationary Supply</h4>
                    <p className="text-sm text-muted-foreground">
                      Daily burns permanently reduce supply, increasing scarcity
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <TrendingUp className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold mb-1">Revenue Backed</h4>
                    <p className="text-sm text-muted-foreground">
                      Token value supported by real gaming platform revenue
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-lg bg-secondary/5 border border-secondary/20">
                  <Users className="w-6 h-6 text-secondary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold mb-1">Growing Ecosystem</h4>
                    <p className="text-sm text-muted-foreground">More players = more fees = more buybacks & burns</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-lg bg-accent/5 border border-accent/20">
                  <Coins className="w-6 h-6 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold mb-1">Transparent</h4>
                    <p className="text-sm text-muted-foreground">All burns verifiable on-chain via Solana blockchain</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Disclaimer */}
          <Card className="border border-muted bg-muted/30">
            <CardContent className="py-4">
              <p className="text-xs text-muted-foreground text-center">
                <strong>Disclaimer:</strong> Cryptocurrency investments carry risk. This is not financial advice. Always
                do your own research before investing. The tokenomics are subject to the platform's terms and
                conditions.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>;
};
export default Token;