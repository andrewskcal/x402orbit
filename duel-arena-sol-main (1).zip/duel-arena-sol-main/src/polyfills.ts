// Browser polyfills for Solana web3.js
import { Buffer } from 'buffer';

// Make Buffer globally available
window.Buffer = Buffer;

// Polyfill global if needed
if (typeof global === 'undefined') {
  (window as any).global = window;
}

// Polyfill process.env if needed
if (!window.process) {
  (window as any).process = { env: {} };
}

// FIXED require polyfill for browser with crypto support
(window as any).require = (module: string) => {
  if (module === 'buffer') {
    return { Buffer };
  }
  if (module === 'crypto') {
    // Return proper crypto polyfill that has createHash
    return {
      randomBytes: (size: number) => {
        const array = new Uint8Array(size);
        window.crypto.getRandomValues(array);
        return array;
      },
      createHash: () => {
        // Simple createHash implementation
        return {
          update: (data: string) => {
            return {
              digest: () => {
                // Return a mock hash value
                return 'mock_hash_for_browser';
              }
            };
          }
        };
      }
    };
  }
  throw new Error(`Module ${module} not found`);
};

export {};
