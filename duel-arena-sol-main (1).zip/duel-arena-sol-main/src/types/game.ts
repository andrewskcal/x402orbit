export type GameType = 'chess' | 'uno' | 'rock-paper-scissors' | 'coin-flip' | 'dice-roll' | 'tic-tac-toe' | 'connect-four' | 'higher-lower' | 'number-duel';

export interface Challenge {
  id: string;
  gameType: GameType;
  creator: string;
  amount: number;
  createdAt: number;
  accepted?: boolean;
  opponent?: string;
  creatorDeposited?: boolean;
  opponentDeposited?: boolean;
  winner?: string;
}

export interface GameResult {
  winner: string;
  loser: string;
  amount: number;
  fee: number;
}
