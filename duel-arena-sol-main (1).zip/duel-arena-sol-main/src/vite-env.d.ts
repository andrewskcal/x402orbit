/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL: string
  readonly VITE_SUPABASE_PUBLISHABLE_KEY: string
  readonly VITE_SUPABASE_PROJECT_ID: string
  readonly VITE_SOLANA_RPC_URL: string
  readonly VITE_SOLANA_NETWORK: string
  readonly VITE_DUEL_PROGRAM_ID: string
  readonly VITE_DUEL_TOKEN_MINT: string
  readonly VITE_PLATFORM_FEE_PERCENTAGE: string
  readonly VITE_MIN_BET_AMOUNT: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
