// @ts-nocheck - Deno edge function with Deno-specific types
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.0';
import { PublicKey, Connection } from 'https://esm.sh/@solana/web3.js@1.98.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Rate limiting constants
const MAX_WINNER_ATTEMPTS = 5;
const RATE_LIMIT_WINDOW_MINUTES = 5;

// Solana RPC URL for MAINNET
const SOLANA_RPC_URL = Deno.env.get('SOLANA_RPC_URL') || 'https://api.mainnet-beta.solana.com';

// Input validation helper
function validateWinnerInput(data: any): { isValid: boolean; error?: string } {
  if (!data.challengeId || typeof data.challengeId !== 'string') {
    return { isValid: false, error: 'Invalid challenge ID' };
  }
  
  if (!data.winnerWallet || typeof data.winnerWallet !== 'string') {
    return { isValid: false, error: 'Invalid winner wallet' };
  }
  
  // Validate Solana address format
  try {
    new PublicKey(data.winnerWallet);
  } catch {
    return { isValid: false, error: 'Invalid Solana wallet address format' };
  }
  
  return { isValid: true };
}

/**
 * Verify transaction on Solana mainnet
 */
async function verifyOnChainTransaction(signature: string): Promise<boolean> {
  try {
    const connection = new Connection(SOLANA_RPC_URL, 'confirmed');
    const status = await connection.getSignatureStatus(signature);
    
    return status?.value?.confirmationStatus === 'confirmed' || 
           status?.value?.confirmationStatus === 'finalized';
  } catch (error) {
    console.error('Error verifying transaction:', error);
    return false;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const requestData = await req.json();
    
    // Validate input
    const validation = validateWinnerInput(requestData);
    if (!validation.isValid) {
      console.error('Input validation failed:', validation.error);
      throw new Error(validation.error);
    }

    const { challengeId, winnerWallet, gameState } = requestData;

    console.log('Recording winner request:', { challengeId });

    // Get challenge to verify user is a participant
    const { data: challenge, error: fetchError } = await supabaseClient
      .from('challenges')
      .select('*')
      .eq('id', challengeId)
      .single();

    if (fetchError) {
      throw new Error('Challenge not found');
    }

    // Check if winner already recorded
    if (challenge.winner_wallet) {
      throw new Error('Winner already recorded for this challenge');
    }

    // Rate limiting check for this specific challenge
    const { data: rateLimitData } = await supabaseClient
      .from('deposit_rate_limits')
      .select('*')
      .eq('wallet_address', `${challengeId}_winner`)
      .maybeSingle();

    if (rateLimitData) {
      const timeSinceLastAttempt = (Date.now() - new Date(rateLimitData.last_attempt_at).getTime()) / 1000 / 60;
      
      if (timeSinceLastAttempt < RATE_LIMIT_WINDOW_MINUTES && rateLimitData.attempt_count >= MAX_WINNER_ATTEMPTS) {
        console.warn('Rate limit exceeded for winner recording');
        throw new Error('Too many attempts to record winner. Please try again in a few minutes.');
      }
      
      if (timeSinceLastAttempt < RATE_LIMIT_WINDOW_MINUTES) {
        await supabaseClient
          .from('deposit_rate_limits')
          .update({ 
            attempt_count: rateLimitData.attempt_count + 1,
            last_attempt_at: new Date().toISOString()
          })
          .eq('wallet_address', `${challengeId}_winner`);
      } else {
        await supabaseClient
          .from('deposit_rate_limits')
          .update({ 
            attempt_count: 1,
            last_attempt_at: new Date().toISOString()
          })
          .eq('wallet_address', `${challengeId}_winner`);
      }
    } else {
      await supabaseClient
        .from('deposit_rate_limits')
        .insert({ 
          wallet_address: `${challengeId}_winner`,
          attempt_count: 1 
        });
    }

    // Verify user is a participant
    const { data: userWallet } = await supabaseClient
      .from('user_wallets')
      .select('wallet_address')
      .eq('user_id', user.id)
      .single();

    if (!userWallet) {
      throw new Error('User wallet not found');
    }

    const isParticipant = 
      challenge.creator_wallet === userWallet.wallet_address ||
      challenge.opponent_wallet === userWallet.wallet_address;

    if (!isParticipant) {
      throw new Error('User is not a participant in this challenge');
    }

    // Verify both players deposited
    if (!challenge.creator_deposited || !challenge.opponent_deposited) {
      throw new Error('Both players must deposit before game can be completed');
    }

    // Verify challenge allows winner recording (open or active status)
    if (challenge.status !== 'active' && challenge.status !== 'open') {
      throw new Error(`Challenge is not active (status: ${challenge.status})`);
    }

    // Verify opponent has joined
    if (!challenge.opponent_wallet) {
      throw new Error('Opponent has not joined the challenge yet');
    }

    // Validate winner is one of the participants
    if (winnerWallet !== challenge.creator_wallet && winnerWallet !== challenge.opponent_wallet) {
      throw new Error('Winner must be one of the participants');
    }

    console.log('All validations passed, updating challenge');

    // Update challenge with winner using secure function
    const { data: updatedChallenge, error: updateError } = await supabaseClient.rpc(
      'update_challenge_secure',
      {
        challenge_id: challengeId,
        new_winner_wallet: winnerWallet,
        new_status: 'completed',
        new_game_state: gameState || {}
      }
    );

    if (updateError) {
      console.error('Database update error:', updateError);
      throw updateError;
    }

    console.log('Winner recorded successfully');

    return new Response(
      JSON.stringify({ 
        success: true,
        challenge: updatedChallenge
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Winner recording error:', error instanceof Error ? error.message : 'Unknown error');
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});