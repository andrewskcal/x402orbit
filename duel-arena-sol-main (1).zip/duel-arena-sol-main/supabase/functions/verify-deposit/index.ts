import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.0';
import { Connection, PublicKey } from 'https://esm.sh/@solana/web3.js@1.98.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Rate limiting constants
const MAX_ATTEMPTS = 10;
const RATE_LIMIT_WINDOW_MINUTES = 10;
const MIN_AMOUNT = 0.01;
const MAX_AMOUNT = 1000;

// Input validation helper
function validateInput(data: any): { isValid: boolean; error?: string } {
  if (!data.challengeId || typeof data.challengeId !== 'string') {
    return { isValid: false, error: 'Invalid challenge ID' };
  }
  
  if (!data.signature || typeof data.signature !== 'string' || data.signature.length < 64) {
    return { isValid: false, error: 'Invalid transaction signature' };
  }
  
  if (typeof data.expectedAmount !== 'number' || data.expectedAmount < MIN_AMOUNT || data.expectedAmount > MAX_AMOUNT) {
    return { isValid: false, error: `Amount must be between ${MIN_AMOUNT} and ${MAX_AMOUNT} SOL` };
  }
  
  if (!data.recipientAddress || typeof data.recipientAddress !== 'string') {
    return { isValid: false, error: 'Invalid recipient address' };
  }
  
  if (typeof data.isCreator !== 'boolean') {
    return { isValid: false, error: 'Invalid creator flag' };
  }
  
  if (!data.isCreator && (!data.opponentWallet || typeof data.opponentWallet !== 'string')) {
    return { isValid: false, error: 'Invalid opponent wallet' };
  }
  
  // Validate Solana addresses format
  try {
    new PublicKey(data.recipientAddress);
    if (!data.isCreator) {
      new PublicKey(data.opponentWallet);
    }
  } catch {
    return { isValid: false, error: 'Invalid Solana address format' };
  }
  
  return { isValid: true };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const requestData = await req.json();
    
    // Validate input
    const validation = validateInput(requestData);
    if (!validation.isValid) {
      console.error('Input validation failed:', validation.error);
      throw new Error(validation.error);
    }

    const { challengeId, signature, expectedAmount, recipientAddress, isCreator, opponentWallet } = requestData;
    const walletAddress = isCreator ? user.id : opponentWallet;

    console.log('Verifying deposit request:', { challengeId, isCreator, amount: expectedAmount });

    // Check rate limiting
    const { data: rateLimitData } = await supabaseClient
      .from('deposit_rate_limits')
      .select('*')
      .eq('wallet_address', walletAddress)
      .maybeSingle();

    if (rateLimitData) {
      const timeSinceLastAttempt = (Date.now() - new Date(rateLimitData.last_attempt_at).getTime()) / 1000 / 60;
      
      if (timeSinceLastAttempt < RATE_LIMIT_WINDOW_MINUTES && rateLimitData.attempt_count >= MAX_ATTEMPTS) {
        console.warn('Rate limit exceeded for wallet');
        throw new Error('Too many verification attempts. Please try again in a few minutes.');
      }
      
      // Update rate limit counter
      if (timeSinceLastAttempt < RATE_LIMIT_WINDOW_MINUTES) {
        await supabaseClient
          .from('deposit_rate_limits')
          .update({ 
            attempt_count: rateLimitData.attempt_count + 1,
            last_attempt_at: new Date().toISOString()
          })
          .eq('wallet_address', walletAddress);
      } else {
        // Reset counter if outside window
        await supabaseClient
          .from('deposit_rate_limits')
          .update({ 
            attempt_count: 1,
            last_attempt_at: new Date().toISOString()
          })
          .eq('wallet_address', walletAddress);
      }
    } else {
      // Create new rate limit entry
      await supabaseClient
        .from('deposit_rate_limits')
        .insert({ 
          wallet_address: walletAddress,
          attempt_count: 1 
        });
    }

    // Check for replay attack - signature already used
    const { data: existingSignature } = await supabaseClient
      .from('transaction_signatures')
      .select('*')
      .eq('signature', signature)
      .maybeSingle();

    if (existingSignature) {
      console.error('Replay attack detected - signature already used');
      throw new Error('This transaction has already been verified');
    }

    // Check if challenge already has this deposit recorded
    const { data: existingChallenge } = await supabaseClient
      .from('challenges')
      .select('*')
      .eq('id', challengeId)
      .single();

    if (!existingChallenge) {
      throw new Error('Challenge not found');
    }

    if (isCreator && existingChallenge.creator_deposited) {
      throw new Error('Creator deposit already recorded for this challenge');
    }

    if (!isCreator && existingChallenge.opponent_deposited) {
      throw new Error('Opponent deposit already recorded for this challenge');
    }

    // Connect to Solana Devnet
    const connection = new Connection('https://api.mainnet-beta.solana.com', 'confirmed');

    // Verify the transaction exists and is confirmed
    const tx = await connection.getTransaction(signature, {
      maxSupportedTransactionVersion: 0
    });

    if (!tx) {
      throw new Error('Transaction not found on blockchain');
    }

    if (tx.meta?.err !== null) {
      throw new Error('Transaction failed on blockchain');
    }

    // Check transaction age (must be recent - within 1 hour)
    const txTimestamp = tx.blockTime ? tx.blockTime * 1000 : 0;
    const txAge = Date.now() - txTimestamp;
    const oneHourMs = 60 * 60 * 1000;
    
    if (txAge > oneHourMs) {
      throw new Error('Transaction is too old. Must be within 1 hour.');
    }

    // Verify transaction details
    const recipientPubkey = new PublicKey(recipientAddress);
    let transferFound = false;
    let transferAmount = 0;

    // Check post balances to verify transfer
    if (tx.meta && tx.transaction) {
      const accountKeys = tx.transaction.message.getAccountKeys().staticAccountKeys;
      
      for (let i = 0; i < accountKeys.length; i++) {
        if (accountKeys[i].equals(recipientPubkey)) {
          const preBalance = tx.meta.preBalances[i];
          const postBalance = tx.meta.postBalances[i];
          transferAmount = (postBalance - preBalance) / 1e9; // Convert lamports to SOL
          
          if (transferAmount >= expectedAmount - 0.000001) { // Small tolerance for fees
            transferFound = true;
          }
          break;
        }
      }
    }

    if (!transferFound) {
      throw new Error('Transfer verification failed: amount mismatch or recipient incorrect');
    }

    console.log('Transaction verified successfully');

    // Record the signature to prevent replay attacks
    const { error: signatureError } = await supabaseClient
      .from('transaction_signatures')
      .insert({
        signature,
        challenge_id: challengeId,
        wallet_address: walletAddress,
        amount: transferAmount
      });

    if (signatureError) {
      console.error('Failed to record signature');
      throw new Error('Failed to prevent replay attack. Transaction not processed.');
    }

    // Update challenge with verified deposit using secure function
    const { data: challenge, error: updateError } = await supabaseClient.rpc(
      'update_challenge_secure',
      {
        challenge_id: challengeId,
        new_creator_deposited: isCreator ? true : null,
        new_opponent_deposited: isCreator ? null : true,
        new_opponent_wallet: isCreator ? null : opponentWallet,
        new_status: isCreator ? null : 'active'
      }
    );

    if (updateError) {
      console.error('Database update error:', updateError);
      throw updateError;
    }

    console.log('Deposit verified and recorded successfully');

    return new Response(
      JSON.stringify({ 
        success: true, 
        verified: true,
        challenge 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Verification error:', error instanceof Error ? error.message : 'Unknown error');
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
