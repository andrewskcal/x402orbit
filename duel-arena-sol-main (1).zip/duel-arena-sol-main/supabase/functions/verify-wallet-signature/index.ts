import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.0';
import nacl from 'https://esm.sh/tweetnacl@1.0.3';
import { decodeBase58 } from 'https://deno.land/std@0.224.0/encoding/base58.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    let body;
    try {
      const text = await req.text();
      console.log('Raw request body:', text);
      body = text ? JSON.parse(text) : {};
    } catch (parseError) {
      console.error('Failed to parse request body:', parseError);
      return new Response(
        JSON.stringify({ error: 'Invalid request body' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { walletAddress, message, signature } = body;

    // Validate inputs
    if (!walletAddress || !message || !signature) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Decode the signature and public key
    const signatureBytes = decodeBase58(signature);
    const publicKeyBytes = decodeBase58(walletAddress);
    const messageBytes = new TextEncoder().encode(message);

    // Verify the signature
    const verified = nacl.sign.detached.verify(
      messageBytes,
      signatureBytes,
      publicKeyBytes
    );

    if (!verified) {
      return new Response(
        JSON.stringify({ error: 'Invalid signature' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create Supabase admin client
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Create deterministic email for wallet
    const walletEmail = `${walletAddress}@wallet.duelarena.app`;
    
    // Generate a deterministic password based on wallet address only
    const passwordSource = `duelarena:${walletAddress}`;
    const passwordHash = await crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(passwordSource)
    );
    const securePassword = Array.from(new Uint8Array(passwordHash))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('')
      .substring(0, 64);

    let user = null;
    let session = null;

    // Try to sign in with the deterministic password first (user might already exist)
    const { data: signInData, error: signInError } = await supabaseAdmin.auth.signInWithPassword({
      email: walletEmail,
      password: securePassword,
    });

    if (signInData?.user && signInData?.session) {
      // User exists and signed in successfully
      user = signInData.user;
      session = signInData.session;
      console.log('User signed in successfully:', user.id);
    } else if (signInError?.message?.includes('Invalid login credentials')) {
      // User doesn't exist, create new user
      console.log('User not found, creating new user...');
      
      const { data: newUserData, error: createError } = await supabaseAdmin.auth.admin.createUser({
        email: walletEmail,
        password: securePassword,
        email_confirm: true,
        user_metadata: {
          wallet_address: walletAddress,
        }
      });

      if (createError) {
        // If user was just created by another request, try signing in again
        if (createError.message?.includes('already been registered')) {
          console.log('User was created by another request, signing in...');
          const { data: retrySignIn, error: retryError } = await supabaseAdmin.auth.signInWithPassword({
            email: walletEmail,
            password: securePassword,
          });
          
          if (retrySignIn?.user && retrySignIn?.session) {
            user = retrySignIn.user;
            session = retrySignIn.session;
          } else {
            throw new Error('Failed to sign in after creation conflict: ' + retryError?.message);
          }
        } else {
          throw new Error('Failed to create user: ' + createError.message);
        }
      } else {
        // New user created, sign them in to get a session
        user = newUserData.user;
        const { data: newSignIn, error: newSignInError } = await supabaseAdmin.auth.signInWithPassword({
          email: walletEmail,
          password: securePassword,
        });
        
        if (newSignIn?.session) {
          session = newSignIn.session;
        } else {
          throw new Error('Failed to create session for new user: ' + newSignInError?.message);
        }
      }
    } else {
      throw new Error('Authentication failed: ' + signInError?.message);
    }

    if (!user || !session) {
      throw new Error('Failed to create or retrieve user session');
    }

    // CRITICAL: Store wallet address in lowercase for consistent RLS policy matching
    const walletAddressLower = walletAddress.toLowerCase();
    
    // Link wallet to user account using UPSERT - CRITICAL: Must succeed before returning
    const { error: walletError } = await supabaseAdmin
      .from('user_wallets')
      .upsert(
        {
          user_id: user.id,
          wallet_address: walletAddressLower,
        },
        {
          onConflict: 'user_id,wallet_address',
          ignoreDuplicates: false
        }
      );
      
    if (walletError) {
      console.error('Failed to link wallet:', walletError);
      throw new Error('Failed to link wallet to account: ' + walletError.message);
    }
    
    console.log('Wallet successfully linked:', walletAddressLower, 'to user:', user.id);

    return new Response(
      JSON.stringify({
        success: true,
        session: session,
        user: user,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in verify-wallet-signature:', error);
    const errorMessage = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
