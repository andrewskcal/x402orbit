-- Create challenges table
CREATE TABLE public.challenges (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  game_type TEXT NOT NULL,
  creator_wallet TEXT NOT NULL,
  opponent_wallet TEXT,
  bet_amount NUMERIC NOT NULL,
  creator_deposited BOOLEAN NOT NULL DEFAULT false,
  opponent_deposited BOOLEAN NOT NULL DEFAULT false,
  status TEXT NOT NULL DEFAULT 'pending',
  winner_wallet TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Enable Row Level Security
ALTER TABLE public.challenges ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (no auth required for this gaming platform)
CREATE POLICY "Anyone can view challenges"
ON public.challenges
FOR SELECT
USING (true);

CREATE POLICY "Anyone can create challenges"
ON public.challenges
FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can update challenges"
ON public.challenges
FOR UPDATE
USING (true);

-- Create index for faster queries
CREATE INDEX idx_challenges_status ON public.challenges(status);
CREATE INDEX idx_challenges_creator ON public.challenges(creator_wallet);
CREATE INDEX idx_challenges_created_at ON public.challenges(created_at DESC);