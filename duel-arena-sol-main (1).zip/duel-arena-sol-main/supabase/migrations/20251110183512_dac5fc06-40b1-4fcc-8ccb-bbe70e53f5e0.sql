-- Create user_wallets table to link users with their wallets
CREATE TABLE public.user_wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id, wallet_address)
);

-- Enable RLS on user_wallets
ALTER TABLE public.user_wallets ENABLE ROW LEVEL SECURITY;

-- Users can view their own wallets
CREATE POLICY "Users can view own wallets" ON public.user_wallets
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- Users can insert their own wallets
CREATE POLICY "Users can insert own wallets" ON public.user_wallets
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Create the missing update_challenge_secure function
CREATE OR REPLACE FUNCTION public.update_challenge_secure(
  challenge_id UUID,
  new_creator_deposited BOOLEAN DEFAULT NULL,
  new_opponent_deposited BOOLEAN DEFAULT NULL,
  new_opponent_wallet TEXT DEFAULT NULL,
  new_winner_wallet TEXT DEFAULT NULL,
  new_status TEXT DEFAULT NULL,
  new_game_state JSONB DEFAULT NULL
)
RETURNS challenges
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated_challenge challenges;
BEGIN
  UPDATE challenges
  SET 
    creator_deposited = COALESCE(new_creator_deposited, creator_deposited),
    opponent_deposited = COALESCE(new_opponent_deposited, opponent_deposited),
    opponent_wallet = COALESCE(new_opponent_wallet, opponent_wallet),
    winner_wallet = COALESCE(new_winner_wallet, winner_wallet),
    status = COALESCE(new_status, status),
    started_at = CASE WHEN new_status = 'active' THEN now() ELSE started_at END,
    completed_at = CASE WHEN new_status = 'completed' THEN now() ELSE completed_at END
  WHERE id = challenge_id
  RETURNING * INTO updated_challenge;
  
  RETURN updated_challenge;
END;
$$;

-- Drop existing overly permissive RLS policies
DROP POLICY IF EXISTS "Anyone can view challenges" ON public.challenges;
DROP POLICY IF EXISTS "Anyone can create challenges" ON public.challenges;
DROP POLICY IF EXISTS "Anyone can update challenges" ON public.challenges;

-- Create secure RLS policies for challenges table
-- Allow anyone to view challenges (needed for matchmaking/challenge links)
CREATE POLICY "Anyone can view challenges" ON public.challenges
  FOR SELECT
  USING (true);

-- Allow authenticated users to create challenges with their own wallet
CREATE POLICY "Authenticated users can create challenges" ON public.challenges
  FOR INSERT TO authenticated
  WITH CHECK (
    creator_wallet IN (SELECT wallet_address FROM user_wallets WHERE user_id = auth.uid())
  );

-- Only service role can update challenges (via edge functions)
CREATE POLICY "Service role can update challenges" ON public.challenges
  FOR UPDATE TO service_role
  USING (true);