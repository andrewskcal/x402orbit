-- Add rounds support to challenges table
ALTER TABLE public.challenges 
  ADD COLUMN rounds INTEGER DEFAULT 1 CHECK (rounds >= 1 AND rounds <= 6),
  ADD COLUMN round_wins JSONB DEFAULT '{"creator": 0, "opponent": 0}'::jsonb;

-- Add comment for clarity
COMMENT ON COLUMN public.challenges.rounds IS 'Total number of rounds to play (1-6). First to win majority wins the match.';
COMMENT ON COLUMN public.challenges.round_wins IS 'Track round wins: {"creator": 0, "opponent": 0}';
