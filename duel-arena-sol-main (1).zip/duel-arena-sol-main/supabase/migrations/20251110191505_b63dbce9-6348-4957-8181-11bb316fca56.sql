-- Create table to track used transaction signatures (prevent replay attacks)
CREATE TABLE IF NOT EXISTS public.transaction_signatures (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  signature text NOT NULL UNIQUE,
  challenge_id uuid NOT NULL,
  wallet_address text NOT NULL,
  amount numeric NOT NULL,
  verified_at timestamp with time zone NOT NULL DEFAULT now(),
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Add index for faster lookups
CREATE INDEX idx_transaction_signatures_signature ON public.transaction_signatures(signature);
CREATE INDEX idx_transaction_signatures_challenge ON public.transaction_signatures(challenge_id);
CREATE INDEX idx_transaction_signatures_wallet ON public.transaction_signatures(wallet_address);

-- Enable RLS
ALTER TABLE public.transaction_signatures ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read signatures (for verification)
CREATE POLICY "Anyone can view transaction signatures"
ON public.transaction_signatures
FOR SELECT
USING (true);

-- Only service role can insert (edge functions)
CREATE POLICY "Service role can insert signatures"
ON public.transaction_signatures
FOR INSERT
WITH CHECK (true);

-- Create table to track rate limiting
CREATE TABLE IF NOT EXISTS public.deposit_rate_limits (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address text NOT NULL,
  attempt_count integer NOT NULL DEFAULT 1,
  last_attempt_at timestamp with time zone NOT NULL DEFAULT now(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(wallet_address)
);

-- Add index for rate limit lookups
CREATE INDEX idx_deposit_rate_limits_wallet ON public.deposit_rate_limits(wallet_address);

-- Enable RLS
ALTER TABLE public.deposit_rate_limits ENABLE ROW LEVEL SECURITY;

-- Service role only
CREATE POLICY "Service role can manage rate limits"
ON public.deposit_rate_limits
FOR ALL
USING (true)
WITH CHECK (true);