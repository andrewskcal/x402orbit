-- Add game_state column to challenges table to support real-time multiplayer
ALTER TABLE public.challenges 
ADD COLUMN IF NOT EXISTS game_state jsonb DEFAULT '{}'::jsonb;