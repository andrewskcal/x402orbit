-- Add demo mode and expiration to challenges table
ALTER TABLE public.challenges 
ADD COLUMN is_demo boolean NOT NULL DEFAULT false,
ADD COLUMN expires_at timestamp with time zone;

-- Create index for finding expired challenges
CREATE INDEX idx_challenges_expires_at ON public.challenges(expires_at) WHERE expires_at IS NOT NULL;

-- Function to check if challenge is expired
CREATE OR REPLACE FUNCTION is_challenge_expired(challenge_row challenges)
RETURNS boolean AS $$
BEGIN
  IF challenge_row.expires_at IS NULL THEN
    RETURN false;
  END IF;
  RETURN challenge_row.expires_at < now();
END;
$$ LANGUAGE plpgsql STABLE;