-- Fix search path for is_challenge_expired function
DROP FUNCTION IF EXISTS is_challenge_expired(challenges);

CREATE OR REPLACE FUNCTION is_challenge_expired(challenge_row challenges)
RETURNS boolean AS $$
BEGIN
  IF challenge_row.expires_at IS NULL THEN
    RETURN false;
  END IF;
  RETURN challenge_row.expires_at < now();
END;
$$ LANGUAGE plpgsql STABLE SET search_path = public;