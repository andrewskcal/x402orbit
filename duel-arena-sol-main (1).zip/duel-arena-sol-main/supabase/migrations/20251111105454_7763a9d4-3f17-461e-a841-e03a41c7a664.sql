-- Drop the restrictive service-role-only update policy
DROP POLICY IF EXISTS "Service role can update challenges" ON public.challenges;

-- Allow opponents to join challenges (set opponent_wallet when it's null)
CREATE POLICY "Anyone can join open challenges"
ON public.challenges
FOR UPDATE
USING (opponent_wallet IS NULL)
WITH CHECK (opponent_wallet IS NOT NULL);

-- Allow creators to update their own challenges
CREATE POLICY "Creators can update their challenges"
ON public.challenges
FOR UPDATE
USING (
  creator_wallet IN (
    SELECT wallet_address 
    FROM user_wallets 
    WHERE user_id = auth.uid()
  )
);

-- Allow service role full update access
CREATE POLICY "Service role can update all challenges"
ON public.challenges
FOR UPDATE
USING (auth.role() = 'service_role');