-- Allow opponents to update their challenges after joining
CREATE POLICY "Opponents can update their challenges"
ON public.challenges
FOR UPDATE
USING (
  opponent_wallet IN (
    SELECT user_wallets.wallet_address 
    FROM user_wallets 
    WHERE user_wallets.user_id = auth.uid()
  )
);