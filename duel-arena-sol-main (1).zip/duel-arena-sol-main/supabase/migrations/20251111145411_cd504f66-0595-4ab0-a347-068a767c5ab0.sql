-- Drop the old case-sensitive policy
DROP POLICY IF EXISTS "Authenticated users can create challenges" ON public.challenges;

-- Create new case-insensitive policy for creating challenges
CREATE POLICY "Authenticated users can create challenges"
ON public.challenges
FOR INSERT
WITH CHECK (
  LOWER(creator_wallet) IN (
    SELECT LOWER(user_wallets.wallet_address)
    FROM user_wallets
    WHERE user_wallets.user_id = auth.uid()
  )
);