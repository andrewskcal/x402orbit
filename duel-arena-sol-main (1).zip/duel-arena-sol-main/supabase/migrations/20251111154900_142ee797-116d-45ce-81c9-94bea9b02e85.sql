-- Add comprehensive validation to update_challenge_secure function
CREATE OR REPLACE FUNCTION public.update_challenge_secure(
  challenge_id uuid,
  new_creator_deposited boolean DEFAULT NULL,
  new_opponent_deposited boolean DEFAULT NULL,
  new_opponent_wallet text DEFAULT NULL,
  new_winner_wallet text DEFAULT NULL,
  new_status text DEFAULT NULL,
  new_game_state jsonb DEFAULT NULL
)
RETURNS challenges
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  current_challenge challenges;
  updated_challenge challenges;
BEGIN
  -- Fetch current challenge state
  SELECT * INTO current_challenge 
  FROM challenges 
  WHERE id = challenge_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Challenge not found';
  END IF;
  
  -- Validate winner is a participant
  IF new_winner_wallet IS NOT NULL THEN
    IF new_winner_wallet != current_challenge.creator_wallet 
       AND new_winner_wallet != current_challenge.opponent_wallet THEN
      RAISE EXCEPTION 'Winner must be a participant in the challenge';
    END IF;
  END IF;
  
  -- Validate state transitions
  IF new_status IS NOT NULL THEN
    -- From pending: can only go to open, active, or cancelled
    IF current_challenge.status = 'pending' 
       AND new_status NOT IN ('open', 'active', 'cancelled') THEN
      RAISE EXCEPTION 'Invalid state transition from pending to %', new_status;
    END IF;
    
    -- From open: can only go to active or cancelled
    IF current_challenge.status = 'open' 
       AND new_status NOT IN ('active', 'cancelled') THEN
      RAISE EXCEPTION 'Invalid state transition from open to %', new_status;
    END IF;
    
    -- From active: can only go to completed or cancelled
    IF current_challenge.status = 'active' 
       AND new_status NOT IN ('completed', 'cancelled') THEN
      RAISE EXCEPTION 'Invalid state transition from active to %', new_status;
    END IF;
    
    -- From completed: cannot change status
    IF current_challenge.status = 'completed' THEN
      RAISE EXCEPTION 'Cannot modify completed challenge';
    END IF;
  END IF;
  
  -- Validate both players deposited before marking active
  IF new_status = 'active' THEN
    IF NOT (COALESCE(new_creator_deposited, current_challenge.creator_deposited, false) 
        AND COALESCE(new_opponent_deposited, current_challenge.opponent_deposited, false)) THEN
      RAISE EXCEPTION 'Both players must deposit before challenge can become active';
    END IF;
    
    -- Ensure opponent has joined
    IF COALESCE(new_opponent_wallet, current_challenge.opponent_wallet) IS NULL THEN
      RAISE EXCEPTION 'Opponent must join before challenge can become active';
    END IF;
  END IF;
  
  -- Validate completed challenges have a winner
  IF new_status = 'completed' AND new_winner_wallet IS NULL THEN
    RAISE EXCEPTION 'Completed challenges must have a winner';
  END IF;
  
  -- Perform the update
  UPDATE challenges
  SET 
    creator_deposited = COALESCE(new_creator_deposited, creator_deposited),
    opponent_deposited = COALESCE(new_opponent_deposited, opponent_deposited),
    opponent_wallet = COALESCE(new_opponent_wallet, opponent_wallet),
    winner_wallet = COALESCE(new_winner_wallet, winner_wallet),
    status = COALESCE(new_status, status),
    game_state = COALESCE(new_game_state, game_state),
    started_at = CASE 
      WHEN new_status = 'active' AND started_at IS NULL THEN now() 
      ELSE started_at 
    END,
    completed_at = CASE 
      WHEN new_status = 'completed' AND completed_at IS NULL THEN now() 
      ELSE completed_at 
    END,
    updated_at = now()
  WHERE id = challenge_id
  RETURNING * INTO updated_challenge;
  
  RETURN updated_challenge;
END;
$$;